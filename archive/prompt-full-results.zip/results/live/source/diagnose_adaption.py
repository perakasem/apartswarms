"""Run isolated Adaption reasoning checks. Paid calls need --execute-paid."""
from contextlib import closing, contextmanager
from datetime import datetime, timezone
from decimal import Decimal
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import sys
import tempfile
import time

from selection_study.common import canonical, digest
from selection_study.environment import build_messages, generate_episode
from selection_study.ledger import BudgetError, money
from selection_study.runner import strict_choice
from selection_study.transport import (AdaptionProvider, TransportError, MODEL_PRICES,
                                       estimate_credit_charge, maximum_call_cost, validate_usage)

BASE = Path(__file__).resolve().parent
MODELS = tuple(MODEL_PRICES)
VARIANTS = {'reasoning_none': {'reasoning': {'effort': 'none'}},
            'template_false': {'chat_template_kwargs': {'enable_thinking': False}}}
OUTPUT_CAP = 256
DIAGNOSTIC_LIMIT = Decimal('1')
GLOBAL_LIMIT = Decimal('100')
MAX_ATTEMPTS = 20


def clean(value, secrets):
    if isinstance(value, str):
        for secret in secrets:
            if secret:
                value = value.replace(secret, '[REDACTED]')
        return value
    if isinstance(value, dict):
        return {clean(key, secrets): clean(item, secrets) for key, item in value.items()}
    if isinstance(value, list):
        return [clean(item, secrets) for item in value]
    return value


def read_json(path):
    def invalid(value):
        raise ValueError('Non-finite JSON value')
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('Duplicate JSON key')
            result[key] = value
        return result
    return json.loads(Path(path).read_text(), parse_constant=invalid, object_pairs_hook=unique)


def durable_json(path, value, *, exclusive=False):
    """Write the file and sync its containing directory before returning."""
    path = Path(path)
    payload = (canonical(value) + '\n').encode()
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        if exclusive:
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        else:
            fd, temporary = tempfile.mkstemp(prefix='.pending-', dir=path.parent)
        with os.fdopen(fd, 'wb') as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        if not exclusive:
            os.replace(temporary, path)
            temporary = None
        directory = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if temporary is not None and os.path.exists(temporary):
            os.unlink(temporary)


@contextmanager
def directory_lock(root):
    root.mkdir(parents=True, exist_ok=True)
    with (root / '.diagnostic.lock').open('a') as stream:
        try:
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise BudgetError('Another diagnostic process holds the lock') from None
        try:
            yield
        finally:
            fcntl.flock(stream, fcntl.LOCK_UN)


def main_account(root):
    """Read the main ledger without opening a write connection."""
    root = Path(root).resolve()
    status = read_json(root / 'status.json')
    study = read_json(root / 'study.json')
    if status.get('status') != 'probe_failed' or status.get('mode') != 'live' or study.get('mode') != 'live':
        raise BudgetError('Diagnostics require a stopped live study with failed probes')
    with closing(sqlite3.connect((root / 'credits.sqlite').as_uri() + '?mode=ro', uri=True)) as db:
        db.row_factory = sqlite3.Row
        db.execute('BEGIN')
        metadata = dict(db.execute('SELECT key,value FROM metadata').fetchall())
        rows = [dict(row) for row in db.execute('SELECT * FROM attempts ORDER BY rowid')]
    if (metadata.get('mode') != 'live' or metadata.get('currency') != 'adaption_credits'
            or money(metadata.get('limit_credits')) != GLOBAL_LIMIT or metadata.get('frozen_reason')
            or metadata.get('prices') != json.dumps(MODEL_PRICES, sort_keys=True)):
        raise BudgetError('The main ledger settings do not permit diagnostics')
    committed = Decimal(0)
    for row in rows:
        if row['phase'] != 'probe' or row['status'] not in ('settled', 'pending', 'unknown'):
            raise BudgetError('The main study is no longer at its probe gate')
        if row['status'] == 'pending':
            raise BudgetError('The main study still has a pending request')
        committed += money(row['estimated_charge'] if row['status'] == 'settled' else row['reserved'])
    return {'root': str(root), 'committed_credits': str(committed),
            'status_hash': digest(status), 'study_hash': digest(study),
            'ledger_hash': digest({'metadata': metadata, 'attempts': rows}),
            'attempts': len(rows), 'actual_billing_verified': False}


class Journal:
    def __init__(self, path, main_root):
        self.path = Path(path)
        self.settings = {'schema': 'adaption-diagnostics-1', 'currency': 'adaption_credits',
                         'diagnostic_limit_credits': str(DIAGNOSTIC_LIMIT),
                         'global_limit_credits': str(GLOBAL_LIMIT), 'max_attempts': MAX_ATTEMPTS,
                         'main_root': str(Path(main_root).resolve()), 'model_prices': MODEL_PRICES,
                         'reservation_by_model': {model: str(maximum_call_cost(model)) for model in MODELS},
                         'output_cap': OUTPUT_CAP, 'input_cap': 6000,
                         'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                         'carry_into_main_before_resume': True}
        self.events = []
        if self.path.exists():
            saved = read_json(self.path)
            if saved.get('settings') != self.settings:
                raise BudgetError('The diagnostic journal settings changed')
            self.events = saved['events']
            self.state()

    def state(self):
        attempts, previous, frozen = {}, None, False
        for number, original in enumerate(self.events, 1):
            event = dict(original)
            recorded = event.pop('hash')
            if event['sequence'] != number or event['previous'] != previous or digest(event) != recorded:
                raise BudgetError('The diagnostic journal hash check failed')
            previous = recorded
            kind, attempt_id = event['kind'], event.get('attempt_id')
            if kind == 'reserve':
                if attempt_id in attempts or event['model'] not in MODELS:
                    raise BudgetError('The diagnostic attempt identity repeats or is invalid')
                amount = money(event['reserved_credits'])
                if amount != maximum_call_cost(event['model']):
                    raise BudgetError('The diagnostic reservation is not complete')
                attempts[attempt_id] = {'model': event['model'], 'reserved': amount,
                                        'status': 'pending', 'estimated_charge': None}
            elif kind in ('settle', 'unknown'):
                if attempt_id not in attempts or attempts[attempt_id]['status'] != 'pending':
                    raise BudgetError('The diagnostic settlement has no pending reservation')
                item = attempts[attempt_id]
                if kind == 'settle':
                    charge = money(event['estimated_credits'])
                    if charge > item['reserved']:
                        raise BudgetError('The diagnostic estimate exceeds its reservation')
                    item['estimated_charge'] = charge
                item['status'] = 'settled' if kind == 'settle' else 'unknown'
            elif kind == 'freeze':
                frozen = True
            else:
                raise BudgetError('The diagnostic journal event is invalid')
        charged = sum((item['estimated_charge'] for item in attempts.values()
                       if item['status'] == 'settled'), Decimal(0))
        outstanding = sum((item['reserved'] for item in attempts.values()
                           if item['status'] != 'settled'), Decimal(0))
        if len(attempts) > MAX_ATTEMPTS or charged + outstanding > DIAGNOSTIC_LIMIT:
            raise BudgetError('The diagnostic journal exceeds its fixed limits')
        return {'attempts': attempts, 'charged': charged, 'outstanding': outstanding,
                'committed': charged + outstanding, 'frozen': frozen, 'previous': previous}

    def append(self, kind, **fields):
        previous = self.state()['previous']
        event = {'kind': kind, 'sequence': len(self.events) + 1, 'previous': previous,
                 'time_utc': datetime.now(timezone.utc).isoformat(), **fields}
        event['hash'] = digest(event)
        self.events.append(event)
        self.state()
        durable_json(self.path, {'settings': self.settings, 'events': self.events})

    def reserve(self, attempt_id, model, account):
        state = self.state()
        amount = maximum_call_cost(model)
        if state['frozen'] or attempt_id in state['attempts'] or len(state['attempts']) >= MAX_ATTEMPTS:
            raise BudgetError('The diagnostic journal is frozen, full, or has this attempt already')
        if state['committed'] + amount > DIAGNOSTIC_LIMIT:
            raise BudgetError('The diagnostic credit limit would be exceeded')
        if money(account['committed_credits']) + state['committed'] + amount > GLOBAL_LIMIT:
            raise BudgetError('The combined study credit limit would be exceeded')
        self.append('reserve', attempt_id=attempt_id, model=model,
                    reserved_credits=str(amount), main_account=account)


def request_body(model, variant, messages):
    if model not in MODELS or variant not in VARIANTS:
        raise ValueError('The model or diagnostic variant is invalid')
    return {'model': model, 'input': messages, 'tools': [], 'tool_choice': 'none',
            'agentic_memory': False, 'store': False, 'stream': False,
            'temperature': .7, 'max_output_tokens': OUTPUT_CAP, **VARIANTS[variant]}


def inspect_response(raw, model, count, episode):
    if not isinstance(raw, dict):
        raise ValueError('The response is not an object')
    usage = validate_usage(raw.get('usage'), enforce_caps=False)
    if usage['input_tokens'] > min(6000, count) or usage['output_tokens'] > OUTPUT_CAP:
        raise ValueError('The response exceeds a diagnostic token bound')
    if raw.get('model') != model or not isinstance(raw.get('id'), str) or not raw['id']:
        raise ValueError('The response model or identifier is invalid')
    if raw.get('status') not in ('completed', 'incomplete', 'failed', 'cancelled'):
        raise ValueError('The response has no final status')
    output = raw.get('output', [])
    if not isinstance(output, list) or any(not isinstance(item, dict)
                                          or item.get('type') not in ('message', 'reasoning') for item in output):
        raise ValueError('The response contains an unexpected output item')
    text = raw.get('output_text')
    if text is None:
        text = ''.join(part.get('text', '') for item in output if item.get('type') == 'message'
                       for part in item.get('content', []) if part.get('type') == 'output_text')
    if not isinstance(text, str):
        raise ValueError('The response text is invalid')
    worker = strict_choice(text, episode)
    return {'request_id': raw['id'], 'response_model': raw['model'], 'status': raw['status'],
            'usage': usage, 'reasoning_config': raw.get('reasoning'),
            'reasoning_tokens': (usage.get('output_tokens_details') or {}).get('reasoning_tokens'),
            'reasoning_items': sum(item.get('type') == 'reasoning' for item in output),
            'text': text, 'worker_id': worker, 'strict_json_valid_choice': worker is not None,
            'completed_valid_choice': raw['status'] == 'completed' and not raw.get('error') and worker is not None,
            'incomplete_details': raw.get('incomplete_details'),
            'estimated_credits': str(estimate_credit_charge(model, usage)),
            'actual_billing_verified': False}


class DiagnosticSession:
    def __init__(self, main_root, diagnostic_root, provider, counters):
        self.main_root = Path(main_root).resolve()
        self.root = Path(diagnostic_root).resolve()
        self.provider = provider
        self.counters = counters
        self.secrets = getattr(provider, 'secrets', ())

    def run(self, variant, run_id, *, execute_paid=False, models=MODELS):
        if not execute_paid:
            raise BudgetError('Diagnostic dispatch requires execute_paid=True')
        if variant not in VARIANTS or not re.fullmatch(r'[A-Za-z0-9_-]{1,80}', run_id):
            raise ValueError('The diagnostic variant or run identifier is invalid')
        if not models or len(set(models)) != len(models) or any(model not in MODELS for model in models):
            raise ValueError('The diagnostic model list is invalid')
        results = []
        with directory_lock(self.root):
            journal = Journal(self.root / 'budget.json', self.main_root)
            initial_account = main_account(self.main_root)
            episode = generate_episode(0, 'worker_objection')
            messages = build_messages(episode, [], 1)
            for model in models:
                attempt_id = f'{run_id}__{model}'
                target = self.root / 'attempts' / attempt_id
                if target.exists():
                    raise BudgetError('The diagnostic attempt folder already exists')
                count = self.counters[model].count(messages)
                template_counts = self.counters[model].count_modes(messages)
                if type(count) is not int or not 0 <= count <= 6000:
                    raise ValueError('The diagnostic input exceeds its native token bound')
                body = request_body(model, variant, messages)
                account = main_account(self.main_root)
                if account != initial_account:
                    raise BudgetError('The main study changed during diagnostics')
                journal.reserve(attempt_id, model, account)
                try:
                    durable_json(target / 'request.json', clean({
                        'attempt_id': attempt_id, 'variant': variant, 'body': body,
                        'input_bound': count, 'counter': self.counters[model].name,
                        'token_counts_by_template': template_counts,
                        'episode_hash': digest(episode), 'seed': 0, 'round': 1,
                        'reserved_credits': str(maximum_call_cost(model)),
                    }, self.secrets), exclusive=True)
                    # Check again after durable reservation and request logging.
                    account = main_account(self.main_root)
                    if account != initial_account or money(account['committed_credits']) + journal.state()['committed'] > GLOBAL_LIMIT:
                        raise BudgetError('The main study changed before diagnostic dispatch')
                except BaseException:
                    journal.append('settle', attempt_id=attempt_id, estimated_credits='0', reason='No dispatch')
                    journal.append('freeze', reason='The diagnostic pre-dispatch check or write failed')
                    raise
                started = time.monotonic()
                try:
                    raw = self.provider._request('/responses', body)
                except BaseException as error:
                    http_status = None
                    if isinstance(error, TransportError):
                        match = re.fullmatch(r'Adaption returned HTTP ([0-9]{3})', str(error))
                        http_status = int(match.group(1)) if match else None
                    result = {'attempt_id': attempt_id, 'model': model, 'variant': variant,
                              'status': 'transport_error', 'http_status': http_status,
                              'elapsed_seconds': time.monotonic() - started,
                              'token_counts_by_template': template_counts,
                              'error_type': type(error).__name__, 'estimated_credits': None,
                              'reserved_credits': str(maximum_call_cost(model)),
                              'unknown_charge': True, 'actual_billing_verified': False}
                    try:
                        durable_json(target / 'result.json', clean(result, self.secrets), exclusive=True)
                        journal.append('unknown', attempt_id=attempt_id, reason='Transport error; no checked usage')
                    except BaseException:
                        journal.append('freeze', reason='The diagnostic error record could not be saved')
                        raise
                    results.append(result)
                    if not isinstance(error, TransportError):
                        journal.append('freeze', reason='Unexpected diagnostic transport failure')
                        raise RuntimeError('The diagnostic transport failed') from None
                    continue
                try:
                    durable_json(target / 'raw_response.json', clean(raw, self.secrets), exclusive=True)
                    result = inspect_response(raw, model, count, episode)
                    result.update({'attempt_id': attempt_id, 'model': model, 'variant': variant,
                                   'elapsed_seconds': time.monotonic() - started,
                                   'token_counts_by_template': template_counts,
                                   'reserved_credits': str(maximum_call_cost(model))})
                    result = clean(result, self.secrets)
                    durable_json(target / 'result.json', result, exclusive=True)
                    journal.append('settle', attempt_id=attempt_id, estimated_credits=result['estimated_credits'],
                                   request_id=result['request_id'], usage=result['usage'])
                except BaseException:
                    # Keep the full reservation when the result cannot be checked or saved.
                    if journal.state()['attempts'][attempt_id]['status'] == 'pending':
                        journal.append('unknown', attempt_id=attempt_id, reason='Response validation or write failed')
                    journal.append('freeze', reason='The diagnostic response could not be checked or saved')
                    raise RuntimeError('The diagnostic response check or write failed') from None
                results.append(result)
            state = journal.state()
            return {'results': results, 'diagnostic_attempts': len(state['attempts']),
                    'estimated_charged_credits': str(state['charged']),
                    'outstanding_reserved_credits': str(state['outstanding']),
                    'diagnostic_committed_credits': str(state['committed']),
                    'combined_committed_credits': str(money(initial_account['committed_credits']) + state['committed']),
                    'carry_into_main_before_resume': True, 'actual_billing_verified': False}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--variant', choices=tuple(VARIANTS), required=True)
    parser.add_argument('--run-id', help='Unique run name. Defaults to the variant name.')
    parser.add_argument('--main-root', type=Path, default=BASE / 'results' / 'live')
    parser.add_argument('--diagnostic-root', type=Path, default=BASE / 'results' / 'diagnostics')
    parser.add_argument('--key-receipt', type=Path)
    parser.add_argument('--execute-paid', action='store_true')
    args = parser.parse_args(argv)
    if not args.execute_paid:
        print(canonical({'status': 'prepared_not_sent', 'paid_calls': 0, 'variant': args.variant,
                         'models': list(MODELS), 'output_cap': OUTPUT_CAP,
                         'diagnostic_limit_credits': str(DIAGNOSTIC_LIMIT),
                         'global_limit_credits': str(GLOBAL_LIMIT)}))
        return 0
    try:
        if not args.key_receipt:
            raise ValueError('A local key receipt is required')
        main_account(args.main_root)
        from selection_study.cli import counters
        native = counters()
        from key_prompt import receive_key
        key = receive_key(args.key_receipt)
        provider = AdaptionProvider(key)
        key = None
        session = DiagnosticSession(args.main_root, args.diagnostic_root, provider, native)
        result = session.run(args.variant, args.run_id or args.variant, execute_paid=True)
        print(canonical(result))
        return 0
    except BaseException as error:
        # Never copy exception text, request objects, or the key to stdout/stderr.
        print('Diagnostic stopped. Check its saved records. Error class: ' + type(error).__name__, file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
