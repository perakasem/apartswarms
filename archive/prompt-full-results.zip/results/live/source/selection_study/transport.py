"""Adaption inference transport. This module has no automatic retries."""

from __future__ import annotations

from decimal import Decimal
import json
import ssl
import urllib.error
import urllib.request


BASE_URL = 'https://api.prod.adaptionlabs.ai/api/v1'
MODEL_PRICES = {
    'qwen3.5-397b': {'input': '0.55', 'output': '3.50'},
    'glm-5.2': {'input': '1.40', 'output': '4.40'},
}
INPUT_CAP = 6000
OUTPUT_CAP = 4000


class TransportError(RuntimeError):
    def __init__(self, message, *, retryable=False, fatal=True, known_usage=None, request_id=None):
        super().__init__(message)
        self.retryable = retryable
        self.fatal = fatal
        self.known_usage = known_usage
        self.request_id = request_id


def validate_usage(usage, *, enforce_caps=True):
    if not isinstance(usage, dict):
        raise ValueError('The response has no token usage')
    for field in ('input_tokens', 'output_tokens', 'total_tokens'):
        value = usage.get(field)
        if type(value) is not int or value < 0:
            raise ValueError('The response has invalid token usage')
    if usage['total_tokens'] != usage['input_tokens'] + usage['output_tokens']:
        raise ValueError('The response token totals do not agree')
    if enforce_caps and (usage['input_tokens'] > INPUT_CAP or usage['output_tokens'] > OUTPUT_CAP):
        raise ValueError('The response exceeds a token limit')
    for details, field, bound in (
        ('output_tokens_details', 'reasoning_tokens', 'output_tokens'),
        ('input_tokens_details', 'cached_tokens', 'input_tokens'),
    ):
        value = usage.get(details)
        if value is not None and not isinstance(value, dict):
            raise ValueError('The response has invalid token details')
        if value is not None and field in value:
            count = value[field]
            if type(count) is not int or not 0 <= count <= usage[bound]:
                raise ValueError('The response has invalid token details')
    return usage


def estimate_credit_charge(model_id, usage):
    """Use uncached rates. This is an estimate, not a billing receipt."""
    validate_usage(usage, enforce_caps=False)
    price = MODEL_PRICES[model_id]
    return (Decimal(usage['input_tokens']) * Decimal(price['input'])
            + Decimal(usage['output_tokens']) * Decimal(price['output'])) / Decimal(1_000_000)


def maximum_call_cost(model_id, reserve=True):
    result = estimate_credit_charge(model_id, {'input_tokens': INPUT_CAP,
        'output_tokens': OUTPUT_CAP, 'total_tokens': INPUT_CAP + OUTPUT_CAP})
    return result * Decimal('1.05') if reserve else result


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.HTTPError(req.full_url, code, 'Redirect blocked', headers, fp)


class AdaptionProvider:
    mode = 'live'

    def __init__(self, api_key, opener=None, timeout=120):
        if not isinstance(api_key, str) or not api_key or api_key != api_key.strip():
            raise ValueError('A valid Adaption key is required')
        if any(ord(char) < 33 or ord(char) > 126 for char in api_key):
            raise ValueError('A valid Adaption key is required')
        self._api_key = api_key
        self.secrets = (api_key,)
        self.timeout = timeout
        if opener is None:
            import certifi
            context = ssl.create_default_context(cafile=certifi.where())
            self._http = urllib.request.build_opener(
                _NoRedirect(), urllib.request.HTTPSHandler(context=context))
            self._opener = self._http.open
        else:
            self._opener = opener

    def _clean(self, value):
        if isinstance(value, str):
            return value.replace(self._api_key, '[REDACTED]')
        if isinstance(value, list):
            return [self._clean(item) for item in value]
        if isinstance(value, dict):
            return {self._clean(key): self._clean(item) for key, item in value.items()}
        return value

    def _request(self, path, body=None):
        headers = {'Authorization': 'Bearer ' + self._api_key, 'Accept': 'application/json'}
        data = None
        if body is not None:
            headers['Content-Type'] = 'application/json'
            data = json.dumps(body, ensure_ascii=False, allow_nan=False, separators=(',', ':')).encode()
        request = urllib.request.Request(BASE_URL + path, data=data, headers=headers,
                                         method='POST' if body is not None else 'GET')
        try:
            with self._opener(request, timeout=self.timeout) as response:
                raw = response.read(4_000_001)
                if len(raw) > 4_000_000:
                    raise TransportError('The response body exceeds the local limit')
                value = json.loads(raw)
        except urllib.error.HTTPError as error:
            code = error.code
            error.close()
            retryable = code in (408, 429, 500, 502, 503, 504)
            raise TransportError(f'Adaption returned HTTP {code}', retryable=retryable,
                                 fatal=not retryable) from None
        except (urllib.error.URLError, TimeoutError, ConnectionError, ssl.SSLError):
            raise TransportError('The Adaption connection failed', retryable=True, fatal=False) from None
        except (json.JSONDecodeError, UnicodeError):
            raise TransportError('Adaption returned invalid JSON') from None
        if not isinstance(value, dict):
            raise TransportError('Adaption returned an invalid response object')
        return self._clean(value)

    def list_models(self):
        raw = self._request('/models?type=hosted')
        data = raw.get('data')
        if (raw.get('object') != 'list' or not isinstance(data, list)
                or any(not isinstance(item, dict) or not isinstance(item.get('id'), str) for item in data)):
            raise TransportError('The hosted model list is invalid')
        return raw

    def complete(self, model_id, messages):
        if model_id not in MODEL_PRICES:
            raise ValueError('The model has no fixed study price')
        if not isinstance(messages, list) or len(messages) != 3:
            raise ValueError('The request requires three study messages')
        for message, role in zip(messages, ('system', 'user', 'user')):
            if (not isinstance(message, dict) or set(message) != {'role', 'content'}
                    or message['role'] != role or not isinstance(message['content'], str)):
                raise ValueError('The request must use the fixed study message format')
        raw = self._request('/responses', {'model': model_id, 'input': messages,
            'tools': [], 'tool_choice': 'none', 'agentic_memory': False, 'store': False,
            'stream': False, 'temperature': 0.7, 'max_output_tokens': OUTPUT_CAP,
            'reasoning': {'effort': 'none'}})
        usage = raw.get('usage')
        request_id = raw.get('id') if isinstance(raw.get('id'), str) else None
        try:
            validate_usage(usage)
            if not request_id or raw.get('model') != model_id:
                raise ValueError('The response model or identifier differs')
            if (not isinstance(raw.get('reasoning'), dict)
                    or raw['reasoning'].get('effort') != 'none'
                    or (usage.get('output_tokens_details') or {}).get('reasoning_tokens') != 0):
                raise ValueError('The response did not confirm disabled reasoning')
            details = raw.get('incomplete_details') or {}
            if (raw.get('status') == 'incomplete' and isinstance(details, dict)
                    and details.get('reason') == 'max_output_tokens' and not raw.get('error')):
                raise TransportError('The model used its output allowance before completion',
                                     retryable=False, fatal=False,
                                     known_usage=usage, request_id=request_id)
            if raw.get('status') != 'completed' or raw.get('error'):
                raise ValueError('The model response did not complete')
            output = raw.get('output', [])
            if not isinstance(output, list) or any(not isinstance(item, dict) for item in output):
                raise ValueError('The response output is invalid')
            if any(item.get('type') not in ('message', 'reasoning') for item in output):
                raise ValueError('The response contains an unrequested tool or item')
            text = raw.get('output_text')
            if text is None:
                parts = [part.get('text', '') for item in output if item.get('type') == 'message'
                         for part in item.get('content', []) if isinstance(part, dict) and part.get('type') == 'output_text']
                text = ''.join(parts)
            if not isinstance(text, str):
                raise ValueError('The response text is invalid')
        except (ValueError, TypeError, KeyError):
            # Preserve usage for conservative accounting, but never print provider content.
            raise TransportError('The response failed the fixed model, output, or token checks',
                                 known_usage=usage if isinstance(usage, dict) else None,
                                 request_id=request_id) from None
        return {'id': request_id, 'model': raw['model'], 'status': raw['status'],
                'text': text, 'usage': usage, 'raw': raw}
