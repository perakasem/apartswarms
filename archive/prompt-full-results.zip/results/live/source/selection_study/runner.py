"""One coordinator call per assignment. Fixed workers run locally."""
import asyncio
import json
import math
from pathlib import Path
import time

from .common import EventLog, digest, read_json, write_json
from .environment import build_messages, generate_episode, outcome, failure_outcome, CONDITIONS
from .ledger import CreditLedger, BudgetError
from .transport import (MODEL_PRICES, TransportError, estimate_credit_charge,
                        maximum_call_cost, INPUT_CAP)
from .analysis import summarize_run, aggregate


MODELS = tuple(MODEL_PRICES)


def manifest():
    return [{'phase': phase, 'model_id': model, 'seed': seed, 'condition': condition,
             'run_id': f'{phase}_{model}_{seed}_{condition}'}
            for phase, seeds in [('pilot', (1, 2)), ('main', range(1001, 1041))]
            for seed in seeds for condition in (CONDITIONS if seed % 2 else CONDITIONS[::-1])
            for model in MODELS]


def strict_choice(text, episode):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result: raise ValueError('Duplicate key')
            result[key] = value
        return result
    try:
        value = json.loads(text, object_pairs_hook=unique)
    except (ValueError, TypeError):
        return None
    if (not isinstance(value, dict) or set(value) != {'worker_id'}
            or not isinstance(value['worker_id'], str) or value['worker_id'] not in episode['worker_ids']):
        return None
    return value['worker_id']


class OfflineProvider:
    mode = 'offline'
    secrets = ()

    def complete(self, model_id, messages):
        # Parse only the same roster that a live coordinator sees. Fixed test choice.
        common = json.loads(messages[1]['content'].split('\n', 1)[1])
        return {'id': 'offline', 'model': model_id, 'status': 'completed',
                'text': json.dumps({'worker_id': common['worker_ids'][0]}),
                'usage': {'input_tokens': 0, 'output_tokens': 0, 'total_tokens': 0},
                'raw': {'offline': True}}


class Runner:
    def __init__(self, root, provider, counters, *, limit='100', concurrency=16):
        self.root = Path(root)
        self.provider = provider
        self.counters = counters
        self.ledger = CreditLedger(self.root / 'credits.sqlite', limit, provider.mode)
        self.semaphore = asyncio.Semaphore(concurrency)
        self.stop = False
        self.retry_delay = 2 if provider.mode == 'live' else 0

    def _halt(self, reason, uncertain_attempt=None):
        # Stop this process even if a ledger write also fails.
        self.stop = True
        if uncertain_attempt is not None:
            try:
                self.ledger.mark_unknown(uncertain_attempt, reason, freeze=True)
                return
            except Exception:
                # A charge may already be settled. Never replace it with unknown.
                pass
        try:
            self.ledger.freeze(reason)
        except Exception:
            # The caller still fails. Pending reservations remain conservative.
            pass

    async def request(self, row, round_number, messages, count, log):
        model = row['model_id']
        for attempt in range(2):
            attempt_id = f'{row["run_id"]}|r{round_number}|attempt{attempt}'
            async with self.semaphore:
                if self.stop: raise BudgetError('A prior request stopped this study')
                reserve = maximum_call_cost(model) if self.provider.mode == 'live' else 0
                self.ledger.reserve(attempt_id, model, row['phase'], reserve, is_retry=bool(attempt))
                try:
                    log.append('request', attempt_id=attempt_id, round_number=round_number,
                               model_id=model, messages=messages, counted_input_tokens=count,
                               counter=self.counters[model].name)
                except BaseException:
                    self.stop = True
                    try:
                        self.ledger.settle(attempt_id, 0)
                    finally:
                        self._halt('Request logging failed before dispatch')
                    raise
                started = time.monotonic()
                try:
                    response = await asyncio.to_thread(self.provider.complete, model, messages)
                except TransportError as error:
                    try:
                        known = None
                        try:
                            known = estimate_credit_charge(model, error.known_usage)
                        except (ValueError, TypeError, KeyError):
                            pass
                        if known is not None:
                            self.ledger.settle(attempt_id, known, error.known_usage)
                        else:
                            self.ledger.mark_unknown(attempt_id, freeze=error.fatal)
                        log.append('transport_error', attempt_id=attempt_id, message=str(error),
                                   retryable=error.retryable, fatal=error.fatal, usage=error.known_usage,
                                   request_id=error.request_id)
                        if (known is not None and self.provider.mode == 'live'
                                and error.known_usage['input_tokens'] > count):
                            raise ValueError('Native count plus allowance was too small')
                    except BaseException:
                        self._halt('Error accounting or logging failed after dispatch', attempt_id)
                        raise
                    if error.fatal:
                        self._halt('The response failed required checks')
                        raise
                    if not error.retryable or attempt == 1:
                        return None, None
                except BaseException:
                    self._halt('The request ended without a checked response', attempt_id)
                    raise
                else:
                    try:
                        # Account first, so a log error cannot erase the known estimate.
                        usage = response['usage']
                        charge = estimate_credit_charge(model, usage) if self.provider.mode == 'live' else 0
                        self.ledger.settle(attempt_id, charge, usage)
                        log.append('response', attempt_id=attempt_id, elapsed_seconds=time.monotonic()-started,
                                   response=response, estimated_credits=str(charge))
                        if self.provider.mode == 'live' and usage['input_tokens'] > count:
                            raise ValueError('Native count plus allowance was too small')
                    except BaseException:
                        self._halt('Response accounting, logging, or input bound check failed', attempt_id)
                        raise
                    return response['text'], response
            await asyncio.sleep(self.retry_delay * (attempt + 1))
        raise AssertionError('Unreachable retry state')

    async def episode(self, row, rounds=24):
        target = self.root / 'runs' / row['run_id']
        if target.exists() and any(target.iterdir()):
            raise ValueError('A saved run cannot be repeated or reused without a separate audit')
        target.mkdir(parents=True, exist_ok=True)
        episode = generate_episode(row['seed'], row['condition'])
        write_json(target / 'episode.json', episode)
        log = EventLog(target / 'events.jsonl', getattr(self.provider, 'secrets', ()))
        log.append('start', row=row, episode_hash=digest(episode), mode=self.provider.mode)
        history, turns = [], []
        status, error_message = 'complete', None
        counter = self.counters[row['model_id']]
        try:
            for number in range(1, rounds + 1):
                if self.stop: raise BudgetError('The study stopped after a prior failure')
                messages = build_messages(episode, history, number)
                count = counter.count(messages)
                if type(count) is not int or not 0 <= count <= INPUT_CAP:
                    raise ValueError('The complete input exceeds the fixed token cap')
                text, response = await self.request(row, number, messages, count, log)
                worker = strict_choice(text, episode)
                result = outcome(episode, number, worker) if worker else failure_outcome(
                    episode, number, 'transport_failure' if response is None else 'invalid_choice')
                turn = {'round': number, 'worker_id': worker, 'outcome': result if worker else None,
                        'invalid': worker is None, 'failure_reason': result['failure_reason']}
                turns.append(turn); history.append(result)
                log.append('outcome', **turn, feedback=result)
                write_json(target / 'checkpoint.json', {'row': row, 'turns': turns, 'mode': self.provider.mode,
                                                        'log_hash': log.previous})
        except Exception as error:
            status = 'incomplete'; error_message = f'{type(error).__name__}: {error}'
            self._halt('An episode failed before all planned turns completed')
            try:
                log.append('stopped', error=error_message)
            except Exception:
                # A damaged log must not trigger more writes or paid requests.
                pass
        # Probes end after four calls. They have no complete 24-round study score.
        scored = summarize_run(episode, turns, status if rounds == 24 else 'incomplete')
        scored.update(row)
        scored.update({'status': status, 'scheduled_rounds': rounds, 'mode': self.provider.mode,
                       'observed_turns': len(turns), 'valid_turns': sum(not t['invalid'] for t in turns),
                       'error': error_message, 'log_hash': log.previous})
        write_json(target / 'result.json', scored)
        return scored

    async def stage(self, rows, rounds=24):
        # Bound episode scheduling too, so a stop does not create every pending folder.
        episode_slots = asyncio.Semaphore(32)
        async def one(row):
            async with episode_slots:
                if self.stop: return None
                try:
                    result = await self.episode(row, rounds)
                    write_json(self.root / 'progress.json', {'last_run': row['run_id'], 'status': result['status'],
                                                           'ledger': self.ledger.snapshot()})
                    return result
                except BaseException:
                    self._halt('A stage record or score could not be completed')
                    raise
        # Drain in-flight requests so their usage is recorded before propagating an error.
        results = await asyncio.gather(*(one(row) for row in rows), return_exceptions=True)
        for result in results:
            if isinstance(result, BaseException): raise result
        return [r for r in results if r is not None]

    async def pipeline(self, main=True):
        probes = [{'run_id': f'probe_v1_2_{model}', 'phase': 'probe', 'model_id': model,
                   'seed': 0, 'condition': 'worker_objection'} for model in MODELS]
        probe_results = []
        for row in probes:
            if self.stop: break
            probe_results.append(await self.episode(row, rounds=4))
        probe_pass = len(probe_results) == 2 and all(r['status'] == 'complete' and r['valid_turns'] == 4 for r in probe_results)
        write_json(self.root / 'probes.json', {'passed': probe_pass, 'results': probe_results})
        if not probe_pass: return {'status': 'probe_failed', 'ledger': self.ledger.snapshot()}
        pilot = await self.stage([r for r in manifest() if r['phase'] == 'pilot'])
        pilot_pass = len(pilot) == 8
        for model in MODELS:
            group = [r for r in pilot if r['model_id'] == model]
            pilot_pass &= (len(group) == 4 and all(r['status'] == 'complete' for r in group)
                           and sum(r['valid_turns'] for r in group) >= math.ceil(96*.95))
        write_json(self.root / 'pilot.json', {'passed': bool(pilot_pass), 'results': pilot})
        if not pilot_pass or not main:
            return {'status': 'pilot_passed' if pilot_pass else 'pilot_failed', 'ledger': self.ledger.snapshot()}
        write_json(self.root / 'main_freeze.json', {'study_hash': digest(read_json(self.root/'study.json')),
                                                  'pilot_hash': digest(pilot), 'manifest_hash': digest(manifest())})
        main_results = await self.stage([r for r in manifest() if r['phase'] == 'main'])
        analysis = aggregate(main_results)
        write_json(self.root / 'analysis.json', analysis)
        write_json(self.root / 'results.json', main_results)
        return {'status': 'complete' if len(main_results)==160 and all(r['status']=='complete' for r in main_results) else 'incomplete',
                'main_runs': len(main_results), 'ledger': self.ledger.snapshot()}
