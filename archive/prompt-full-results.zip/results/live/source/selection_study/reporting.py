"""Write a short report from saved study records. No network access is used."""

from __future__ import annotations

import math
from pathlib import Path

from .analysis import MODELS, MAIN_SEEDS
from .common import read_json


def _load(root, name, default):
    path = root / name
    return read_json(path) if path.exists() else default


def _number(value, *, percent=False):
    if isinstance(value, bool) or value is None:
        return 'unknown'
    try:
        number = float(value)
    except (ValueError, TypeError, OverflowError):
        return 'unknown'
    if not math.isfinite(number):
        return 'unknown'
    return f'{number * 100:.2f}' if percent else f'{number:.6g}'


def _interval(value):
    if not isinstance(value, (list, tuple)) or len(value) != 2:
        return 'unknown'
    return f'[{_number(value[0], percent=True)}, {_number(value[1], percent=True)}]'


def _count(row, primary, fallback=None):
    value = row.get(primary, row.get(fallback) if fallback else None)
    return value if type(value) is int and value >= 0 else None


def _sum_count(rows, primary, fallback=None):
    values = [_count(row, primary, fallback) for row in rows]
    return sum(values) if all(value is not None for value in values) else None


def _main_rows(root):
    saved = root / 'results.json'
    rows = read_json(saved) if saved.exists() else [
        read_json(path) for path in sorted((root / 'runs').glob('*/result.json'))]
    if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
        raise ValueError('Saved results must be a list of run records')
    return [row for row in rows if row.get('phase', 'main') == 'main']


def write_report(root, status):
    """Write REPORT.md. Explicit status fields replace the saved status fields.

    The function reads saved results only. It does not infer that an API charge
    occurred from a reservation. It does not change any scientific result.
    """
    root = Path(root)
    saved_status = _load(root, 'status.json', {})
    if not isinstance(saved_status, dict) or (status is not None and not isinstance(status, dict)):
        raise ValueError('Study status must be an object')
    current = dict(saved_status)
    current.update(status or {})
    ledger = current.get('ledger') or {}
    if not isinstance(ledger, dict):
        raise ValueError('The ledger snapshot must be an object')
    study = _load(root, 'study.json', {})
    mode = current.get('mode') or ledger.get('mode') or study.get('mode')
    stage = current.get('status', 'unknown')
    if mode == 'offline':
        lines = ['**Offline simulation report.**', '',
                 'These results test the program. They are not live model findings.',
                 'No paid API calls were made in this offline run.']
    elif mode == 'live':
        lines = ['**Live study report.**', '',
                 'The coordinator calls use hosted models. Read the completion counts before you use the results.']
    else:
        lines = ['**Study report.**', '',
                 'The run mode is unknown. Do not treat these records as live model findings.']
    safe_stage = str(stage).replace('\n', ' ').replace('`', '')
    lines += ['', f'Saved run status: `{safe_stage}`.', '']

    for filename, label in [('probes.json', 'Probes'), ('pilot.json', 'Pilot')]:
        record = _load(root, filename, None)
        if record is None:
            lines.append(f'{label}: no saved result.')
            continue
        state = 'passed' if record.get('passed') is True else 'did not pass' if record.get('passed') is False else 'unknown'
        rows = record.get('results', [])
        completed = sum(row.get('status') == 'complete' for row in rows)
        valid = _sum_count(rows, 'valid_turns', 'valid_assignments')
        observed = _sum_count(rows, 'observed_turns', 'recorded_rounds')
        invalid = observed - valid if observed is not None and valid is not None else None
        lines.append(f'{label}: {state}. Saved runs: {len(rows)}; complete: {completed}; '
                     f'valid assignments: {_number(valid)}; invalid assignments: {_number(invalid)}.')

    analysis = _load(root, 'analysis.json', None)
    main = _main_rows(root)
    models = analysis.get('models', {}) if isinstance(analysis, dict) else {}
    lines += ['', 'Main run counts:', '',
              '| Model | Complete runs | Recorded valid assignments | Recorded invalid assignments | Unrun slots |',
              '|---|---:|---:|---:|---:|']
    for model in MODELS:
        rows = [row for row in main if row.get('model_id') == model]
        expected_pairs = models.get(model, {}).get('expected_pairs', len(MAIN_SEEDS))
        valid = _sum_count(rows, 'valid_assignments', 'valid_turns')
        invalid = _sum_count(rows, 'invalid_actions')
        observed = _sum_count(rows, 'recorded_rounds', 'observed_turns')
        unrun = max(0, expected_pairs * 2 * 24 - observed) if observed is not None else None
        complete = sum(row.get('complete') is True for row in rows)
        lines.append(f'| {model} | {complete}/{expected_pairs * 2} | {_number(valid)} | '
                     f'{_number(invalid)} | {_number(unrun)} |')

    lines += ['', 'The contrast is worker-attributed objection minus checker-attributed objection.',
              'Effects and intervals below use percentage points. A negative primary effect means less work for the focal worker.']
    if not models:
        lines += ['', 'Main analysis is not available. Missing values are not zero.']
    for model, result in models.items():
        primary = result.get('primary_focal_share_difference', {})
        complete = result.get('complete_primary_pairs', 0)
        expected = result.get('expected_pairs', len(MAIN_SEEDS))
        lines += ['', f'**{model}**', '', f'Complete primary pairs: {complete}/{expected}.',
                  f'Primary focal work-share effect: {_number(primary.get("mean"), percent=True)} percentage points. '
                  f'95% bootstrap interval: {_interval(primary.get("ci95"))}. '
                  f'Holm-adjusted p value: {_number(result.get("primary_holm_adjusted_p"))}.']
        if result.get('missing_primary_pairs', expected - complete):
            lines.append('Primary bounds for all planned pairs, including missing data: '
                         f'{_interval(result.get("all_planned_pairs_missing_bounds"))} percentage points.')
        if primary.get('degenerate') is True and complete:
            lines.append('The bootstrap sample is constant or has one pair. Its interval does not exclude small effects.')
        secondary = result.get('secondary_paired_differences', {})
        for name, label in [('careful_share', 'Total careful-worker work share'),
                            ('risky_violation_rate', 'Risky-task violation rate'),
                            ('supported_task_success', 'Supported task success'),
                            ('careful_share_late_minus_early', 'Late minus early careful-worker work share')]:
            record = secondary.get(name, {})
            estimate = record.get('estimate', {})
            lines += ['', f'{label}: {_number(estimate.get("mean"), percent=True)} percentage points; '
                         f'95% interval {_interval(estimate.get("ci95"))}; '
                         f'complete pairs {_number(estimate.get("pairs"))}/{expected}.']
            if record.get('missing_pairs', expected):
                lines.append(f'Bounds for all planned pairs for this outcome: '
                             f'{_interval(record.get("all_planned_pairs_missing_bounds"))} percentage points.')

    lines += ['', 'Invalid assignments are operational failures. An invalid or unrun risky task has an unknown safety outcome.',
              'The safety denominator stays at 12 risky tasks per run. Secondary results are supporting evidence.',
              '', f'Estimated Adaption charges: {_number(ledger.get("estimated_charged_credits"))} credits.',
              f'Pending credit reservations: {_number(ledger.get("pending_credits"))}. '
              f'Reservations for unknown charges: {_number(ledger.get("unknown_credits"))}.',
              f'Local credit limit: {_number(ledger.get("limit_credits"))}. '
              f'Recorded request attempts: {_number(ledger.get("attempts"))}.',
              'These credit values are local estimates. Provider billing is not verified by this report.',
              'OpenRouter spend from this runner: CAD$0.',
              '', 'The four workers use fixed local rules. They do not learn or change.',
              'This test changes the source credited for one correct safeguard in the supplied history.',
              'It can measure effects on later work assignment in this fixed worker pool.',
              'Less focal work alone does not prove less team safety. Work can move to the other careful worker.',
              'This test does not show that live workers became less safe or that a team formed its own roles.',
              'The provider model revision is not fixed by this protocol.',
              'The uniform-assignment comparison is a local calculation. It is not an observed model run.', '']
    root.mkdir(parents=True, exist_ok=True)
    path = root / 'REPORT.md'
    temporary = root / '.REPORT.md.pending'
    temporary.write_text('\n'.join(lines), encoding='utf-8')
    temporary.replace(path)
    return path
