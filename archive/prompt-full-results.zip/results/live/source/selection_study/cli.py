"""Run local checks, then the fixed Adaption study with an explicit paid switch."""
import argparse
import asyncio
from contextlib import ExitStack, closing
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import io
import os
from pathlib import Path
import shutil
import sqlite3
import sys
import unittest
from unittest.mock import patch

from .common import read_json, write_json, digest
from .ledger import CreditLedger
from .runner import Runner, OfflineProvider, manifest, MODELS
from .tokenization import NativeCounter
from .transport import AdaptionProvider, MODEL_PRICES, TransportError

BASE = Path(__file__).resolve().parents[1]


def source_hashes():
    files = list((BASE / 'selection_study').glob('*.py')) + list((BASE / 'tests').glob('*.py'))
    files += [BASE / name for name in ('PROTOCOL.md', 'AMENDMENT-1.1.md', 'AMENDMENT-1.2.md',
                                      'requirements.txt', 'key_prompt.py', 'diagnose_adaption.py')]
    return {str(path.relative_to(BASE)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(files) if path.is_file()}


def verify():
    """Run the complete test suite with all socket connections disabled."""
    stream = io.StringIO()
    suite = unittest.defaultTestLoader.discover(str(BASE / 'tests'))
    with ExitStack() as stack:
        stack.enter_context(patch('socket.create_connection', side_effect=AssertionError('Network disabled')))
        stack.enter_context(patch('socket.socket.connect', side_effect=AssertionError('Network disabled')))
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    report = {'passed': result.wasSuccessful() and not result.skipped,
              'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
              'skipped': len(result.skipped), 'network_blocked': True, 'paid_calls': 0,
              'source_hashes': source_hashes(), 'log': stream.getvalue(),
              'python': sys.version, 'time_utc': datetime.now(timezone.utc).isoformat()}
    write_json(BASE / 'offline_test_report.json', report)
    print(stream.getvalue(), end='')
    return 0 if report['passed'] else 1


def counters():
    result = {model: NativeCounter(model, BASE / 'tokenizers' / key)
              for model, key in zip(MODELS, ('qwen', 'glm'))}
    verified = read_json(BASE / 'tokenizers' / 'verification.json')
    if not verified.get('network_blocked') or verified.get('paid_calls') != 0:
        raise ValueError('The native tokenizer check is missing')
    for key, model in zip(('qwen', 'glm'), MODELS):
        if verified['models'][key]['counter'] != result[model].name:
            raise ValueError('The native tokenizer check is stale')
    return result


def require_offline_checks():
    report = read_json(BASE / 'offline_test_report.json')
    if not report.get('passed') or report.get('source_hashes') != source_hashes():
        raise ValueError('Run the offline checks after the last source change')


async def execute(args):
    if args.amend_failed_probes:
        raise ValueError('The v1.0 amendment command is retired. Its recorded v1.1 source is retained')
    require_offline_checks()
    native = counters()
    root = args.result_root.resolve()
    amend_control = getattr(args, 'amend_reasoning_control', False)
    if amend_control and (args.mode != 'live' or not root.is_dir()):
        raise ValueError('The amendment needs an existing live study')
    if root.exists() and any(root.iterdir()) and not amend_control:
        raise ValueError('This result folder already has data. Automatic repeat calls are disabled')
    if args.mode == 'live':
        if not args.execute_paid:
            raise ValueError('Live inference requires --execute-paid')
        if args.available_credits < 100:
            raise ValueError('The reported credit balance is below the fixed study limit')
        # Read once. Never put the key in an argument, log, source file, or report.
        if args.key_receipt:
            from key_prompt import receive_key
            key = receive_key(args.key_receipt)
        else:
            key = os.environ.get('ADAPTION_API_KEY')
        provider = AdaptionProvider(key)
        key = None
        catalog = await asyncio.to_thread(provider.list_models)
        if not set(MODELS).issubset({item['id'] for item in catalog['data']}):
            raise ValueError('A required hosted model is not available to this key')
    else:
        provider = OfflineProvider()
        catalog = {'object': 'list', 'data': [], 'offline': True}
    amendment = None
    if amend_control:
        old = read_json(root / 'study.json')
        old_status = read_json(root / 'status.json')
        old_probes = read_json(root / 'probes.json')
        if (old.get('protocol') != 'selection-1.1' or old.get('mode') != 'live'
                or old_status.get('status') != 'probe_failed' or old_probes.get('passed') is not False
                or (root/'pilot.json').exists() or (root/'main_freeze.json').exists()):
            raise ValueError('Only the failed v1.1 probes can use this amendment')
        for name, expected in old['source_hashes'].items():
            if hashlib.sha256((root/'source'/name).read_bytes()).hexdigest() != expected:
                raise ValueError('An initial source record changed before the amendment')
        diagnostic_root = args.diagnostic_root.resolve()
        diagnostic_journal = read_json(diagnostic_root/'budget.json')
        archive = root / 'amendments' / 'v1_1'
        archive.mkdir(parents=True)
        for path in root.iterdir():
            if path.is_file() and path.suffix in ('.json', '.md'):
                shutil.copy2(path, archive/path.name)
        shutil.copytree(root/'source', archive/'source')
        shutil.copytree(diagnostic_root, archive/'diagnostics')
        with closing(sqlite3.connect(root/'credits.sqlite')) as before, \
                closing(sqlite3.connect(archive/'credits.sqlite')) as backup:
            before.backup(backup)
        receipt = CreditLedger.amend_control_ready(root/'credits.sqlite', diagnostic_root/'budget.json')
        amendment = {'from_protocol': 'selection-1.1', 'to_protocol': 'selection-1.2',
                     'approved_limit_credits': 100,
                     'user_choice': 'keep trying to fix and make the adaption api work',
                     'previous_study_hash': digest(old), 'previous_probes_hash': digest(old_probes),
                     'previous_status_hash': digest(old_status), 'ledger_receipt': receipt,
                     'diagnostic_journal_hash': digest(diagnostic_journal),
                     'preserved_probe_runs': {r['run_id']:r['log_hash'] for r in old_probes['results']}}
    else:
        root.mkdir(parents=True)
    write_json(root / 'model_catalog.json', catalog)
    config = {'protocol': 'selection-1.2', 'mode': args.mode, 'models': list(MODELS),
              'started_utc': datetime.now(timezone.utc).isoformat(),
              'source_hashes': source_hashes(), 'model_prices': MODEL_PRICES,
              'reported_available_adaption_credits': args.available_credits,
              'limit_adaption_credits': 100, 'actual_billing_verified': False,
              'input_cap': 6000, 'output_cap': 4000, 'temperature': .7,
              'inference_concurrency': 16, 'reasoning_setting': 'requested_none_reported_zero_required',
              'reasoning_request': {'effort': 'none'},
              'deployment_revision': 'not_pinned_or_verified',
              'token_counters': {model: native[model].name for model in MODELS},
              'libraries': {name: importlib.metadata.version(name)
                            for name in ('transformers', 'tokenizers', 'jinja2', 'certifi')},
              'pricing_source': 'https://docs.adaptionlabs.ai/inference-stacks/models/',
              'openrouter_calls': 0, 'openrouter_spend_cad': 0}
    if amendment:
        config['previous_study_hash'] = amendment['previous_study_hash']
        config['ledger_control_amendment'] = amendment['ledger_receipt']
    write_json(root / 'study.json', config)
    if amendment:
        amendment['current_study_hash'] = digest(config)
        write_json(root/'amendments/v1_1/amendment.json', amendment)
        # Exact prior copies are now in the archive. Do not present them as current.
        for name in ('probes.json', 'REPORT.md', 'PROBE_REPORT.md', 'audit.json'):
            (root/name).unlink(missing_ok=True)
    write_json(root / 'manifest.json', manifest())
    write_json(root / 'offline_test_report.json', read_json(BASE / 'offline_test_report.json'))
    write_json(root / 'tokenizer_verification.json', read_json(BASE / 'tokenizers' / 'verification.json'))
    for name in source_hashes():
        target = root / 'source' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(BASE / name, target)
    runner = Runner(root, provider, native, limit='100', concurrency=16)
    initial_status = {'status': 'running', 'mode': args.mode, 'ledger': runner.ledger.snapshot()}
    write_json(root / 'status.json', initial_status)
    from .reporting import write_report
    write_report(root, initial_status)
    try:
        status = await runner.pipeline(main=not args.pilot_only)
    except BaseException:
        runner.stop = True
        runner.ledger.freeze('The process stopped before the planned end')
        status = {'status': 'interrupted', 'ledger': runner.ledger.snapshot()}
        write_json(root / 'status.json', {**status, 'mode': args.mode})
        raise
    status.update({'mode': args.mode, 'result_root': str(root),
                   'finished_utc': datetime.now(timezone.utc).isoformat()})
    write_json(root / 'status.json', status)
    write_report(root, status)
    print(__import__('json').dumps(status, sort_keys=True))
    return 0 if status['status'] in ('complete', 'pilot_passed') else 1


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('verify')
    run = sub.add_parser('run')
    run.add_argument('--mode', choices=('offline', 'live'), default='offline')
    run.add_argument('--execute-paid', action='store_true')
    run.add_argument('--key-receipt', type=Path)
    run.add_argument('--available-credits', type=int, default=4500)
    run.add_argument('--result-root', type=Path, required=True)
    run.add_argument('--pilot-only', action='store_true')
    run.add_argument('--amend-failed-probes', action='store_true')
    run.add_argument('--amend-reasoning-control', action='store_true')
    run.add_argument('--diagnostic-root', type=Path, default=BASE/'results'/'diagnostics')
    args = parser.parse_args(argv)
    try:
        return verify() if args.command == 'verify' else asyncio.run(execute(args))
    except (ValueError, OSError, RuntimeError, KeyError) as error:
        # These classes contain our controlled errors. Never print request objects.
        print(f'Study stopped: {type(error).__name__}: {error}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
