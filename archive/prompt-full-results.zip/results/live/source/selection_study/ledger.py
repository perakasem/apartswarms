"""Atomic credit reservations. Charges remain estimates until billing is checked."""

from contextlib import contextmanager
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
import hashlib
import fcntl
import json
from pathlib import Path
import sqlite3
import re

from .transport import MODEL_PRICES, maximum_call_cost, estimate_credit_charge, validate_usage


QUOTAS = {'main': 1920, 'pilot': 96, 'probe': 12, 'diagnostic': 20}
RETRY_LIMIT = 100
MAX_ATTEMPTS = 4276


class BudgetError(RuntimeError):
    pass


def money(value):
    if isinstance(value, bool):
        raise ValueError('The credit amount is invalid')
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ValueError('The credit amount is invalid') from None
    if not result.is_finite() or result < 0:
        raise ValueError('The credit amount must be finite and nonnegative')
    return result


def _record_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def _strict_json(text):
    def reject(value):
        raise BudgetError('The diagnostic record has a non-finite JSON value')
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise BudgetError('The diagnostic record has a duplicate JSON key')
            result[key] = value
        return result
    return json.loads(text, parse_constant=reject, object_pairs_hook=unique)


def _diagnostic_import(path, main_root, main_hash, main_committed):
    """Check the diagnostic journal and its successful technical results."""
    content = path.read_bytes()
    journal = _strict_json(content)
    settings = journal.get('settings', {})
    source = Path(__file__).resolve().parents[1] / 'diagnose_adaption.py'
    expected = {'schema': 'adaption-diagnostics-1', 'currency': 'adaption_credits',
                'diagnostic_limit_credits': '1', 'global_limit_credits': '100',
                'max_attempts': 20, 'main_root': str(main_root), 'model_prices': MODEL_PRICES,
                'reservation_by_model': {model: str(maximum_call_cost(model)) for model in MODEL_PRICES},
                'output_cap': 256, 'input_cap': 6000,
                'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
                'carry_into_main_before_resume': True}
    if settings != expected or not isinstance(journal.get('events'), list):
        raise BudgetError('The diagnostic journal settings do not match the approved checks')
    attempts, previous = {}, None
    for number, original in enumerate(journal['events'], 1):
        event = dict(original)
        saved_hash = event.pop('hash')
        if event['sequence'] != number or event['previous'] != previous or _record_hash(event) != saved_hash:
            raise BudgetError('The diagnostic journal hash check failed')
        previous = saved_hash
        attempt_id, kind = event.get('attempt_id'), event['kind']
        if kind == 'reserve':
            model = event.get('model')
            if (model not in MODEL_PRICES or not isinstance(attempt_id, str)
                    or not re.fullmatch(r'[A-Za-z0-9_.-]{1,180}', attempt_id)
                    or not attempt_id.endswith('__' + model) or attempt_id in attempts
                    or money(event['reserved_credits']) != maximum_call_cost(model)):
                raise BudgetError('A diagnostic reservation is invalid or repeated')
            account = event.get('main_account', {})
            if (account.get('root') != str(main_root) or account.get('ledger_hash') != main_hash
                    or money(account.get('committed_credits')) != main_committed):
                raise BudgetError('The diagnostic used a different main ledger state')
            attempts[attempt_id] = {'id': 'diagnostic__' + attempt_id, 'model': model,
                'phase': 'diagnostic', 'retry': 0, 'reserved': event['reserved_credits'],
                'status': 'unknown', 'estimated_charge': None, 'usage': None,
                'source_pending': True}
        elif kind in ('settle', 'unknown'):
            item = attempts.get(attempt_id)
            if item is None or not item['source_pending']:
                raise BudgetError('A diagnostic settlement has no pending reservation')
            item['source_pending'] = False
            if kind == 'settle':
                usage = validate_usage(event.get('usage'), enforce_caps=False)
                charge = money(event['estimated_credits'])
                if (usage['input_tokens'] > 6000 or usage['output_tokens'] > 256
                        or charge != estimate_credit_charge(item['model'], usage)
                        or charge > money(item['reserved'])):
                    raise BudgetError('A diagnostic settlement exceeds its limits or price')
                item.update(status='settled', estimated_charge=event['estimated_credits'],
                            usage=json.dumps({key: usage[key] for key in
                                              ('input_tokens', 'output_tokens', 'total_tokens')}, sort_keys=True),
                            source_usage=usage, request_id=event.get('request_id'))
        else:
            raise BudgetError('A frozen or unsupported diagnostic journal cannot enable the study')
    if not 2 <= len(attempts) <= 20:
        raise BudgetError('The diagnostic attempt count is outside the approved range')
    charged = sum((money(item['estimated_charge']) for item in attempts.values()
                   if item['status'] == 'settled'), Decimal(0))
    unknown = sum((money(item['reserved']) for item in attempts.values()
                   if item['status'] != 'settled'), Decimal(0))
    if charged + unknown > 1 or main_committed + charged + unknown > 100:
        raise BudgetError('The diagnostic carry would exceed a credit limit')
    from .environment import generate_episode, build_messages
    episode = generate_episode(0, 'worker_objection')
    messages = build_messages(episode, [], 1)
    ready, record_hashes = {}, {}
    for source_id, item in attempts.items():
        if item['status'] != 'settled':
            continue
        folder = path.parent / 'attempts' / source_id
        records = {}
        for name in ('request.json', 'raw_response.json', 'result.json'):
            record = (folder / name).read_bytes()
            record_hashes[str((folder / name).relative_to(path.parent))] = hashlib.sha256(record).hexdigest()
            records[name] = _strict_json(record)
        request, raw, result = (records[name] for name in ('request.json', 'raw_response.json', 'result.json'))
        if (raw.get('model') != item['model'] or raw.get('id') != item['request_id']
                or not isinstance(item['request_id'], str) or not item['request_id']
                or raw.get('usage') != item['source_usage'] or result.get('usage') != item['source_usage']
                or result.get('request_id') != item['request_id']
                or money(result.get('estimated_credits')) != money(item['estimated_charge'])):
            raise BudgetError('A diagnostic response differs from its accounting record')
        if request.get('variant') != 'reasoning_none':
            continue
        body = {'model': item['model'], 'input': messages, 'tools': [], 'tool_choice': 'none',
                'agentic_memory': False, 'store': False, 'stream': False, 'temperature': .7,
                'max_output_tokens': 256, 'reasoning': {'effort': 'none'}}
        try:
            choice = _strict_json(raw.get('output_text', ''))
        except (ValueError, TypeError):
            choice = None
        if (request.get('body') != body or request.get('seed') != 0 or request.get('round') != 1
                or type(request.get('input_bound')) is not int
                or not item['source_usage']['input_tokens'] <= request['input_bound'] <= 6000
                or raw.get('status') != 'completed' or raw.get('error')
                or not isinstance(raw.get('reasoning'), dict) or raw['reasoning'].get('effort') != 'none'
                or (item['source_usage'].get('output_tokens_details') or {}).get('reasoning_tokens') != 0
                or result.get('completed_valid_choice') is not True
                or not isinstance(choice, dict) or set(choice) != {'worker_id'}
                or choice['worker_id'] not in episode['worker_ids']):
            continue
        ready[item['model']] = source_id
    if set(ready) != set(MODEL_PRICES):
        raise BudgetError('Both models need a valid completed diagnostic with disabled reasoning')
    imported = [{key: item[key] for key in ('id', 'model', 'phase', 'retry', 'reserved',
                                           'status', 'estimated_charge', 'usage')}
                for item in attempts.values()]
    return imported, {'journal_sha256': hashlib.sha256(content).hexdigest(),
                      'journal_chain_hash': previous, 'diagnostic_source_sha256': settings['source_sha256'],
                      'event_hashes': [event['hash'] for event in journal['events']],
                      'record_sha256': record_hashes, 'ready_attempts_by_model': ready,
                      'estimated_charged_credits': str(charged), 'unknown_credits': str(unknown),
                      'committed_credits': str(charged + unknown), 'attempts': len(imported)}


class CreditLedger:
    def __init__(self, path, limit_credits='65', mode='live'):
        self.path = Path(path)
        self.limit = money(limit_credits)
        self.mode = mode
        if mode not in ('live', 'offline') or self.limit <= 0 or self.limit > 100:
            raise ValueError('Use live or offline mode and a credit limit above zero and at most 100')
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._transaction() as db:
            db.execute('CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL)')
            db.execute('CREATE TABLE IF NOT EXISTS attempts (id TEXT PRIMARY KEY, model TEXT NOT NULL, phase TEXT NOT NULL, retry INTEGER NOT NULL, reserved TEXT NOT NULL, status TEXT NOT NULL, estimated_charge TEXT, usage TEXT)')
            expected = {'mode': mode, 'limit_credits': str(self.limit.normalize()),
                        'currency': 'adaption_credits', 'prices': json.dumps(MODEL_PRICES, sort_keys=True),
                        'quotas': json.dumps(QUOTAS, sort_keys=True), 'retry_limit': str(RETRY_LIMIT),
                        'max_attempts': str(MAX_ATTEMPTS)}
            for key, value in expected.items():
                row = db.execute('SELECT value FROM metadata WHERE key=?', (key,)).fetchone()
                if row and row[0] != value:
                    raise BudgetError('The ledger settings differ from the saved study')
                db.execute('INSERT OR IGNORE INTO metadata VALUES (?,?)', (key, value))
            db.execute("INSERT OR IGNORE INTO metadata VALUES ('frozen_reason','')")

    @classmethod
    def amend_failed_probes(cls, path):
        """Apply the approved v1.1 limit change to a settled v1 probe ledger.

        The caller must stop the old runner and hold the study lock. This method
        does not make requests and does not change or remove attempt records.
        The saved receipt is the durable record if the caller stops after commit.
        """
        ledger = object.__new__(cls)
        ledger.path = Path(path)
        if not ledger.path.is_file():
            raise BudgetError('The prior probe ledger does not exist')
        receipt_key = 'amendment_failed_probes_v1_1'
        old_settings = {
            'mode': 'live', 'limit_credits': '65', 'currency': 'adaption_credits',
            'prices': json.dumps(MODEL_PRICES, sort_keys=True),
            'quotas': json.dumps({'main': 1920, 'pilot': 96, 'probe': 4}, sort_keys=True),
            'retry_limit': '100', 'max_attempts': '4240', 'frozen_reason': '',
        }
        with ledger._transaction() as db:
            saved = dict(db.execute('SELECT key,value FROM metadata').fetchall())
            if (receipt_key in saved or any(saved.get(key) != value
                                          for key, value in old_settings.items())):
                raise BudgetError('Only the unchanged live v1 probe ledger can be amended')
            rows = [dict(row) for row in db.execute('SELECT * FROM attempts ORDER BY rowid')]
            if not rows or len(rows) > 4240:
                raise BudgetError('The ledger has no completed probe attempts or too many attempts')
            for row in rows:
                if (row['model'] not in MODEL_PRICES or row['phase'] != 'probe'
                        or row['status'] != 'settled' or row['retry'] not in (0, 1)):
                    raise BudgetError('Only settled probe attempts can be amended')
                try:
                    charge, reserved = money(row['estimated_charge']), money(row['reserved'])
                except (ValueError, TypeError):
                    raise BudgetError('Every prior probe needs a known charge') from None
                if charge > reserved:
                    raise BudgetError('A prior probe charge exceeds its reservation')
            old_phases = ('main', 'pilot', 'probe')
            counts = {model: {
                'primary_by_phase': {phase: sum(row['model'] == model and row['phase'] == phase
                                               and not row['retry'] for row in rows)
                                     for phase in old_phases},
                'retries': sum(row['model'] == model and row['retry'] for row in rows),
            } for model in MODEL_PRICES}
            if any(group['primary_by_phase']['probe'] > 4 or group['retries'] > RETRY_LIMIT
                   for group in counts.values()):
                raise BudgetError('The prior probe or retry count exceeds the v1 limit')
            charges, pending, unknown = ledger._totals(rows)
            if charges > Decimal('65') or pending or unknown:
                raise BudgetError('The prior ledger charge is not within the v1 limit')
            new_settings = dict(old_settings, limit_credits=str(Decimal('100').normalize()),
                                quotas=json.dumps({'main': 1920, 'pilot': 96, 'probe': 8}, sort_keys=True),
                                max_attempts='4248')
            attempt_hash = hashlib.sha256(json.dumps(rows, sort_keys=True, separators=(',', ':'),
                                                     ensure_ascii=False, allow_nan=False).encode()).hexdigest()
            account = {'attempts': len(rows), 'counts': counts,
                       'estimated_charged_credits': str(charges),
                       'pending_credits': str(pending), 'unknown_credits': str(unknown),
                       'attempt_records_sha256': attempt_hash}
            receipt = {
                'amendment_id': 'failed_probes_v1_1',
                'created_at': datetime.now(timezone.utc).isoformat(),
                'reason': 'Approved output allowance increase after failed v1 probes',
                'before': {'settings': old_settings, 'output_cap': 2000, **account},
                'after': {'settings': new_settings, 'output_cap': 4000, **account},
                'attempt_records_unchanged': True, 'actual_billing_verified': False,
            }
            for key in ('limit_credits', 'quotas', 'max_attempts'):
                db.execute('UPDATE metadata SET value=? WHERE key=?', (new_settings[key], key))
            db.execute('INSERT INTO metadata VALUES (?,?)',
                       (receipt_key, json.dumps(receipt, sort_keys=True, allow_nan=False)))
        return receipt

    @classmethod
    def amend_control_ready(cls, path, diagnostic_budget_path):
        """Carry all diagnostic costs and enable the checked v1.2 controls.

        The caller must stop the study runner. The diagnostic directory lock
        prevents concurrent diagnostic writes throughout this transaction.
        """
        ledger = object.__new__(cls)
        ledger.path = Path(path).resolve()
        diagnostic_path = Path(diagnostic_budget_path).resolve()
        if not ledger.path.is_file() or not diagnostic_path.is_file():
            raise BudgetError('The main ledger or diagnostic journal does not exist')
        old_settings = {'mode': 'live', 'limit_credits': str(Decimal('100').normalize()),
            'currency': 'adaption_credits', 'prices': json.dumps(MODEL_PRICES, sort_keys=True),
            'quotas': json.dumps({'main': 1920, 'pilot': 96, 'probe': 8}, sort_keys=True),
            'retry_limit': '100', 'max_attempts': '4248', 'frozen_reason': ''}
        receipt_key = 'amendment_control_ready_v1_2'
        with (diagnostic_path.parent / '.diagnostic.lock').open('r') as lock:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise BudgetError('A diagnostic process is still active') from None
            try:
                with ledger._transaction() as db:
                    saved = dict(db.execute('SELECT key,value FROM metadata').fetchall())
                    if (receipt_key in saved or any(saved.get(key) != value
                                                  for key, value in old_settings.items())):
                        raise BudgetError('Only the unchanged live v1.1 probe ledger can be amended')
                    old_rows = [dict(row) for row in db.execute('SELECT * FROM attempts ORDER BY rowid')]
                    if not old_rows:
                        raise BudgetError('The main ledger has no prior probes')
                    for row in old_rows:
                        if (row['model'] not in MODEL_PRICES or row['phase'] != 'probe'
                                or row['status'] not in ('settled', 'unknown') or row['retry'] not in (0, 1)):
                            raise BudgetError('Only completed or unknown prior probes can be carried')
                        reserved = money(row['reserved'])
                        if reserved <= 0 or (row['status'] == 'settled' and money(row['estimated_charge']) > reserved):
                            raise BudgetError('A prior probe has an invalid charge or reservation')
                    for model in MODEL_PRICES:
                        group = [row for row in old_rows if row['model'] == model]
                        if sum(not row['retry'] for row in group) > 8 or sum(row['retry'] for row in group) > 100:
                            raise BudgetError('The prior probe or retry count exceeds v1.1 limits')
                    old_totals = ledger._totals(old_rows)
                    main_hash = _record_hash({'metadata': saved, 'attempts': old_rows})
                    imported, diagnostic_receipt = _diagnostic_import(
                        diagnostic_path, ledger.path.parent, main_hash, sum(old_totals))
                    if {row['id'] for row in old_rows} & {row['id'] for row in imported}:
                        raise BudgetError('A diagnostic attempt identifier is already in the main ledger')
                    all_rows = old_rows + imported
                    if len(all_rows) > MAX_ATTEMPTS or sum(ledger._totals(all_rows)) > 100:
                        raise BudgetError('The combined ledger would exceed its limits')
                    new_settings = dict(old_settings, quotas=json.dumps(QUOTAS, sort_keys=True),
                                        max_attempts=str(MAX_ATTEMPTS))
                    def account(rows, settings):
                        charges, pending, unknown = ledger._totals(rows)
                        return {'settings': settings, 'attempts': len(rows),
                            'attempt_records_sha256': _record_hash(rows),
                            'estimated_charged_credits': str(charges), 'pending_credits': str(pending),
                            'unknown_credits': str(unknown), 'committed_credits': str(charges + pending + unknown),
                            'counts': {model: {'primary_by_phase': {
                                phase: sum(row['model'] == model and row['phase'] == phase and not row['retry']
                                           for row in rows) for phase in QUOTAS},
                                'retries': sum(row['model'] == model and row['retry'] for row in rows)}
                                       for model in MODEL_PRICES}}
                    receipt = {'amendment_id': 'control_ready_v1_2',
                        'created_at': datetime.now(timezone.utc).isoformat(),
                        'before': account(old_rows, old_settings), 'after': account(all_rows, new_settings),
                        'old_attempt_records_unchanged': True, 'old_metadata_sha256': _record_hash(saved),
                        'diagnostics': diagnostic_receipt,
                        'imported_attempt_ids': [row['id'] for row in imported],
                        'reasoning': {'effort': 'none'}, 'required_reasoning_tokens': 0,
                        'source_sha256': {name: hashlib.sha256((Path(__file__).parent / name).read_bytes()).hexdigest()
                                          for name in ('ledger.py', 'transport.py')},
                        'actual_billing_verified': False}
                    for row in imported:
                        db.execute('INSERT INTO attempts VALUES (?,?,?,?,?,?,?,?)',
                                   tuple(row[key] for key in ('id', 'model', 'phase', 'retry', 'reserved',
                                                             'status', 'estimated_charge', 'usage')))
                    for key in ('quotas', 'max_attempts'):
                        db.execute('UPDATE metadata SET value=? WHERE key=?', (new_settings[key], key))
                    db.execute('INSERT INTO metadata VALUES (?,?)',
                               (receipt_key, json.dumps(receipt, sort_keys=True, allow_nan=False)))
                return receipt
            finally:
                fcntl.flock(lock, fcntl.LOCK_UN)

    @contextmanager
    def _transaction(self):
        db = sqlite3.connect(self.path, timeout=30, isolation_level=None)
        db.row_factory = sqlite3.Row
        try:
            db.execute('PRAGMA journal_mode=WAL')
            db.execute('PRAGMA synchronous=FULL')
            db.execute('BEGIN IMMEDIATE')
            yield db
            db.execute('COMMIT')
        except BaseException:
            if db.in_transaction:
                db.execute('ROLLBACK')
            raise
        finally:
            db.close()

    @staticmethod
    def _freeze(db, reason):
        db.execute("UPDATE metadata SET value=? WHERE key='frozen_reason'", (str(reason),))

    @staticmethod
    def _totals(rows):
        charges = sum((money(row['estimated_charge']) for row in rows if row['status'] == 'settled'), Decimal(0))
        pending = sum((money(row['reserved']) for row in rows if row['status'] == 'pending'), Decimal(0))
        unknown = sum((money(row['reserved']) for row in rows if row['status'] == 'unknown'), Decimal(0))
        return charges, pending, unknown

    def reserve(self, attempt_id, model_id, phase, amount, is_retry=False):
        reserved = money(amount)
        if (not isinstance(attempt_id, str) or not attempt_id or len(attempt_id) > 500
                or model_id not in MODEL_PRICES or phase not in QUOTAS or type(is_retry) is not bool):
            raise ValueError('The reservation identity is invalid')
        if self.mode == 'live' and reserved != maximum_call_cost(model_id):
            raise ValueError('A live request needs the full fixed reservation')
        if self.mode == 'offline' and reserved != 0:
            raise ValueError('An offline request must have a zero reservation')
        with self._transaction() as db:
            if db.execute("SELECT value FROM metadata WHERE key='frozen_reason'").fetchone()[0]:
                raise BudgetError('The ledger is frozen')
            rows = db.execute('SELECT * FROM attempts').fetchall()
            if any(row['id'] == attempt_id for row in rows):
                raise BudgetError('The request attempt already exists')
            if len(rows) >= MAX_ATTEMPTS:
                raise BudgetError('The total request limit was reached')
            if phase == 'diagnostic' and sum(row['phase'] == 'diagnostic' for row in rows) >= QUOTAS['diagnostic']:
                raise BudgetError('The shared diagnostic request limit was reached')
            group = [r for r in rows if r['model'] == model_id]
            used = sum(r['retry'] for r in group) if is_retry else sum(r['phase'] == phase and not r['retry'] for r in group)
            quota = RETRY_LIMIT if is_retry else QUOTAS[phase]
            if used >= quota:
                raise BudgetError('The phase or retry limit was reached')
            if sum(self._totals(rows)) + reserved > self.limit:
                raise BudgetError('The credit limit would be exceeded')
            db.execute('INSERT INTO attempts VALUES (?,?,?,?,?,?,?,?)',
                       (attempt_id, model_id, phase, int(is_retry), str(reserved), 'pending', None, None))
        return attempt_id

    def settle(self, attempt_id, estimated_charge, usage=None):
        charge = money(estimated_charge)
        if self.mode == 'offline' and charge != 0:
            raise BudgetError('An offline request cannot have a charge')
        overrun = False
        with self._transaction() as db:
            row = db.execute('SELECT * FROM attempts WHERE id=?', (attempt_id,)).fetchone()
            if not row or row['status'] == 'settled':
                raise BudgetError('The attempt is missing or already settled')
            # Save only accounting fields, never response text or credentials.
            safe = None
            if usage is not None:
                safe = {key: usage[key] for key in ('input_tokens', 'output_tokens', 'total_tokens') if key in usage}
                if any(type(value) is not int or value < 0 for value in safe.values()):
                    raise ValueError('Token usage fields must be nonnegative integers')
            db.execute("UPDATE attempts SET status='settled',estimated_charge=?,usage=? WHERE id=?",
                       (str(charge), json.dumps(safe, sort_keys=True), attempt_id))
            overrun = charge > money(row['reserved']) or sum(self._totals(db.execute('SELECT * FROM attempts').fetchall())) > self.limit
            if overrun:
                self._freeze(db, 'Estimated credits exceeded the fixed reservation')
        if overrun:
            raise BudgetError('The charge was recorded and the ledger was frozen')

    def mark_unknown(self, attempt_id, reason='The request charge is unknown', *, freeze=True):
        with self._transaction() as db:
            row = db.execute('SELECT status FROM attempts WHERE id=?', (attempt_id,)).fetchone()
            if not row or row[0] == 'settled':
                raise BudgetError('The attempt is missing or already settled')
            db.execute("UPDATE attempts SET status='unknown' WHERE id=?", (attempt_id,))
            if freeze:
                self._freeze(db, reason)

    def freeze(self, reason):
        with self._transaction() as db:
            self._freeze(db, reason)

    def records(self):
        with self._transaction() as db:
            return [dict(row) for row in db.execute('SELECT * FROM attempts ORDER BY rowid')]

    def snapshot(self):
        with self._transaction() as db:
            rows = db.execute('SELECT * FROM attempts').fetchall()
            charges, pending, unknown = self._totals(rows)
            reason = db.execute("SELECT value FROM metadata WHERE key='frozen_reason'").fetchone()[0]
            counts = {model: {'primary_by_phase': {phase: sum(r['model'] == model and r['phase'] == phase and not r['retry'] for r in rows)
                                                   for phase in QUOTAS},
                              'retries': sum(r['model'] == model and r['retry'] for r in rows)} for model in MODEL_PRICES}
            return {'currency': 'adaption_credits', 'mode': self.mode, 'limit_credits': str(self.limit),
                    'estimated_charged_credits': str(charges), 'pending_credits': str(pending),
                    'unknown_credits': str(unknown), 'committed_credits': str(charges + pending + unknown),
                    'remaining_credits': str(self.limit - charges - pending - unknown),
                    'attempts': len(rows), 'frozen': bool(reason), 'frozen_reason': reason,
                    'counts': counts, 'actual_billing_verified': False}


BudgetLedger = CreditLedger
