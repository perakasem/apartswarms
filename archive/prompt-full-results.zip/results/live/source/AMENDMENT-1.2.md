**Technical amendment: selection-1.1 to selection-1.2.**

This amendment was selected before any pilot or main call. The user approved continued work on the Adaption route. The existing total limit stays at 100 Adaption credits. The main sample stays at 40 paired task seeds per model.

The first two probe stages did not pass. The larger 4,000-token output limit did not prevent Qwen output exhaustion. The later stage also had HTTP 504 errors. Across both stages, the ledger has 20 attempts, including four retries. Fifteen attempts have known usage. Five have unknown charges and keep their full reservations. These are technical failures. They are not results for the primary research question.

Two separate technical diagnostics tested only `reasoning={"effort":"none"}`. One call went to each model. Both completed in about 0.55 seconds, returned valid worker-choice JSON, returned `reasoning.effort="none"`, and reported zero reasoning tokens. Their input counts matched the checked native templates with thinking disabled: 1,118 tokens for Qwen and 1,045 for GLM. These short checks support the next technical test. They do not establish performance with a full history or simultaneous requests.

Version 1.2 sets `reasoning={"effort":"none"}` on every study request. A response must return the same effort setting and report zero reasoning tokens. Missing or different control evidence stops new calls. The runner does not extract a worker choice from hidden reasoning or use an extra formatting call.

The two model IDs, temperature, prompt text, worker rules, task matrix, task seeds, condition order, scorer, primary outcome, and statistical tests stay the same. The input limit stays at 6,000 tokens. The output limit stays at 4,000 tokens. Calls remain non-streaming. At most 16 requests and 32 episodes can be active. The pilot has only eight episodes and can have at most eight requests at once.

The reasoning setting is a model operating condition. It can change worker selection. Apply it to both conditions and both models. Report results as results for this setting. Do not combine earlier probes with the main outcome sample. No change was selected from the direction of an observed safety effect.

After the local tests, run four new sequential probe turns per model. Use `probe_v1_2_<model>` for these records. All eight new probe turns must pass. Then run the complete pilot: two separate pilot seeds in both conditions for each model, with all 24 tasks and the full growing history. This is 192 pilot calls in total. The pilot must meet the existing completeness and 95% valid-output rules. It must also pass the input, output, identity, usage, and reasoning-control checks. Save the main freeze only after the pilot passes. The main sample stays unchanged.

The study allowance is now 2,128 attempts per model: 1,920 main calls, 96 pilot calls, 12 probes across all versions, and 100 retry attempts. The old two retries per model count toward the 100. The study ceiling is 4,256 attempts, including all 20 old study attempts. At the full token limits, the base ceiling is 92.1424 credits. With the 5% reserve, it is 96.74952 credits.

The separate technical diagnostic allowance is at most 20 attempts and 1 credit. It includes the two completed calls. Add this allowance once to the study allowance. The combined ceiling is 4,276 attempts and 97.74952 credits. No further diagnostic call is required by this amendment. The single hard limit remains 100 credits. Do not raise the limit or open a separate uncounted ledger.

Before any version 1.2 study call, stop all diagnostic work and import its saved charges and unknown reservations into the existing study ledger. Use a fixed import identity and a receipt so that a repeated amendment cannot add or remove the same charge twice. Imported diagnostic attempts remain separate from probe and retry quotas. Keep all 20 old study entries unchanged, including the five unknown charges. Do not infer that a transport error was free.

At this amendment, the old study has 0.12211095 estimated charged credits and 0.118230 credits reserved for unknown charges. The two diagnostic charges total 0.0021718 credits. The combined committed amount is 0.24251275 credits. The diagnostic `usage.cost` values agree with the local estimates for these calls. No provider account deduction has been verified.

Before replacing the current study record or source copies, archive version 1.1 under `results/live/amendments/v1_1/`. Keep its study, sources, status, failed probe gate, report, manifest, model catalog, test report, tokenizer check, and a consistent credit-ledger backup. Also save a fixed copy of the diagnostic journal and its request, response, and result records. Save hashes for all archive records. Keep the earlier `amendments/v1_0/` archive and all old run logs.

The amendment receipt must link the old and new study hashes, old status and probe hashes, diagnostic journal hash, and ledger import receipt. The ledger receipt must show the old rows, imported diagnostic rows, revised quotas, and unchanged unknown reservations. The audit must check these links and confirm that old charges were neither removed nor counted twice. It must also confirm that the prompts, workers, task rules, and scoring stayed unchanged. Save the new source copies and new test results before paid probes start.

The user-reported balance is 4,500 credits. It is not a verified billing record. The approved 100-credit hard limit remains sufficient under the stated rates and limits. No credit purchase or automatic recharge is authorized. OpenRouter use remains zero.
