**Technical amendment: selection-1.0 to selection-1.1.**

The user approved a total limit of 100 Adaption credits. The main sample stays at 40 paired task seeds for each model. This amendment was made before any pilot or main call.

The first probe stage ended on 7 November 2026 at 21:06:40 UTC. It made four calls to each model. Qwen returned three valid choices. Its other call used all 2,000 output tokens for reasoning and returned no choice. GLM returned one valid choice. Its other three calls used all 2,000 output tokens for reasoning and returned no choice. The probe gate failed.

All eight calls have token usage and settled local charge estimates. Their total estimated charge is 0.05430695 credits. There are no pending or unknown reservations from that stage. No pilot or main calls occurred. These probes provide a technical test result. They are not part of the main outcome analysis.

The output limit changes from 2,000 to 4,000 tokens for both models. The input limit stays at 6,000 tokens. At most 16 model requests can be active at once. At most 32 episodes can be active. The eight pilot episodes permit at most eight simultaneous requests.

The two model IDs, temperature, prompt text, worker rules, task matrix, task seeds, condition order, scoring, primary outcome, and statistical tests stay the same. The amendment does not select prompts or tasks from an observed safety effect. It addresses output exhaustion. A larger output allowance can change model behavior. All pilot and main calls must therefore use version 1.1.

Four new probes are allowed for each model. Their run IDs are `probe_v1_1_qwen3.5-397b` and `probe_v1_1_glm-5.2`. The old probe IDs remain in the records. The new probe stage must pass before the pilot starts. The pilot must pass the original fixed checks before the main freeze. A second technical failure must remain visible. It does not authorize further changes.

The total limit is 4,248 attempts across both versions. Per model, this allows 1,920 main calls, 96 pilot calls, eight probes, and at most 100 transport retries. Invalid output does not receive a repair call. At the full input and output limits, the base ceiling is 91.9692 credits. With a 5% reserve, it is 96.56766 credits. The calculation includes the old probes at the new, larger allowance. The 100-credit hard limit includes all old charges and all new reservations.

Keep the original event logs, task files, result files, and credit ledger. Archive the original study file, source copies, probe gate, status, and report in `results/live/amendments/v1_0/`. Save the amendment provenance with hashes for the old and new study records. The old probe result hashes must still match their event logs. Save new version 1.1 study and source records before new calls.

The audit must check both source sets. It must check that the model, task, prompt, and score definitions stayed the same. It must check the old failed probe gate, the preserved old charge entries, the new probe identities, and the main freeze. The main analysis excludes both probe stages.

The user-reported balance is 4,500 credits. It is not a verified billing record. No credit purchase or automatic recharge is authorized. OpenRouter use stays at zero. The local credit values are estimates, not verified account deductions.
