"""Offline tests for the CLI archive and diagnostic import boundary."""

import argparse
import asyncio
from contextlib import ExitStack, closing, redirect_stdout
import hashlib
import io
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import AsyncMock, patch

from selection_study import cli
from selection_study.common import digest, read_json, write_json
from selection_study.ledger import BudgetError, CreditLedger
from selection_study.runner import MODELS


class FakeCounter:
    name = 'test_native_control'


class FakeProvider:
    mode = 'live'
    secrets = ('test-only-key',)

    def __init__(self, key):
        if key != 'test-only-key':
            raise AssertionError('Only the test key is allowed')

    def list_models(self):
        return {'object': 'list', 'data': [{'id': model} for model in MODELS]}

    def complete(self, *args):
        raise AssertionError('No inference request is allowed in this test')


class ControlAmendmentCliTests(unittest.TestCase):
    def fixture(self, folder):
        folder = Path(folder).resolve()
        base = folder / 'package'
        base.mkdir()
        (base / 'sample.py').write_text('# new control source\n')
        hashes = {'sample.py': hashlib.sha256((base / 'sample.py').read_bytes()).hexdigest()}
        write_json(base / 'offline_test_report.json', {'passed': True})
        write_json(base / 'tokenizers/verification.json', {'paid_calls': 0})
        root = folder / 'study'
        (root / 'source').mkdir(parents=True)
        (root / 'source/sample.py').write_text('# old source for failed probes\n')
        old_hashes = {'sample.py': hashlib.sha256((root / 'source/sample.py').read_bytes()).hexdigest()}
        write_json(root / 'study.json', {'protocol': 'selection-1.1', 'mode': 'live',
                   'source_hashes': old_hashes, 'reasoning_setting': 'provider_default_uncontrolled'})
        write_json(root / 'status.json', {'status': 'probe_failed', 'mode': 'live'})
        write_json(root / 'probes.json', {'passed': False, 'results': [
            {'run_id': 'probe_' + model, 'log_hash': 'saved-' + model} for model in MODELS]})
        (root / 'REPORT.md').write_text('The earlier probes did not pass.\n')
        ledger = CreditLedger(root / 'credits.sqlite', '100', 'live')
        with closing(sqlite3.connect(ledger.path)) as db, db:
            db.execute('INSERT INTO attempts VALUES (?,?,?,?,?,?,?,?)',
                       ('prior-probe', MODELS[0], 'probe', 0, '0.01', 'settled', '0.001', None))
        diagnostics = folder / 'diagnostics'
        write_json(diagnostics / 'budget.json', {'schema': 'diagnostic-test-fixture',
                   'events': [{'hash': 'test-diagnostic-chain-hash'}]})
        write_json(diagnostics / 'runs/reasoning_none/response.json',
                   {'status': 'completed', 'usage': {'output_tokens_details': {'reasoning_tokens': 0}}})
        (diagnostics / 'source').mkdir()
        (diagnostics / 'source/check.py').write_text('# saved diagnostic source\n')
        args = argparse.Namespace(result_root=root, mode='live', execute_paid=True,
            available_credits=4500, key_receipt=None, pilot_only=False,
            amend_failed_probes=False, amend_reasoning_control=True, diagnostic_root=diagnostics)
        receipt = {'amendment_id': 'reasoning_control_v1_2', 'imported_attempts': 2,
                   'journal_chain_hash': 'test-diagnostic-chain-hash',
                   'actual_billing_verified': False}
        return base, hashes, root, diagnostics, args, receipt

    def contexts(self, base, hashes, receipt):
        stack = ExitStack()
        stack.enter_context(patch.object(cli, 'BASE', base))
        stack.enter_context(patch.object(cli, 'source_hashes', return_value=hashes))
        stack.enter_context(patch.object(cli, 'require_offline_checks'))
        stack.enter_context(patch.object(cli, 'counters', return_value={model: FakeCounter() for model in MODELS}))
        stack.enter_context(patch.object(cli, 'AdaptionProvider', FakeProvider))
        stack.enter_context(patch.dict('os.environ', {'ADAPTION_API_KEY': 'test-only-key'}))
        stack.enter_context(patch('socket.create_connection', side_effect=AssertionError('No network')))
        stack.enter_context(patch('socket.socket.connect', side_effect=AssertionError('No network')))
        amendment = stack.enter_context(patch.object(cli.CreditLedger, 'amend_control_ready',
            return_value=receipt, create=True))
        pipeline = stack.enter_context(patch.object(cli.Runner, 'pipeline', AsyncMock(
            return_value={'status': 'pilot_passed', 'ledger': {}})))
        stack.enter_context(redirect_stdout(io.StringIO()))
        return stack, amendment, pipeline

    def test_control_amendment_archives_inputs_and_records_ledger_receipt(self):
        with tempfile.TemporaryDirectory() as folder:
            base, hashes, root, diagnostics, args, receipt = self.fixture(folder)
            original_study = read_json(root / 'study.json')
            original_status = read_json(root / 'status.json')
            original_probes = read_json(root / 'probes.json')
            original_source = (root / 'source/sample.py').read_bytes()
            original_budget = (diagnostics / 'budget.json').read_bytes()
            contexts, amendment, pipeline = self.contexts(base, hashes, receipt)

            def import_after_archive(ledger_path, budget_path):
                self.assertTrue((root / 'amendments/v1_1/credits.sqlite').is_file())
                self.assertTrue((root / 'amendments/v1_1/diagnostics/budget.json').is_file())
                with closing(sqlite3.connect(ledger_path)) as db, db:
                    db.execute('INSERT INTO attempts VALUES (?,?,?,?,?,?,?,?)',
                        ('diagnostic-import-fixture', MODELS[1], 'diagnostic', 0,
                         '0.01', 'settled', '0.002', None))
                return receipt

            amendment.side_effect = import_after_archive
            with contexts:
                self.assertEqual(asyncio.run(cli.execute(args)), 0)
                amendment.assert_called_once_with(root / 'credits.sqlite', diagnostics / 'budget.json')
                pipeline.assert_awaited_once_with(main=True)
            archive = root / 'amendments/v1_1'
            self.assertEqual(read_json(archive / 'study.json'), original_study)
            self.assertEqual(read_json(archive / 'status.json'), original_status)
            self.assertEqual(read_json(archive / 'probes.json'), original_probes)
            self.assertEqual((archive / 'source/sample.py').read_bytes(), original_source)
            self.assertEqual((archive / 'REPORT.md').read_text(), 'The earlier probes did not pass.\n')
            with closing(sqlite3.connect(archive / 'credits.sqlite')) as db:
                self.assertEqual(db.execute('SELECT id, estimated_charge FROM attempts').fetchall(),
                                 [('prior-probe', '0.001')])
            with closing(sqlite3.connect(root / 'credits.sqlite')) as db:
                self.assertEqual(db.execute('SELECT COUNT(*) FROM attempts').fetchone()[0], 2)
            self.assertEqual((archive / 'diagnostics/budget.json').read_bytes(), original_budget)
            self.assertEqual((archive / 'diagnostics/source/check.py').read_bytes(),
                             (diagnostics / 'source/check.py').read_bytes())
            self.assertEqual(read_json(archive / 'diagnostics/runs/reasoning_none/response.json'),
                             read_json(diagnostics / 'runs/reasoning_none/response.json'))
            self.assertEqual((diagnostics / 'budget.json').read_bytes(), original_budget)
            current = read_json(root / 'study.json')
            self.assertEqual(current['protocol'], 'selection-1.2')
            self.assertEqual(current['reasoning_setting'], 'requested_none_reported_zero_required')
            self.assertEqual(current['reasoning_request'], {'effort': 'none'})
            self.assertEqual(current['ledger_control_amendment'], receipt)
            self.assertEqual(current['source_hashes'], hashes)
            self.assertEqual((root / 'source/sample.py').read_bytes(), (base / 'sample.py').read_bytes())
            record = read_json(archive / 'amendment.json')
            self.assertEqual(record['from_protocol'], 'selection-1.1')
            self.assertEqual(record['to_protocol'], 'selection-1.2')
            self.assertEqual(record['previous_study_hash'], digest(original_study))
            self.assertEqual(record['previous_status_hash'], digest(original_status))
            self.assertEqual(record['previous_probes_hash'], digest(original_probes))
            self.assertEqual(record['current_study_hash'], digest(current))
            self.assertEqual(record['ledger_receipt'], receipt)
            self.assertEqual(record['diagnostic_journal_hash'], digest(read_json(diagnostics / 'budget.json')))

    def test_invalid_prior_study_is_refused_before_import_or_pipeline(self):
        variants = ('wrong_protocol', 'running', 'passed_probes', 'pilot_exists',
                    'main_freeze_exists', 'changed_source')
        for variant in variants:
            with self.subTest(variant=variant), tempfile.TemporaryDirectory() as folder:
                base, hashes, root, diagnostics, args, receipt = self.fixture(folder)
                if variant == 'wrong_protocol':
                    value = read_json(root / 'study.json'); value['protocol'] = 'selection-1.0'
                    write_json(root / 'study.json', value)
                elif variant == 'running':
                    write_json(root / 'status.json', {'status': 'running', 'mode': 'live'})
                elif variant == 'passed_probes':
                    write_json(root / 'probes.json', {'passed': True, 'results': []})
                elif variant == 'pilot_exists':
                    write_json(root / 'pilot.json', {})
                elif variant == 'main_freeze_exists':
                    write_json(root / 'main_freeze.json', {})
                else:
                    (root / 'source/sample.py').write_text('# changed after probes\n')
                previous = read_json(root / 'study.json')
                contexts, amendment, pipeline = self.contexts(base, hashes, receipt)
                with contexts, self.assertRaises(ValueError):
                    asyncio.run(cli.execute(args))
                amendment.assert_not_called()
                pipeline.assert_not_awaited()
                self.assertEqual(read_json(root / 'study.json'), previous)
                self.assertFalse((root / 'amendments').exists())

    def test_missing_diagnostics_cannot_rewrite_study(self):
        with tempfile.TemporaryDirectory() as folder:
            base, hashes, root, diagnostics, args, receipt = self.fixture(folder)
            args.diagnostic_root = Path(folder) / 'missing'
            previous = read_json(root / 'study.json')
            contexts, amendment, pipeline = self.contexts(base, hashes, receipt)
            with contexts, self.assertRaises((ValueError, OSError)):
                asyncio.run(cli.execute(args))
            amendment.assert_not_called()
            pipeline.assert_not_awaited()
            self.assertEqual(read_json(root / 'study.json'), previous)

    def test_paid_switch_is_required_before_import(self):
        with tempfile.TemporaryDirectory() as folder:
            base, hashes, root, diagnostics, args, receipt = self.fixture(folder)
            args.execute_paid = False
            contexts, amendment, pipeline = self.contexts(base, hashes, receipt)
            with contexts, self.assertRaises(ValueError):
                asyncio.run(cli.execute(args))
            amendment.assert_not_called()
            pipeline.assert_not_awaited()
            self.assertFalse((root / 'amendments').exists())

    def test_rejected_diagnostic_import_does_not_start_or_rewrite_study(self):
        with tempfile.TemporaryDirectory() as folder:
            base, hashes, root, diagnostics, args, receipt = self.fixture(folder)
            previous_study = read_json(root / 'study.json')
            previous_status = read_json(root / 'status.json')
            contexts, amendment, pipeline = self.contexts(base, hashes, receipt)
            amendment.side_effect = BudgetError('The diagnostic import did not pass its checks')
            with contexts, self.assertRaises(BudgetError):
                asyncio.run(cli.execute(args))
            amendment.assert_called_once()
            pipeline.assert_not_awaited()
            self.assertEqual(read_json(root / 'study.json'), previous_study)
            self.assertEqual(read_json(root / 'status.json'), previous_status)
            self.assertEqual(read_json(root / 'amendments/v1_1/study.json'), previous_study)
            self.assertFalse((root / 'amendments/v1_1/amendment.json').exists())


if __name__ == '__main__':
    unittest.main()
