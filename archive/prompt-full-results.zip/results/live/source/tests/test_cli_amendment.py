import argparse
import asyncio
from contextlib import closing
import hashlib
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import AsyncMock, patch

from selection_study import cli
from selection_study.common import read_json, write_json, digest
from selection_study.ledger import CreditLedger
from selection_study.runner import MODELS


class FakeCounter:
    name = 'test_native'


class FakeProvider:
    mode = 'live'
    secrets = ('test-only-key',)
    def __init__(self, key): self.calls = 0
    def list_models(self): return {'object':'list','data':[{'id':m} for m in MODELS]}
    def complete(self, *args): raise AssertionError('No inference request is allowed in this test')


class AmendmentCliTests(unittest.TestCase):
    def fixture(self, folder, status='probe_failed'):
        base = Path(folder)/'source_package'; base.mkdir()
        (base/'sample.py').write_text('# source fixture\n')
        hashes={'sample.py':hashlib.sha256((base/'sample.py').read_bytes()).hexdigest()}
        write_json(base/'offline_test_report.json', {'passed':True})
        write_json(base/'tokenizers/verification.json', {'paid_calls':0})
        root=Path(folder)/'results'; root.mkdir()
        (root/'source').mkdir()
        (root/'source/sample.py').write_text((base/'sample.py').read_text())
        write_json(root/'study.json', {'protocol':'selection-1.0','mode':'live','source_hashes':hashes})
        write_json(root/'status.json', {'status':status,'mode':'live'})
        write_json(root/'probes.json', {'passed':False,'results':[
            {'run_id':'probe_'+m,'log_hash':'test-hash-'+m} for m in MODELS]})
        ledger=CreditLedger(root/'credits.sqlite', '65', 'live')
        with closing(sqlite3.connect(ledger.path)) as db, db:
            db.execute("UPDATE metadata SET value=? WHERE key='quotas'",
                       (json.dumps({'main':1920,'pilot':96,'probe':4},sort_keys=True),))
            db.execute("UPDATE metadata SET value='4240' WHERE key='max_attempts'")
            for model in MODELS:
                for n in range(4):
                    db.execute('INSERT INTO attempts VALUES (?,?,?,?,?,?,?,?)',
                        (f'probe_{model}|r{n+1}|attempt0',model,'probe',0,'0.01','settled','0.001',
                         json.dumps({'input_tokens':100,'output_tokens':100,'total_tokens':200})))
        args=argparse.Namespace(result_root=root,mode='live',execute_paid=True,
            available_credits=4500,key_receipt=None,pilot_only=False,amend_failed_probes=True,
            amend_reasoning_control=False,diagnostic_root=None)
        return base,hashes,root,args

    def contexts(self, base, hashes):
        from contextlib import ExitStack
        stack=ExitStack()
        stack.enter_context(patch.object(cli,'BASE',base))
        stack.enter_context(patch.object(cli,'source_hashes',return_value=hashes))
        stack.enter_context(patch.object(cli,'require_offline_checks'))
        stack.enter_context(patch.object(cli,'counters',return_value={m:FakeCounter() for m in MODELS}))
        stack.enter_context(patch.object(cli,'AdaptionProvider',FakeProvider))
        stack.enter_context(patch.dict('os.environ',{'ADAPTION_API_KEY':'test-only-key'}))
        return stack

    def test_retired_probe_amendment_is_refused_before_provider_access(self):
        with tempfile.TemporaryDirectory() as folder:
            base,hashes,root,args=self.fixture(folder)
            original=read_json(root/'study.json')
            with self.contexts(base,hashes), patch.object(cli,'AdaptionProvider') as provider, \
                    patch.object(cli.Runner,'pipeline',AsyncMock()) as pipeline:
                with self.assertRaises(ValueError):
                    asyncio.run(cli.execute(args))
                provider.assert_not_called()
                pipeline.assert_not_awaited()
            self.assertEqual(read_json(root/'study.json'),original)
            self.assertFalse((root/'amendments').exists())
            with closing(sqlite3.connect(root/'credits.sqlite')) as db:
                self.assertEqual(db.execute('SELECT COUNT(*) FROM attempts').fetchone()[0],8)
                self.assertEqual(db.execute("SELECT value FROM metadata WHERE key='limit_credits'").fetchone()[0],'65')

    def test_main_or_running_study_cannot_use_probe_amendment(self):
        for status in ('running','complete'):
            with tempfile.TemporaryDirectory() as folder:
                base,hashes,root,args=self.fixture(folder,status)
                with self.contexts(base,hashes), self.assertRaises(ValueError):
                    asyncio.run(cli.execute(args))
                self.assertFalse((root/'amendments').exists())
                with closing(sqlite3.connect(root/'credits.sqlite')) as db:
                    self.assertEqual(db.execute("SELECT value FROM metadata WHERE key='limit_credits'").fetchone()[0],'65')


if __name__=='__main__': unittest.main()
