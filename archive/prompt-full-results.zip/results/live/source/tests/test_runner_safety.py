"""No-network checks for request accounting and stop controls."""

from decimal import Decimal
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from selection_study.ledger import BudgetError
from selection_study.runner import Runner
from selection_study.transport import TransportError, maximum_call_cost


MODEL = 'qwen3.5-397b'
USAGE = {'input_tokens': 200, 'output_tokens': 50, 'total_tokens': 250}
CHARGE = Decimal('0.000285')
MESSAGES = [{'role': role, 'content': 'test'} for role in ('system', 'user', 'user')]


class Counter:
    name = 'test-counter'

    def count(self, messages):
        return 1000


class Provider:
    mode = 'live'
    secrets = ()

    def __init__(self, results=None):
        self.calls = 0
        self.results = list(results or [])

    def complete(self, model_id, messages):
        self.calls += 1
        if self.results:
            result = self.results.pop(0)
            if isinstance(result, BaseException):
                raise result
            return result
        return {'id': 'fake-response', 'model': model_id, 'status': 'completed',
                'text': '{"worker_id":"test"}', 'usage': dict(USAGE), 'raw': {}}


class Log:
    previous = 'test-hash'

    def __init__(self, fail_on=None):
        self.fail_on = fail_on
        self.events = []

    def append(self, kind, **fields):
        if kind == self.fail_on:
            raise OSError('Injected log write failure')
        self.events.append((kind, fields))


class RunnerSafetyTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.provider = Provider()
        self.runner = Runner(Path(self.temp.name), self.provider, {MODEL: Counter()})
        self.runner.retry_delay = 0
        self.row = {'run_id': 'test-run', 'model_id': MODEL, 'phase': 'pilot',
                    'seed': 1, 'condition': 'worker_objection'}

    def tearDown(self):
        self.temp.cleanup()

    async def request(self, log=None, count=1000):
        return await self.runner.request(self.row, 1, MESSAGES, count, log or Log())

    async def test_v1_1_runner_uses_approved_100_credit_limit(self):
        self.assertEqual(Decimal(self.runner.ledger.snapshot()['limit_credits']), Decimal('100'))

    async def assert_stopped(self):
        self.assertTrue(self.runner.stop)
        self.assertTrue(self.runner.ledger.snapshot()['frozen'])
        prior_calls = self.provider.calls
        with self.assertRaises(BudgetError):
            await self.runner.request(self.row, 2, MESSAGES, 1000, Log())
        self.assertEqual(self.provider.calls, prior_calls)

    async def test_request_log_failure_prevents_dispatch(self):
        with self.assertRaises(OSError):
            await self.request(Log('request'))
        self.assertEqual(self.provider.calls, 0)
        snapshot = self.runner.ledger.snapshot()
        self.assertEqual(Decimal(snapshot['committed_credits']), 0)
        self.assertEqual(snapshot['attempts'], 1)
        await self.assert_stopped()

    async def test_response_log_failure_preserves_known_charge(self):
        with self.assertRaises(OSError):
            await self.request(Log('response'))
        snapshot = self.runner.ledger.snapshot()
        self.assertEqual(self.provider.calls, 1)
        self.assertEqual(Decimal(snapshot['estimated_charged_credits']), CHARGE)
        self.assertEqual(Decimal(snapshot['unknown_credits']), 0)
        await self.assert_stopped()

    async def test_settlement_failure_retains_reservation(self):
        with patch.object(self.runner.ledger, 'settle', side_effect=OSError('Injected database failure')):
            with self.assertRaises(OSError):
                await self.request()
        self.assertEqual(self.provider.calls, 1)
        self.assertEqual(Decimal(self.runner.ledger.snapshot()['unknown_credits']), maximum_call_cost(MODEL))
        await self.assert_stopped()

    async def test_process_stops_when_freeze_write_also_fails(self):
        with patch.object(self.runner.ledger, 'mark_unknown', side_effect=OSError('Injected database failure')), \
                patch.object(self.runner.ledger, 'freeze', side_effect=OSError('Injected database failure')):
            with self.assertRaises(OSError):
                await self.request(Log('response'))
        self.assertTrue(self.runner.stop)
        with self.assertRaises(BudgetError):
            await self.runner.request(self.row, 2, MESSAGES, 1000, Log())
        self.assertEqual(self.provider.calls, 1)

    async def test_transport_error_log_failure_preserves_known_charge(self):
        self.provider.results = [TransportError('Output limit', fatal=False, known_usage=USAGE)]
        with self.assertRaises(OSError):
            await self.request(Log('transport_error'))
        self.assertEqual(self.provider.calls, 1)
        self.assertEqual(Decimal(self.runner.ledger.snapshot()['estimated_charged_credits']), CHARGE)
        await self.assert_stopped()

    async def test_output_limit_consumes_one_turn_without_retry_or_freeze(self):
        self.provider.results = [TransportError('Output limit', fatal=False, known_usage=USAGE)]
        self.assertEqual(await self.request(), (None, None))
        snapshot = self.runner.ledger.snapshot()
        self.assertEqual(self.provider.calls, 1)
        self.assertEqual(snapshot['attempts'], 1)
        self.assertEqual(Decimal(snapshot['estimated_charged_credits']), CHARGE)
        self.assertFalse(self.runner.stop)
        self.assertFalse(snapshot['frozen'])

    async def test_output_limit_still_checks_native_input_bound(self):
        self.provider.results = [TransportError('Output limit', fatal=False, known_usage=USAGE)]
        with self.assertRaisesRegex(ValueError, 'Native count'):
            await self.request(count=199)
        self.assertEqual(self.provider.calls, 1)
        self.assertEqual(Decimal(self.runner.ledger.snapshot()['estimated_charged_credits']), CHARGE)
        await self.assert_stopped()

    async def test_transient_retry_keeps_unknown_reservation(self):
        self.provider.results = [TransportError('HTTP 503', retryable=True, fatal=False)]
        text, response = await self.request()
        self.assertIsNotNone(text)
        self.assertEqual(response['id'], 'fake-response')
        snapshot = self.runner.ledger.snapshot()
        self.assertEqual(self.provider.calls, 2)
        self.assertEqual(snapshot['attempts'], 2)
        self.assertEqual(snapshot['counts'][MODEL]['retries'], 1)
        self.assertEqual(Decimal(snapshot['unknown_credits']), maximum_call_cost(MODEL))
        self.assertFalse(self.runner.stop)
        self.assertFalse(snapshot['frozen'])

    async def test_fatal_transport_error_stops_requests(self):
        self.provider.results = [TransportError('Missing usage')]
        with self.assertRaises(TransportError):
            await self.request()
        self.assertEqual(self.provider.calls, 1)
        self.assertEqual(Decimal(self.runner.ledger.snapshot()['unknown_credits']), maximum_call_cost(MODEL))
        await self.assert_stopped()

    async def test_episode_context_error_stops_even_when_stop_log_fails(self):
        log = Log('stopped')
        with patch('selection_study.runner.EventLog', return_value=log), \
                patch('selection_study.runner.summarize_run', return_value={}), \
                patch.object(self.runner.counters[MODEL], 'count', side_effect=ValueError('Input too long')):
            result = await self.runner.episode(self.row)
        self.assertEqual(result['status'], 'incomplete')
        self.assertEqual(self.provider.calls, 0)
        await self.assert_stopped()

    async def test_episode_schema_error_stops_requests(self):
        with patch('selection_study.runner.EventLog', return_value=Log()), \
                patch('selection_study.runner.summarize_run', return_value={}), \
                patch('selection_study.runner.build_messages', side_effect=KeyError('Missing field')):
            result = await self.runner.episode(self.row)
        self.assertEqual(result['status'], 'incomplete')
        self.assertEqual(self.provider.calls, 0)
        await self.assert_stopped()


if __name__ == '__main__':
    unittest.main()
