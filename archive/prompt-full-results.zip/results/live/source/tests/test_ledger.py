from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from decimal import Decimal
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest

from selection_study.ledger import BudgetError, CreditLedger
from selection_study.transport import maximum_call_cost


MODEL = 'qwen3.5-397b'
RESERVE = maximum_call_cost(MODEL)


@contextmanager
def database(path):
    db = sqlite3.connect(path)
    try:
        with db:
            yield db
    finally:
        db.close()


class LedgerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / 'ledger.sqlite'

    def tearDown(self):
        self.temp.cleanup()

    def test_reservation_settlement_and_unknown_charge(self):
        ledger=CreditLedger(self.path)
        ledger.reserve('a',MODEL,'main',RESERVE)
        ledger.reserve('b',MODEL,'main',RESERVE)
        ledger.settle('a','0.005',{'input_tokens':100,'output_tokens':20,'total_tokens':120})
        ledger.mark_unknown('b',freeze=False)
        snap=ledger.snapshot()
        self.assertEqual(Decimal(snap['committed_credits']),RESERVE+Decimal('0.005'))
        self.assertEqual(Decimal(snap['unknown_credits']),RESERVE)
        self.assertFalse(snap['frozen'])
        self.assertFalse(snap['actual_billing_verified'])
        ledger.reserve('b-retry',MODEL,'main',RESERVE,is_retry=True)
        self.assertEqual(ledger.snapshot()['counts'][MODEL]['retries'],1)

    def test_settings_cannot_change_when_reopened(self):
        CreditLedger(self.path,limit_credits='64')
        for kwargs in [dict(limit_credits='65'),dict(limit_credits='64',mode='offline')]:
            with self.assertRaises(BudgetError):CreditLedger(self.path,**kwargs)

    def test_pending_requests_count_against_limit(self):
        ledger=CreditLedger(self.path,limit_credits=str(RESERVE))
        ledger.reserve('a',MODEL,'main',RESERVE)
        with self.assertRaises(BudgetError):ledger.reserve('b',MODEL,'main',RESERVE)
        ledger.settle('a','0')
        ledger.reserve('b',MODEL,'main',RESERVE)

    def test_duplicate_ids_and_settlement_are_rejected(self):
        ledger=CreditLedger(self.path)
        ledger.reserve('a',MODEL,'main',RESERVE)
        with self.assertRaises(BudgetError):ledger.reserve('a',MODEL,'main',RESERVE)
        ledger.settle('a','0')
        with self.assertRaises(BudgetError):ledger.settle('a','0')

    def test_live_request_cannot_under_reserve(self):
        ledger=CreditLedger(self.path)
        for amount in ['0','NaN','Infinity','-1']:
            with self.subTest(amount=amount),self.assertRaises(ValueError):
                ledger.reserve('a',MODEL,'main',amount)

    def test_overrun_is_recorded_before_freeze(self):
        ledger=CreditLedger(self.path)
        ledger.reserve('a',MODEL,'main',RESERVE)
        with self.assertRaises(BudgetError):ledger.settle('a','0.5')
        self.assertEqual(Decimal(ledger.snapshot()['estimated_charged_credits']),Decimal('.5'))
        self.assertTrue(ledger.snapshot()['frozen'])
        with self.assertRaises(BudgetError):ledger.reserve('b',MODEL,'main',RESERVE)

    def test_fatal_unknown_keeps_reserve_and_stops_new_calls(self):
        ledger=CreditLedger(self.path)
        ledger.reserve('a',MODEL,'main',RESERVE)
        ledger.mark_unknown('a')
        self.assertEqual(Decimal(ledger.snapshot()['unknown_credits']),RESERVE)
        with self.assertRaises(BudgetError):ledger.reserve('b',MODEL,'main',RESERVE)

    def test_probe_and_retry_quotas(self):
        ledger=CreditLedger(self.path)
        for index in range(12):ledger.reserve(f'p{index}',MODEL,'probe',RESERVE)
        with self.assertRaises(BudgetError):ledger.reserve('p12',MODEL,'probe',RESERVE)
        for index in range(100):ledger.reserve(f'r{index}',MODEL,'probe',RESERVE,is_retry=True)
        with self.assertRaises(BudgetError):ledger.reserve('r100',MODEL,'probe',RESERVE,is_retry=True)

    def test_atomic_concurrent_reservations_cannot_exceed_budget(self):
        ledger=CreditLedger(self.path,limit_credits=str(RESERVE*5))
        def reserve(index):
            try:ledger.reserve(f'r{index}',MODEL,'main',RESERVE)
            except BudgetError:return False
            return True
        with ThreadPoolExecutor(max_workers=8) as pool:
            passed=list(pool.map(reserve,range(30)))
        self.assertEqual(sum(passed),5)
        self.assertEqual(ledger.snapshot()['attempts'],5)

    def test_offline_mode_never_records_charges(self):
        ledger=CreditLedger(self.path,mode='offline')
        ledger.reserve('a',MODEL,'main',0)
        with self.assertRaises(BudgetError):ledger.settle('a','0.01')
        ledger.settle('a',0)
        self.assertEqual(Decimal(ledger.snapshot()['estimated_charged_credits']),0)
        with self.assertRaises(ValueError):ledger.reserve('b',MODEL,'main',RESERVE)

    def test_maximum_authorized_limit_is_100_credits(self):
        CreditLedger(self.path, limit_credits='100')
        with self.assertRaises(ValueError):
            CreditLedger(self.path, limit_credits='100.01')

    def test_diagnostic_quota_is_shared_across_models(self):
        ledger = CreditLedger(self.path, limit_credits='100')
        for index in range(20):
            model = ('qwen3.5-397b', 'glm-5.2')[index % 2]
            ledger.reserve(f'diagnostic-{index}', model, 'diagnostic', maximum_call_cost(model))
        with self.assertRaises(BudgetError):
            ledger.reserve('diagnostic-extra', 'glm-5.2', 'diagnostic', maximum_call_cost('glm-5.2'))


class ProbeAmendmentTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / 'ledger.sqlite'
        # Build a v1 fixture directly. Never open or amend a live study ledger.
        ledger = CreditLedger(self.path, limit_credits='65')
        for model in ('qwen3.5-397b', 'glm-5.2'):
            old_reservation = Decimal('0.010815') if model == MODEL else Decimal('0.01806')
            for index in range(4):
                ledger.reserve(f'v1-{model}-{index}', model, 'probe', maximum_call_cost(model))
                ledger.settle(f'v1-{model}-{index}', '0.005',
                              {'input_tokens': 1000, 'output_tokens': 1000, 'total_tokens': 2000})
            with database(self.path) as db:
                db.execute('UPDATE attempts SET reserved=? WHERE model=?', (str(old_reservation), model))
        with database(self.path) as db:
            db.execute("UPDATE metadata SET value=? WHERE key='quotas'",
                       (json.dumps({'main': 1920, 'pilot': 96, 'probe': 4}, sort_keys=True),))
            db.execute("UPDATE metadata SET value='4240' WHERE key='max_attempts'")

    def tearDown(self):
        self.temp.cleanup()

    def state(self):
        with database(self.path) as db:
            return (db.execute('SELECT * FROM metadata ORDER BY key').fetchall(),
                    db.execute('SELECT * FROM attempts ORDER BY id').fetchall())

    def test_amendment_preserves_attempts_and_stores_receipt(self):
        before = self.state()
        receipt = CreditLedger.amend_failed_probes(self.path)
        self.assertEqual(self.state()[1], before[1])
        self.assertEqual(receipt['before']['attempts'], 8)
        self.assertEqual(receipt['before']['attempt_records_sha256'], receipt['after']['attempt_records_sha256'])
        self.assertEqual(Decimal(receipt['after']['estimated_charged_credits']), Decimal('.04'))
        self.assertEqual(Decimal(receipt['before']['settings']['limit_credits']), 65)
        self.assertEqual(Decimal(receipt['after']['settings']['limit_credits']), 100)
        self.assertEqual(receipt['after']['counts'][MODEL]['primary_by_phase']['probe'], 4)
        with database(self.path) as db:
            stored = db.execute("SELECT value FROM metadata WHERE key='amendment_failed_probes_v1_1'").fetchone()[0]
        self.assertEqual(json.loads(stored), receipt)
        # v1.2 must not silently open this intermediate v1.1 ledger.
        with self.assertRaises(BudgetError):
            CreditLedger(self.path, limit_credits='100')
        with database(self.path) as db:
            self.assertEqual(json.loads(db.execute("SELECT value FROM metadata WHERE key='quotas'").fetchone()[0])['probe'], 8)
            self.assertEqual(db.execute("SELECT value FROM metadata WHERE key='max_attempts'").fetchone()[0], '4248')

    def test_old_ledger_cannot_open_without_explicit_amendment(self):
        with self.assertRaises(BudgetError):
            CreditLedger(self.path, limit_credits='65')
        with self.assertRaises(BudgetError):
            CreditLedger(self.path, limit_credits='100')

    def test_amendment_cannot_repeat(self):
        CreditLedger.amend_failed_probes(self.path)
        before = self.state()
        with self.assertRaises(BudgetError):
            CreditLedger.amend_failed_probes(self.path)
        self.assertEqual(self.state(), before)

    def test_metadata_guards_do_not_change_ledger(self):
        mutations = [('mode', 'offline'), ('limit_credits', '64'), ('currency', 'USD'),
                     ('prices', '{}'), ('quotas', '{}'), ('retry_limit', '101'),
                     ('max_attempts', '4241'), ('frozen_reason', 'Stopped')]
        for key, value in mutations:
            with self.subTest(key=key):
                with database(self.path) as db:
                    original = db.execute('SELECT value FROM metadata WHERE key=?', (key,)).fetchone()[0]
                    db.execute('UPDATE metadata SET value=? WHERE key=?', (value, key))
                before = self.state()
                with self.assertRaises(BudgetError):
                    CreditLedger.amend_failed_probes(self.path)
                self.assertEqual(self.state(), before)
                with database(self.path) as db:
                    db.execute('UPDATE metadata SET value=? WHERE key=?', (original, key))

    def test_attempt_guards_do_not_change_ledger(self):
        changes = [('phase', 'pilot'), ('phase', 'main'), ('status', 'pending'),
                   ('status', 'unknown'), ('estimated_charge', None),
                   ('estimated_charge', 'NaN'), ('estimated_charge', '100'),
                   ('model', 'other'), ('retry', 2)]
        for field, value in changes:
            with self.subTest(field=field, value=value):
                with database(self.path) as db:
                    attempt_id, original = db.execute(f'SELECT id,{field} FROM attempts LIMIT 1').fetchone()
                    db.execute(f'UPDATE attempts SET {field}=? WHERE id=?', (value, attempt_id))
                before = self.state()
                with self.assertRaises(BudgetError):
                    CreditLedger.amend_failed_probes(self.path)
                self.assertEqual(self.state(), before)
                with database(self.path) as db:
                    db.execute(f'UPDATE attempts SET {field}=? WHERE id=?', (original, attempt_id))

    def test_too_many_prior_primary_probes_are_rejected(self):
        with database(self.path) as db:
            db.execute("INSERT INTO attempts SELECT 'extra',model,phase,retry,reserved,status,estimated_charge,usage FROM attempts WHERE model=? LIMIT 1", (MODEL,))
        before = self.state()
        with self.assertRaises(BudgetError):
            CreditLedger.amend_failed_probes(self.path)
        self.assertEqual(self.state(), before)

    def test_retry_count_is_shared_across_versions(self):
        with database(self.path) as db:
            for index in range(2):
                db.execute("INSERT INTO attempts SELECT ?,model,phase,1,reserved,status,estimated_charge,usage FROM attempts WHERE model=? LIMIT 1", (f'old-retry-{index}', MODEL))
        CreditLedger.amend_failed_probes(self.path)
        with database(self.path) as db:
            self.assertEqual(db.execute('SELECT sum(retry) FROM attempts WHERE model=?', (MODEL,)).fetchone()[0], 2)
            self.assertEqual(db.execute("SELECT value FROM metadata WHERE key='retry_limit'").fetchone()[0], '100')

    def test_missing_ledger_is_not_created(self):
        missing = Path(self.temp.name) / 'missing.sqlite'
        with self.assertRaises(BudgetError):
            CreditLedger.amend_failed_probes(missing)
        self.assertFalse(missing.exists())


if __name__ == '__main__':
    unittest.main()
