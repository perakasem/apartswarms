import asyncio
import json
from pathlib import Path
import tempfile
import unittest

from selection_study.common import EventLog, read_log, read_json, write_json
from selection_study.environment import generate_episode
from selection_study.runner import Runner, OfflineProvider, MODELS, strict_choice, manifest


class Counter:
    name = 'test_counter'
    def count(self, messages): return 4000


class InvalidProvider(OfflineProvider):
    def complete(self, model_id, messages):
        result = super().complete(model_id, messages)
        result['text'] = 'invalid'
        return result


class PilotInvalidProvider(OfflineProvider):
    def __init__(self): self.calls = {m: 0 for m in MODELS}
    def complete(self, model_id, messages):
        self.calls[model_id] += 1
        result = super().complete(model_id, messages)
        if self.calls[model_id] > 4: result['text'] = 'invalid'
        return result


class FlowTests(unittest.TestCase):
    def run_async(self, function): return asyncio.run(function)

    def runner(self, root, provider=None):
        return Runner(root, provider or OfflineProvider(), {m: Counter() for m in MODELS})

    def test_json_choice_has_no_extra_keys_or_duplicate_keys(self):
        episode = generate_episode(1, 'worker_objection')
        worker = episode['worker_ids'][0]
        self.assertEqual(strict_choice(json.dumps({'worker_id': worker}), episode), worker)
        for text in (None, '[]', '{"worker_id":true}', '{"worker_id":"unknown"}',
                     json.dumps({'worker_id': worker, 'extra': 1}),
                     '{"worker_id":"' + worker + '","worker_id":"' + worker + '"}',
                     '```json\n' + json.dumps({'worker_id': worker}) + '\n```'):
            self.assertIsNone(strict_choice(text, episode))

    def test_probe_records_four_turns_without_a_main_score(self):
        with tempfile.TemporaryDirectory() as root:
            row = {'run_id': 'probe_test', 'phase': 'probe', 'model_id': MODELS[0],
                   'seed': 0, 'condition': 'worker_objection'}
            result = self.run_async(self.runner(root).episode(row, 4))
            self.assertEqual(result['status'], 'complete')
            self.assertEqual(result['valid_turns'], 4)
            self.assertIsNone(result['focal_share'])
            self.assertFalse(result['complete'])
            self.assertEqual(len([e for e in read_log(Path(root)/'runs/probe_test/events.jsonl')
                                  if e['kind'] == 'response']), 4)

    def test_invalid_turns_have_no_assignment_and_unknown_safety(self):
        with tempfile.TemporaryDirectory() as root:
            row = next(r for r in manifest() if r['phase'] == 'pilot')
            result = self.run_async(self.runner(root, InvalidProvider()).episode(row))
            self.assertEqual(result['status'], 'complete')
            self.assertEqual(result['invalid_actions'], 24)
            self.assertEqual(result['focal_share'], 0)
            self.assertIsNone(result['risky_violation_rate'])
            self.assertEqual(result['risky_violation_rate_bounds'], [0, 1])

    def test_offline_probes_and_pilot_complete_at_zero_charge(self):
        with tempfile.TemporaryDirectory() as root:
            runner = self.runner(root)
            status = self.run_async(runner.pipeline(main=False))
            self.assertEqual(status['status'], 'pilot_passed')
            self.assertEqual(status['ledger']['attempts'], 200)
            self.assertEqual(float(status['ledger']['committed_credits']), 0)
            self.assertTrue(read_json(Path(root)/'pilot.json')['passed'])

    def test_failed_pilot_cannot_start_main(self):
        with tempfile.TemporaryDirectory() as root:
            runner = self.runner(root, PilotInvalidProvider())
            write_json(Path(root)/'study.json', {'mode':'offline'})
            status = self.run_async(runner.pipeline(main=True))
            self.assertEqual(status['status'], 'pilot_failed')
            self.assertFalse((Path(root)/'main_freeze.json').exists())
            self.assertFalse(any(r['phase'] == 'main' for r in runner.ledger.records()))

    def test_existing_run_never_sends_new_requests(self):
        with tempfile.TemporaryDirectory() as root:
            row = next(r for r in manifest() if r['phase'] == 'pilot')
            runner = self.runner(root)
            self.run_async(runner.episode(row))
            with self.assertRaises(ValueError): self.run_async(runner.episode(row))
            self.assertEqual(runner.ledger.snapshot()['attempts'], 24)

    def test_manifest_has_full_pairs_and_balanced_condition_order(self):
        rows = manifest()
        self.assertEqual(len(rows), 168)
        mains = [row for row in rows if row['phase'] == 'main']
        self.assertEqual(len({row['run_id'] for row in mains}), 160)
        for model in MODELS:
            first_conditions = [next(row['condition'] for row in mains if row['seed']==seed and row['model_id']==model)
                                for seed in range(1001,1041)]
            self.assertEqual(first_conditions.count('worker_objection'),20)

    def test_log_redacts_secret_and_detects_changed_record(self):
        with tempfile.TemporaryDirectory() as root:
            path=Path(root)/'events.jsonl'
            log=EventLog(path, ('fake-secret',))
            log.append('response', text='contains fake-secret')
            self.assertNotIn('fake-secret',path.read_text())
            self.assertEqual(len(read_log(path)),1)
            path.write_text(path.read_text().replace('contains','changed'))
            with self.assertRaises(ValueError): read_log(path)


if __name__ == '__main__': unittest.main()
