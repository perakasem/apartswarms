"""Temporary-ledger tests for the v1.2 control and diagnostic cost carry."""
from contextlib import closing
from decimal import Decimal
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest

import diagnose_adaption as diagnostic
from selection_study.environment import generate_episode
from selection_study.ledger import BudgetError, CreditLedger
from selection_study.transport import maximum_call_cost


class Counter:
    name = 'test-native'

    def count(self, messages):
        return 1000

    def count_modes(self, messages):
        return {'default': 700, 'enable_thinking_false': 701}


class Provider:
    secrets = ()

    def _request(self, path, body):
        worker = generate_episode(0, 'worker_objection')['worker_ids'][0]
        return {'id': 'test-' + body['model'], 'model': body['model'], 'status': 'completed',
                'reasoning': {'effort': 'none'}, 'output': [],
                'output_text': json.dumps({'worker_id': worker}),
                'usage': {'input_tokens': 700, 'output_tokens': 12, 'total_tokens': 712,
                          'output_tokens_details': {'reasoning_tokens': 0}}}


class ControlAmendmentTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.main = Path(self.temp.name) / 'main'
        self.diag = Path(self.temp.name) / 'diagnostics'
        self.path = self.main / 'credits.sqlite'
        ledger = CreditLedger(self.path, limit_credits='100')
        for model in diagnostic.MODELS:
            for index in range(10):
                attempt_id = f'old-{model}-{index}'
                ledger.reserve(attempt_id, model, 'probe', maximum_call_cost(model), is_retry=index >= 8)
                if index >= 8:
                    ledger.mark_unknown(attempt_id, freeze=False)
                else:
                    ledger.settle(attempt_id, '.005')
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("UPDATE metadata SET value=? WHERE key='quotas'",
                       (json.dumps({'main': 1920, 'pilot': 96, 'probe': 8}, sort_keys=True),))
            db.execute("UPDATE metadata SET value='4248' WHERE key='max_attempts'")
            db.commit()
        diagnostic.durable_json(self.main / 'status.json', {'mode': 'live', 'status': 'probe_failed'})
        diagnostic.durable_json(self.main / 'study.json', {'mode': 'live', 'protocol': 'selection-1.1'})
        session = diagnostic.DiagnosticSession(self.main, self.diag, Provider(),
                                               {model: Counter() for model in diagnostic.MODELS})
        session.run('reasoning_none', 'reasoning_none', execute_paid=True)

    def tearDown(self):
        self.temp.cleanup()

    def state(self):
        with closing(sqlite3.connect(self.path)) as db:
            return (db.execute('SELECT * FROM metadata ORDER BY key').fetchall(),
                    db.execute('SELECT * FROM attempts ORDER BY rowid').fetchall())

    def amend(self):
        return CreditLedger.amend_control_ready(self.path, self.diag / 'budget.json')

    def test_carry_preserves_old_rows_unknown_costs_and_diagnostic_files(self):
        before = self.state()
        diagnostic_files = {str(path.relative_to(self.diag)): path.read_bytes()
                            for path in self.diag.rglob('*') if path.is_file()}
        receipt = self.amend()
        self.assertEqual(self.state()[1][:20], before[1])
        self.assertEqual(len(self.state()[1]), 22)
        self.assertEqual(diagnostic_files, {str(path.relative_to(self.diag)): path.read_bytes()
                                           for path in self.diag.rglob('*') if path.is_file()})
        self.assertEqual(receipt['before']['unknown_credits'], receipt['after']['unknown_credits'])
        self.assertEqual(Decimal(receipt['after']['committed_credits']),
                         Decimal(receipt['before']['committed_credits']) + Decimal(receipt['diagnostics']['committed_credits']))
        self.assertEqual(receipt['diagnostics']['attempts'], 2)
        self.assertEqual(len(receipt['diagnostics']['record_sha256']), 6)
        self.assertEqual(len(receipt['diagnostics']['event_hashes']), 4)
        self.assertEqual(set(receipt['diagnostics']['ready_attempts_by_model']), set(diagnostic.MODELS))
        self.assertTrue(receipt['old_attempt_records_unchanged'])
        json.dumps(receipt, allow_nan=False)
        ledger = CreditLedger(self.path, limit_credits='100')
        snapshot = ledger.snapshot()
        self.assertEqual(snapshot['attempts'], 22)
        self.assertEqual(snapshot['counts']['qwen3.5-397b']['primary_by_phase']['diagnostic'], 1)

    def test_new_probe_slots_and_shared_retry_count(self):
        self.amend()
        ledger = CreditLedger(self.path, limit_credits='100')
        model = diagnostic.MODELS[0]
        for index in range(4):
            ledger.reserve(f'new-probe-{index}', model, 'probe', maximum_call_cost(model))
        with self.assertRaises(BudgetError):
            ledger.reserve('extra-probe', model, 'probe', maximum_call_cost(model))
        for index in range(98):
            ledger.reserve(f'new-retry-{index}', model, 'probe', maximum_call_cost(model), is_retry=True)
        with self.assertRaises(BudgetError):
            ledger.reserve('extra-retry', model, 'probe', maximum_call_cost(model), is_retry=True)
        self.assertEqual(ledger.snapshot()['counts'][model]['retries'], 100)

    def test_imported_diagnostics_use_global_quota(self):
        self.amend()
        ledger = CreditLedger(self.path, limit_credits='100')
        for index in range(18):
            model = diagnostic.MODELS[index % 2]
            ledger.reserve(f'new-diag-{index}', model, 'diagnostic', maximum_call_cost(model))
        with self.assertRaises(BudgetError):
            ledger.reserve('extra-diag', diagnostic.MODELS[0], 'diagnostic', maximum_call_cost(diagnostic.MODELS[0]))

    def test_unknown_diagnostic_charge_is_carried_without_release(self):
        model = diagnostic.MODELS[0]
        with diagnostic.directory_lock(self.diag):
            journal = diagnostic.Journal(self.diag / 'budget.json', self.main)
            journal.reserve('unknown__' + model, model, diagnostic.main_account(self.main))
            journal.append('unknown', attempt_id='unknown__' + model, reason='HTTP 504')
        receipt = self.amend()
        self.assertEqual(receipt['diagnostics']['attempts'], 3)
        self.assertEqual(Decimal(receipt['diagnostics']['unknown_credits']), maximum_call_cost(model))
        self.assertEqual(Decimal(receipt['after']['unknown_credits']),
                         Decimal(receipt['before']['unknown_credits']) + maximum_call_cost(model))
        ledger = CreditLedger(self.path, limit_credits='100')
        carried = next(row for row in ledger.records() if row['id'] == 'diagnostic__unknown__' + model)
        self.assertEqual(carried['status'], 'unknown')
        self.assertIsNone(carried['estimated_charge'])

    def test_second_amendment_is_rejected_without_changes(self):
        self.amend()
        before = self.state()
        with self.assertRaises(BudgetError):
            self.amend()
        self.assertEqual(self.state(), before)

    def test_wrong_metadata_is_rejected_without_changes(self):
        for key, value in [('limit_credits', '65'), ('mode', 'offline'), ('quotas', '{}'),
                           ('max_attempts', '4276'), ('retry_limit', '101'), ('frozen_reason', 'Stopped')]:
            with self.subTest(key=key):
                with closing(sqlite3.connect(self.path)) as db:
                    old = db.execute('SELECT value FROM metadata WHERE key=?', (key,)).fetchone()[0]
                    db.execute('UPDATE metadata SET value=? WHERE key=?', (value, key))
                    db.commit()
                before = self.state()
                with self.assertRaises(BudgetError):
                    self.amend()
                self.assertEqual(self.state(), before)
                with closing(sqlite3.connect(self.path)) as db:
                    db.execute('UPDATE metadata SET value=? WHERE key=?', (old, key))
                    db.commit()

    def test_pending_pilot_and_main_attempts_are_rejected(self):
        for field, value in [('status', 'pending'), ('phase', 'pilot'), ('phase', 'main')]:
            with self.subTest(field=field, value=value):
                with closing(sqlite3.connect(self.path)) as db:
                    attempt_id, old = db.execute(f'SELECT id,{field} FROM attempts LIMIT 1').fetchone()
                    db.execute(f'UPDATE attempts SET {field}=? WHERE id=?', (value, attempt_id))
                    db.commit()
                before = self.state()
                with self.assertRaises(BudgetError):
                    self.amend()
                self.assertEqual(self.state(), before)
                with closing(sqlite3.connect(self.path)) as db:
                    db.execute(f'UPDATE attempts SET {field}=? WHERE id=?', (old, attempt_id))
                    db.commit()

    def test_changed_diagnostic_hash_is_rejected(self):
        path = self.diag / 'budget.json'
        value = diagnostic.read_json(path)
        value['events'][0]['reserved_credits'] = '0'
        diagnostic.durable_json(path, value)
        before = self.state()
        with self.assertRaises(BudgetError):
            self.amend()
        self.assertEqual(self.state(), before)

    def test_missing_technical_success_for_one_model_is_rejected(self):
        model = diagnostic.MODELS[0]
        path = self.diag / 'attempts' / f'reasoning_none__{model}' / 'raw_response.json'
        value = diagnostic.read_json(path)
        value['reasoning']['effort'] = 'low'
        diagnostic.durable_json(path, value)
        before = self.state()
        with self.assertRaises(BudgetError):
            self.amend()
        self.assertEqual(self.state(), before)

    def test_active_diagnostic_lock_is_rejected(self):
        with diagnostic.directory_lock(self.diag):
            with self.assertRaises(BudgetError):
                self.amend()


if __name__ == '__main__':
    unittest.main()
