"""Prospective worker-choice parser with a strict and an execution result.

Recovery accepts one terminal JSON object, optionally in a paired code fence.
It never repairs JSON, chooses between objects, or makes a model call.
"""
from __future__ import annotations

import json
import re


def _unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON key')
        result[key] = value
    return result


def _nonfinite(value):
    raise ValueError('Non-finite JSON value')


def _decode_choice(text, episode):
    if not isinstance(text, str):
        return None
    try:
        value = json.loads(text, object_pairs_hook=_unique, parse_constant=_nonfinite)
    except (ValueError, TypeError, RecursionError):
        return None
    if (not isinstance(value, dict) or set(value) != {'worker_id'}
            or not isinstance(value['worker_id'], str)
            or value['worker_id'] not in episode['worker_ids']):
        return None
    return value['worker_id']


def strict_choice(text, episode):
    """Return a roster ID only when the entire response is the required JSON."""
    return _decode_choice(text, episode)


_FENCE_MARKER = re.compile(r'`{3,}|~{3,}')
_OPEN_FENCE = re.compile(r'(?:^|\n)[ \t]*(?P<marker>`{3,}|~{3,})'
                         r'[ \t]*[A-Za-z0-9_+.-]*[ \t]*\r?\n[ \t\r\n]*\Z')


def _safe_prose(prefix):
    """Do not extract from a quoted JSON string, array, or earlier code fence.

    Balanced prose quotations and bracketed prose labels are allowed. A bare
    brace anywhere outside the candidate is rejected by the caller, so a second
    object or a malformed object cannot be ignored as prose.
    """
    if _FENCE_MARKER.search(prefix):
        return False
    quoted, escaped, brackets = False, False, 0
    for char in prefix:
        if escaped:
            escaped = False
            continue
        if char == '\\' and quoted:
            escaped = True
        elif char == '"':
            quoted = not quoted
        elif not quoted and char == '[':
            brackets += 1
        elif not quoted and char == ']':
            brackets -= 1
            if brackets < 0:
                return False
    return not quoted and brackets == 0


def parse_choice_record(text, episode):
    """Return raw text, worker ID, strict/execution flags, and extraction method.

    A caller with no received response can pass None, then mark that record as
    transport_failure. This module does not infer a transport status.
    """
    selected = strict_choice(text, episode)
    record = {'raw_text': text, 'worker_id': selected, 'strict_valid': selected is not None,
              'execution_valid': selected is not None,
              'extraction_method': 'strict_json' if selected is not None else 'rejected'}
    if selected is not None or not isinstance(text, str):
        return record

    # There must be one complete object, not a nested object, a choice among
    # several objects, or the last valid fragment of malformed JSON.
    if text.count('{') != 1 or text.count('}') != 1:
        return record
    start, end = text.index('{'), text.index('}') + 1
    if end <= start:
        return record
    selected = _decode_choice(text[start:end], episode)
    if selected is None:
        return record
    prefix, suffix = text[:start], text[end:]
    if not suffix.strip():
        if not _safe_prose(prefix):
            return record
        method = 'terminal_json'
    else:
        opening = _OPEN_FENCE.search(prefix)
        if opening is None or not _safe_prose(prefix[:opening.start()]):
            return record
        marker = opening['marker']
        # Markdown permits a closing fence at least as long as its opener.
        closing = r'\s*' + re.escape(marker[0]) + '{' + str(len(marker)) + r',}\s*'
        if re.fullmatch(closing, suffix) is None:
            return record
        method = 'fenced_json'
    record.update(worker_id=selected, execution_valid=True, extraction_method=method)
    return record


def parse_choice(text, episode):
    """Return the executable roster ID, or None for an unrecovered response."""
    return parse_choice_record(text, episode)['worker_id']
