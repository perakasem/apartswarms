"""Check the public price table. This request does not use an API key."""
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
from html.parser import HTMLParser
import re
import ssl
import urllib.request

from .transport import MODEL_PRICES

SOURCE = 'https://docs.adaptionlabs.ai/inference-stacks/models/'


class Table(HTMLParser):
    def __init__(self):
        super().__init__(); self.rows=[]; self.row=None; self.cell=None
    def handle_starttag(self, tag, attrs):
        if tag == 'tr': self.row=[]
        if tag in ('td','th') and self.row is not None: self.cell=[]
    def handle_data(self, value):
        if self.cell is not None: self.cell.append(value)
    def handle_endtag(self, tag):
        if tag in ('td','th') and self.cell is not None:
            self.row.append(''.join(self.cell).strip()); self.cell=None
        if tag == 'tr' and self.row is not None:
            self.rows.append(self.row); self.row=None


def parse_prices(html):
    parser=Table(); parser.feed(html)
    found={}
    for row in parser.rows:
        if len(row) != 3 or row[0] not in MODEL_PRICES: continue
        incoming=re.fullmatch(r'([0-9]+\.[0-9]+)(?:\s*\([0-9]+\.[0-9]+\))?', row[1])
        outgoing=re.fullmatch(r'[0-9]+\.[0-9]+', row[2])
        if incoming and outgoing:
            if row[0] in found: raise ValueError('The price table has duplicate model rows')
            found[row[0]]={'input':incoming.group(1), 'output':outgoing.group(0)}
    if set(found) != set(MODEL_PRICES):
        raise ValueError('The price table does not contain both fixed model prices')
    for model, prices in found.items():
        for direction, value in prices.items():
            if Decimal(value) != Decimal(MODEL_PRICES[model][direction]):
                raise ValueError('A model price changed. Stop before paid calls')
    return found


def check_public_prices():
    import certifi
    context=ssl.create_default_context(cafile=certifi.where())
    with urllib.request.urlopen(SOURCE, context=context, timeout=30) as response:
        raw=response.read(2_000_001)
        if response.status != 200 or len(raw)>2_000_000:
            raise ValueError('The public price check failed')
    html=raw.decode('utf-8')
    return {'checked_utc':datetime.now(timezone.utc).isoformat(), 'source':SOURCE,
            'http_status':200, 'sha256':hashlib.sha256(raw).hexdigest(),
            'unit':'credits per million tokens', 'model_prices':parse_prices(html),
            'cached_discount_assumed':False, 'inference_calls':0,
            'retrieval':'HTTPS with certificate verification via certifi'}
