"""Bind the one approved prompt study to one result folder before inference."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re

from .ledger import canonical, record_hash, validate_carry, QUOTAS, RETRY_LIMIT, MAX_ATTEMPTS
from .transport import INPUT_CAP, OUTPUT_CAP, MODEL_PRICES


class AuthorizationError(RuntimeError):
    pass


def _sync_directory(path):
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def claim_authorization(base, result_root, carry, *, source_hashes=None):
    """Claim once, after all setup checks and before the first paid request.

    The claim remains after completion, interruption, or a later setup failure.
    A second invocation never resumes or replaces it, even for the same root.
    All live entry points must use the same study package base directory.
    """
    base = Path(base).resolve()
    root = Path(result_root).resolve()
    prior = validate_carry(carry, 'live')
    hashes = {} if source_hashes is None else source_hashes
    if (not isinstance(hashes, dict) or not hashes
            or any(not isinstance(key, str) or not key or Path(key).is_absolute() or '..' in Path(key).parts
                   or not isinstance(value, str) or not re.fullmatch(r'[a-f0-9]{64}', value)
                   for key, value in hashes.items())):
        raise ValueError('Source hashes must be a nonempty relative-path SHA256 dictionary')
    claim_root = base / 'results' / 'prompt_authorization'
    if root == claim_root or claim_root in root.parents or root in claim_root.parents:
        raise ValueError('The result folder cannot contain the authorization record')
    receipt = {'schema': 'prompt-authorization-1', 'protocol': 'prompt-comparison-1.0',
               'result_root': str(root), 'prior_carry_sha256': record_hash(prior),
               'global_limit_credits': '100', 'new_limit_credits': '60',
               'input_cap': INPUT_CAP, 'output_cap': OUTPUT_CAP, 'model_prices': MODEL_PRICES,
               'quotas': QUOTAS, 'retry_limit': RETRY_LIMIT, 'max_attempts': MAX_ATTEMPTS,
               'source_hashes': hashes, 'automatic_release': False,
               'claimed_utc': datetime.now(timezone.utc).isoformat()}
    # Complete validation and serialization before creating the permanent claim.
    payload = canonical(receipt) + '\n'
    claim_root.parent.mkdir(parents=True, exist_ok=True)
    try:
        claim_root.mkdir(mode=0o700)
    except FileExistsError:
        raise AuthorizationError('This prompt-study authorization is already claimed. Another live run is blocked') from None
    # Do not remove the directory if a later operation fails. An uncertain claim
    # must prevent another process from starting paid work under the same limit.
    _sync_directory(claim_root.parent)
    descriptor = os.open(claim_root / 'claim.json', os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, 'w', encoding='utf-8') as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())
    _sync_directory(claim_root)
    return json.loads(payload)
