import json
import unittest
from unittest.mock import patch

from prompt_study.environment import CONDITIONS, generate_episode, outcome
from prompt_study.parser import parse_choice, parse_choice_record, strict_choice


class ChoiceParserTests(unittest.TestCase):
    def setUp(self):
        self.episode = generate_episode(4001, CONDITIONS[0])
        self.worker, self.other = self.episode['worker_ids'][:2]
        self.object = json.dumps({'worker_id': self.worker})

    def accepted(self, text, method, strict=False):
        record = parse_choice_record(text, self.episode)
        self.assertEqual(record, {'raw_text': text, 'worker_id': self.worker,
                                  'strict_valid': strict, 'execution_valid': True,
                                  'extraction_method': method})
        self.assertEqual(parse_choice(text, self.episode), self.worker)
        self.assertEqual(strict_choice(text, self.episode), self.worker if strict else None)

    def rejected(self, text):
        record = parse_choice_record(text, self.episode)
        self.assertEqual(record, {'raw_text': text, 'worker_id': None,
                                  'strict_valid': False, 'execution_valid': False,
                                  'extraction_method': 'rejected'})
        self.assertIsNone(parse_choice(text, self.episode))
        self.assertIsNone(strict_choice(text, self.episode))

    def test_strict_object_and_surrounding_whitespace(self):
        self.accepted(self.object, 'strict_json', True)
        self.accepted(' \t\n' + self.object + '\r\n ', 'strict_json', True)

    def test_terminal_object_after_prose(self):
        self.accepted('I select the listed worker.\n' + self.object + '\n', 'terminal_json')
        self.accepted('My selection: ' + self.object, 'terminal_json')

    def test_balanced_quoted_and_bracketed_prose(self):
        self.accepted('I checked the "worker" record. [Selection]\n' + self.object, 'terminal_json')

    def test_bare_and_json_code_fences(self):
        for label in ('', 'json', 'JSON', 'javascript'):
            self.accepted('```' + label + '\n' + self.object + '\n```', 'fenced_json')

    def test_fenced_object_after_prose(self):
        self.accepted('The worker meets the requirements.\n```json\n' + self.object + '\n```\n', 'fenced_json')

    def test_fence_whitespace_line_endings_and_longer_closer(self):
        self.accepted('  ```json \r\n\t' + self.object + '\r\n   ``` \r\n', 'fenced_json')
        self.accepted('````json\n' + self.object + '\n`````', 'fenced_json')
        self.accepted('~~~json\n' + self.object + '\n~~~', 'fenced_json')

    def test_unpaired_or_mismatched_fences(self):
        for text in ('```json\n' + self.object, self.object + '\n```',
                     '```json\n' + self.object + '\n~~~',
                     '````json\n' + self.object + '\n```',
                     '```json\n' + self.object + '\n```\n```',
                     '```json\nReason first.\n' + self.object + '\n```'):
            with self.subTest(text=text):
                self.rejected(text)

    def test_trailing_prose_or_punctuation(self):
        for suffix in ('.', '\nDone.', '\nThank you.', '\n# comment', ' null'):
            self.rejected('I choose:\n' + self.object + suffix)
        self.rejected('```json\n' + self.object + '\n```\nDone.')

    def test_multiple_objects_are_never_resolved(self):
        other = json.dumps({'worker_id': self.other})
        for prefix in (self.object, other, '{}', '{"note":"example"}'):
            self.rejected(prefix + '\nFinal choice:\n' + self.object)
            self.rejected(prefix + '\n```json\n' + self.object + '\n```')

    def test_duplicate_keys_rejected_in_strict_and_recovered_objects(self):
        for key in ('worker_id', r'\u0077orker_id'):
            for value in (self.worker, self.other):
                duplicate = '{"worker_id":' + json.dumps(self.worker) + ',"' + key + '":' + json.dumps(value) + '}'
                for text in (duplicate, 'I choose:\n' + duplicate, '```json\n' + duplicate + '\n```'):
                    self.rejected(text)

    def test_extra_fields_and_unknown_ids(self):
        for value in ({'worker_id': self.worker, 'reason': 'yes'}, {'worker_id': 'UNKNOWN'},
                      {'worker_id': self.worker.lower()}, {'worker_id': True}, {'worker_id': None},
                      {'worker_id': [self.worker]}, {'worker_id': {'worker_id': self.worker}}, {}):
            text = json.dumps(value)
            self.rejected(text)
            self.rejected('Selection:\n' + text)

    def test_arrays_and_outer_objects_are_not_unwrapped(self):
        for text in ('[' + self.object + ']', '[' + self.object,
                     '{"choice":' + self.object + '}', '{"choice":' + self.object):
            self.rejected(text)

    def test_malformed_json_is_not_repaired(self):
        bad = [self.object[:-1], self.object[:-1] + ',}', self.object.replace('"', "'"),
               self.object.replace(':', '='), self.object + '}', '{' + self.object,
               '{"worker_id":}', '{"worker_id": NaN}', '{"worker_id": Infinity}',
               '{"worker_id": -Infinity}']
        for text in bad:
            self.rejected(text)
            self.rejected('Selection:\n' + text)

    def test_malformed_prefix_objects_are_not_discarded(self):
        for prefix in ('{bad JSON}\n', '{"worker_id":\n', '}\n'):
            self.rejected(prefix + self.object)

    def test_quoted_object_is_not_treated_as_an_action(self):
        self.rejected(json.dumps(self.object))
        self.rejected('"' + self.object)
        self.rejected('"' + self.object + '"')

    def test_json_escapes_are_decoded_before_schema_checks(self):
        escaped = '{"\\u0077orker_id":' + json.dumps(self.worker) + '}'
        self.accepted(escaped, 'strict_json', True)
        self.accepted('Selection:\n' + escaped, 'terminal_json')

    def test_empty_plain_id_and_nontext_are_not_executed(self):
        for text in ('', ' ', self.worker, 'I select ' + self.worker, None, 123, True, [], {}):
            self.rejected(text)

    def test_no_received_response_is_not_inferred_as_transport_status(self):
        record = parse_choice_record(None, self.episode)
        self.assertIsNone(record['raw_text'])
        self.assertEqual(record['extraction_method'], 'rejected')

    def test_parser_does_not_depend_on_prompt_arm(self):
        text = 'Selection:\n```json\n' + self.object + '\n```'
        records = [parse_choice_record(text, generate_episode(4001, condition)) for condition in CONDITIONS]
        self.assertTrue(all(record == records[0] for record in records))

    def test_recovery_does_not_change_the_fixed_worker_score(self):
        number = next(n for n, task in enumerate(self.episode['tasks'], 1) if task['requires_objection'])
        for worker in self.episode['worker_ids']:
            text = json.dumps({'worker_id': worker})
            strict = parse_choice(text, self.episode)
            recovered = parse_choice('Selection:\n' + text, self.episode)
            self.assertEqual(outcome(self.episode, number, strict), outcome(self.episode, number, recovered))

    def test_no_network_is_used(self):
        with patch('socket.create_connection', side_effect=AssertionError('Network disabled')), \
             patch('socket.socket.connect', side_effect=AssertionError('Network disabled')):
            self.accepted('Selection:\n' + self.object, 'terminal_json')


if __name__ == '__main__':
    unittest.main()
