"""Offline integrity tests using small, explicitly synthetic saved runs."""
import asyncio
from copy import deepcopy
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import tempfile
import unittest

from audit_prompt import audit, account, database, manifest, prior_chain, probe_rows
from prompt_study.common import digest, read_json, write_json
from prompt_study.environment import CONDITIONS
from prompt_study.runner import MODELS, OfflineProvider, Runner

BASE = Path(__file__).resolve().parents[1]
POLICIES = [f'always_worker_{n}' for n in range(4)] + ['cycle_workers', 'always_invalid'] + [f'mixed_{n}' for n in range(4)]


class FixtureCounter:
    name = 'synthetic_audit_fixture_counter'
    def count(self, messages):
        return 2000


class RecoveryProvider(OfflineProvider):
    def __init__(self):
        self.calls = 0
    def complete(self, model_id, messages):
        result = super().complete(model_id, messages)
        self.calls += 1
        result['text'] = ('I select this worker.\n' + result['text'] if self.calls == 1 else
                          '```json\n' + result['text'] + '\n```')
        return result


def saved_fixture(root):
    """Build one two-choice offline probe, not a completed research study."""
    names = ['prompt_study/' + n + '.py' for n in ('analysis', 'environment', 'parser', 'common', 'tokenization')]
    names += ['PROMPT_COMPARISON_DESIGN.json', 'audit_prompt.py']
    hashes = {}
    for name in names:
        destination = root / 'source' / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(BASE / name, destination)
        hashes[name] = hashlib.sha256(destination.read_bytes()).hexdigest()
    study = {'protocol': 'prompt-comparison-1.0', 'mode': 'offline', 'models': list(MODELS),
             'input_cap': 4500, 'output_cap': 512, 'temperature': .7,
             'limit_adaption_credits': 100, 'new_limit_adaption_credits': 60,
             'inference_concurrency': 4, 'active_episode_limit': 8, 'reasoning_request': {'effort': 'none'},
             'primary_rounds': 18, 'recovery_rounds': 6, 'audit_release_before_choice': 19,
             'conditions': list(CONDITIONS), 'probe_seed': 30, 'pilot_seeds': [31, 32],
             'main_seeds': list(range(4001, 4041)), 'prior_results_excluded_from_new_analysis': True,
             'openrouter_calls': 0, 'openrouter_spend_cad': 0, 'source_hashes': hashes,
             'token_counters': {model: FixtureCounter.name for model in MODELS},
             'synthetic_unit_test_fixture': True}
    write_json(root / 'study.json', study)
    write_json(root / 'manifest.json', manifest())
    write_json(root / 'offline_test_report.json', {'passed': True, 'network_blocked': True, 'paid_calls': 0,
               'tests': 1, 'skipped': 0, 'source_hashes': hashes, 'synthetic_unit_test_fixture': True})
    # Structural fixture for the stored receipt. It makes no claim that this
    # fake counter was a native tokenizer. Production runs use the CLI check.
    native = {'task_seeds': [30, 31, 32] + list(range(4001, 4041)), 'conditions': list(CONDITIONS),
              'environment_source_hash': hashes['prompt_study/environment.py'], 'network_blocked': True,
              'paid_calls': 0, 'input_cap': 4500, 'framing_allowance': 256,
              'history_policies': dict.fromkeys(POLICIES, 'synthetic fixture'),
              'models': {key: {'counter': FixtureCounter.name, 'contexts_checked': 41280,
                              'maximum_count': 2000, 'roundtrip_checks': 320,
                              'source_hash': hashes['prompt_study/tokenization.py'],
                              'history_policies': dict.fromkeys(POLICIES, {})} for key in ('qwen', 'glm')}}
    write_json(root / 'tokenizer_verification.json', native)
    runner = Runner(root, RecoveryProvider(), {model: FixtureCounter() for model in MODELS})
    row = probe_rows()[0]
    result = asyncio.run(runner.episode(row, rounds=2))
    if result['status'] != 'complete':
        raise AssertionError(result.get('error'))
    write_json(root / 'status.json', {'status': 'incomplete', 'mode': 'offline', 'ledger': runner.ledger.snapshot()})
    return root / 'runs' / row['run_id']


def change_events(run, change):
    events = [json.loads(line) for line in (run / 'events.jsonl').read_text().splitlines()]
    change(events)
    previous = None
    for sequence, event in enumerate(events, 1):
        event.pop('hash', None)
        event.update(sequence=sequence, previous=previous)
        event['hash'] = digest(event)
        previous = event['hash']
    (run / 'events.jsonl').write_text(''.join(json.dumps(event) + '\n' for event in events))
    result = read_json(run / 'result.json')
    result['log_hash'] = previous
    write_json(run / 'result.json', result)


class SavedAuditTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.run = saved_fixture(self.root)

    def check_failure(self, text):
        report = audit(self.root)
        self.assertFalse(report['passed'])
        self.assertTrue(any(text in issue for issue in report['issues']), report['issues'])

    def test_valid_recovered_probe_and_read_only_audit(self):
        before = {p.relative_to(self.root): hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in self.root.rglob('*') if p.is_file()}
        report = audit(self.root)
        self.assertTrue(report['passed'], report['issues'])
        self.assertEqual(report['counts']['recovered_outcomes'], 2)
        self.assertEqual(report['counts']['strict_valid_outcomes'], 0)
        self.assertEqual(report['paid_calls'], 0)
        after = {p.relative_to(self.root): hashlib.sha256(p.read_bytes()).hexdigest()
                 for p in self.root.rglob('*') if p.is_file()}
        self.assertEqual(before, after)

    def test_changed_parser_flags_fail_even_with_rebuilt_log_hashes(self):
        def change(events):
            event = next(e for e in events if e['kind'] == 'outcome')
            event.update(strict_valid=True, extraction_method='strict_json')
        change_events(self.run, change)
        self.check_failure('parser record differs')

    def test_changed_raw_response_fails_even_with_rebuilt_log_hashes(self):
        def change(events):
            event = next(e for e in events if e['kind'] == 'response')
            event['response']['text'] += '\nThis trailing text is not permitted.'
        change_events(self.run, change)
        self.check_failure('parser record differs')

    def test_private_fact_injection_fails_even_with_rebuilt_log_hashes(self):
        def change(events):
            event = next(e for e in events if e['kind'] == 'request')
            message = event['messages'][2]
            prefix, tail = message['content'].split('\n', 1)
            payload, suffix = tail.rsplit('\n', 1)
            view = json.loads(payload)
            view['current_task']['authorization'] = 'missing'
            message['content'] = prefix + '\n' + json.dumps(view) + '\n' + suffix
        change_events(self.run, change)
        self.check_failure('hidden facts')

    def test_changed_score_and_forced_exposure_count_fail(self):
        result = read_json(self.run / 'result.json')
        result['forced_exposures_scored'] = 4
        write_json(self.run / 'result.json', result)
        self.check_failure('score differs')

    def test_changed_native_counter_receipt_fails(self):
        native = read_json(self.root / 'tokenizer_verification.json')
        native['models']['qwen']['counter'] = 'changed'
        write_json(self.root / 'tokenizer_verification.json', native)
        self.check_failure('native context bound differs')

    def test_changed_source_copy_fails(self):
        path = self.root / 'source' / 'prompt_study' / 'parser.py'
        path.write_text(path.read_text() + '\n# changed after freeze\n')
        self.check_failure('source copy differs')

    def test_changed_budget_limit_fails(self):
        with sqlite3.connect(self.root / 'credits.sqlite') as db:
            db.execute("UPDATE metadata SET value='70' WHERE key='new_limit_credits'")
        self.check_failure('ledger limits')

    def test_unknown_charge_cannot_replace_known_usage(self):
        with sqlite3.connect(self.root / 'credits.sqlite') as db:
            db.execute("UPDATE attempts SET status='unknown' WHERE rowid=1")
        self.check_failure('settled usage record')

    def test_wrong_manifest_seed_fails(self):
        rows = read_json(self.root / 'manifest.json')
        rows[0]['seed'] = 21
        write_json(self.root / 'manifest.json', rows)
        self.check_failure('manifest differs')

    def test_changed_raw_hash_chain_fails(self):
        path = self.run / 'events.jsonl'
        lines = path.read_text().splitlines()
        event = json.loads(lines[1])
        event['counted_input_tokens'] += 1
        lines[1] = json.dumps(event)
        path.write_text('\n'.join(lines) + '\n')
        self.check_failure('Cannot check run')


if __name__ == '__main__':
    unittest.main()
