import asyncio
from pathlib import Path
import tempfile
import unittest

from prompt_study.common import read_json, read_log
from prompt_study.pacing import GlobalPacer, PacingStopped


class FakeClock:
    def __init__(self):
        self.value = 0.0
        self.waits = []

    def __call__(self):
        return self.value

    async def sleep(self, delay):
        self.waits.append(delay)
        self.value += delay
        await asyncio.sleep(0)


class PacingTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.clock = FakeClock()
        self.pacer = GlobalPacer(self.temp.name, clock=self.clock, sleep=self.clock.sleep)

    async def test_no_startup_or_idle_burst_and_four_per_second(self):
        tickets = [await self.pacer.wait() for _ in range(8)]
        self.assertEqual([ticket.dispatched_at for ticket in tickets],
                         [.25, .5, .75, 1, 1.25, 1.5, 1.75, 2])
        self.clock.value += 100
        after_idle = [await self.pacer.wait() for _ in range(3)]
        self.assertEqual([ticket.dispatched_at for ticket in after_idle], [102, 102.25, 102.5])

    async def test_concurrent_waiters_share_one_smooth_gate(self):
        tickets = await asyncio.gather(*(self.pacer.wait() for _ in range(12)))
        times = sorted(ticket.dispatched_at for ticket in tickets)
        self.assertGreaterEqual(times[0], .25)
        self.assertTrue(all(b - a >= .25 for a, b in zip(times, times[1:])))
        self.assertEqual(self.pacer.dispatches, 12)

    async def test_first_429_honors_retry_after_and_halves_rate(self):
        ticket = await self.pacer.wait()
        before = self.clock()
        state = await self.pacer.on_rate_limit(ticket, 90)
        self.assertEqual(state['rate_limit_cycles'], 1)
        self.assertEqual(state['rate_per_second'], 2)
        self.assertEqual(state['cooldown_remaining_seconds'], 90)
        first = await self.pacer.wait()
        second = await self.pacer.wait()
        self.assertGreaterEqual(first.dispatched_at - before, 90)
        self.assertGreaterEqual(second.dispatched_at - first.dispatched_at, .5)

    async def test_multiple_inflight_429_responses_count_as_one_cycle(self):
        tickets = [await self.pacer.wait() for _ in range(4)]
        await self.pacer.on_rate_limit(tickets[0], 1)
        self.clock.value += 2
        for ticket in tickets[1:]:
            await self.pacer.on_rate_limit(ticket, 1)
        self.assertEqual(self.pacer.rate_limit_cycles, 1)
        self.assertEqual(self.pacer.rate, 2)
        self.assertEqual(self.pacer.snapshot()['cooldown_remaining_seconds'], 60)
        kinds = [event['kind'] for event in read_log(Path(self.temp.name) / 'pacing.jsonl')]
        self.assertEqual(kinds.count('rate_limit'), 1)
        self.assertEqual(kinds.count('same_surge_rate_limit'), 3)

    async def test_two_slowdowns_then_stop_on_third_new_cycle(self):
        for cycle, rate in ((1, 2), (2, 1), (3, 1)):
            ticket = await self.pacer.wait()
            state = await self.pacer.on_rate_limit(ticket, None)
            self.assertEqual(state['rate_limit_cycles'], cycle)
            self.assertEqual(state['rate_per_second'], rate)
            self.assertEqual(state['stopped'], cycle == 3)
        with self.assertRaises(PacingStopped):
            await self.pacer.wait()
        saved = read_json(Path(self.temp.name) / 'throttle.json')
        self.assertTrue(saved['stopped'])
        self.assertEqual(saved['rate_limit_cycles'], 3)

    async def test_queued_request_checks_stop_after_wait(self):
        stopped = [False]
        async def stop_during_sleep(delay):
            self.clock.value += delay
            stopped[0] = True
        self.pacer.sleep = stop_during_sleep
        with self.assertRaises(PacingStopped):
            await self.pacer.wait(stop=lambda: stopped[0])
        self.assertEqual(self.pacer.dispatches, 0)

    async def test_invalid_retry_after_uses_minimum_cooldown(self):
        ticket = await self.pacer.wait()
        for delay in (None, -1, True, float('nan'), float('inf'), '100'):
            with self.subTest(delay=delay):
                await self.pacer.on_rate_limit(ticket, delay)
                self.assertEqual(self.pacer.snapshot()['cooldown_remaining_seconds'], 60)

    async def test_offline_mode_does_not_sleep(self):
        async def forbidden_sleep(delay):
            raise AssertionError('Offline pacing must not sleep')
        pacer = GlobalPacer(Path(self.temp.name) / 'offline', enabled=False,
                            clock=self.clock, sleep=forbidden_sleep)
        tickets = await asyncio.gather(*(pacer.wait() for _ in range(100)))
        self.assertTrue(all(ticket.dispatched_at == 0 for ticket in tickets))
        self.assertEqual(pacer.dispatches, 0)
