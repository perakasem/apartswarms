from pathlib import Path
import tempfile
import unittest

from prompt_study.analysis import CONDITIONS, MODELS, aggregate, summarize_run
from prompt_study.common import write_json
from prompt_study.environment import generate_episode, outcome
from prompt_study.reporting import write_report


class ReportingTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)

    def rows(self):
        rows=[]
        for condition in CONDITIONS:
            episode=generate_episode(4001,condition)
            worker=next(w for w,p in episode['worker_policies'].items() if p=='careful')
            turns=[{'round':n,'worker_id':worker,'invalid':False,'outcome':outcome(episode,n,worker),
                    'raw_text':'{}','strict_valid':True,'execution_valid':True,'extraction_method':'strict_json'} for n in range(1,25)]
            turns[0].update(raw_text='Prose {}',strict_valid=False,extraction_method='terminal_json')
            rows.append(dict(summarize_run(episode,turns,'complete'),phase='main',model_id=MODELS[0]))
        return rows

    def test_offline_report_has_no_live_claim_and_full_missing_bounds(self):
        write_json(self.root/'analysis.json',aggregate([],expected_seeds=[4001],samples=5))
        report=write_report(self.root,{'status':'complete','mode':'offline','ledger':{
            'mode':'offline','limit_credits':'100','new_limit_credits':'60','new_remaining_credits':'60',
            'estimated_charged_credits':'0','pending_credits':'0','unknown_credits':'0','attempts':0}}).read_text()
        self.assertIn('Offline simulation report',report);self.assertIn('not live model findings',report)
        self.assertIn('[-200.00, 200.00]',report)
        self.assertIn('New-study credit limit: 60. Global credit limit: 100',report)
        self.assertIn('not_assessable_incomplete_primary',report)
        self.assertIn('T inference is approximate',report)
        self.assertIn('A general prompt main effect alone does not establish selection against safety',report)

    def test_live_report_has_operational_recovery_and_primary_fields(self):
        rows=self.rows()
        write_json(self.root/'results.json',rows)
        write_json(self.root/'analysis.json',aggregate(rows,expected_seeds=[4001],samples=5))
        write_json(self.root/'pilot.json',{'passed':True,'results':[{'status':'complete','valid_turns':24,'observed_turns':24}]})
        report=write_report(self.root,{'status':'complete','mode':'live'}).read_text()
        self.assertIn('Live prompt-comparison report',report)
        self.assertIn('| qwen3.5-397b | 4/4 | 96 | 92 | 4 | 4 | 0 | 0 | 0 |',report)
        self.assertIn('18 scheduled slots and nine risky tasks',report)
        self.assertIn('valid assignments 24; invalid assignments 0',report)
        self.assertIn('Both intervals are unadjusted',report)
        self.assertIn('neutral_risk_gap_lower_bound',report)
        self.assertIn('Full masking decision: `not_assessable_under_t_rule`',report)
        self.assertIn('Provider billing is not verified',report)
        self.assertIn('one live coordinator and four local workers',report)

    def test_prior_and_current_costs_stay_distinct(self):
        prior={'estimated_charged_credits':'24.34591530','pending_credits':'0','unknown_credits':'9.611280',
               'committed_credits':'33.95719530','attempts':13052}
        current={'estimated_charged_credits':'.1','pending_credits':'.2','unknown_credits':'.3','committed_credits':'.6','attempts':8}
        ledger={'mode':'live','current':current,'carried':prior,'limit_credits':'100','new_limit_credits':'60',
                'estimated_charged_credits':'24.44591530','pending_credits':'.2','unknown_credits':'9.911280',
                'committed_credits':'34.55719530','remaining_credits':'65.44280470','new_remaining_credits':'59.4','attempts':13060}
        report=write_report(self.root,{'status':'running','ledger':ledger}).read_text()
        self.assertIn('| Earlier work, carried | 24.3459153 | 0 | 9.61128 | 33.9571953 | 13052 |',report)
        self.assertIn('| Current prompt comparison | 0.1 | 0.2 | 0.3 | 0.6 | 8 |',report)
        self.assertIn('| All studies | 24.4459153 | 0.2 | 9.91128 | 34.5571953 | 13060 |',report)
        self.assertIn('59.4',report);self.assertIn('65.4428047',report)
        self.assertIn('Earlier study data are not part of this sample',report)
        self.assertIn('OpenRouter spend from this runner: CAD$0',report)

    def test_old_schedule_is_rejected(self):
        for row in [{'phase':'main','seed':3001,'condition':'neutral_worker'},
                    {'phase':'main','seed':4001,'condition':'worker_delayed'}]:
            write_json(self.root/'results.json',[row])
            with self.assertRaises(ValueError):write_report(self.root,{'mode':'live'})

    def test_partial_status_reports_unrun_slots_not_zero_outcomes(self):
        write_json(self.root/'status.json',{'status':'running','mode':'live'})
        write_json(self.root/'runs/one/result.json',{'phase':'main','model_id':'glm-5.2','seed':4001,
            'condition':'neutral_worker','complete':False,'valid_assignments':3,'invalid_actions':1,'recorded_rounds':4})
        report=write_report(self.root,{'status':'incomplete'}).read_text()
        self.assertIn('Saved run status: `incomplete`',report)
        self.assertIn('| glm-5.2 | 0/160 | 3 | unknown | unknown | unknown | 1 | unknown | 3836 |',report)
        self.assertIn('Main analysis is not available. Missing values are not zero.',report)
        self.assertIn('unknown safety outcome',report)


if __name__=='__main__':unittest.main()
