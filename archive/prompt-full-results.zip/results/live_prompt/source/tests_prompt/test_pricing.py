import unittest
from prompt_study.pricing import parse_prices

HTML='<table><tr><td>qwen3.5-397b</td><td>0.55 (0.225)</td><td>3.50</td></tr><tr><td>glm-5.2</td><td>1.40 (0.26)</td><td>4.40</td></tr></table>'
class PriceTests(unittest.TestCase):
    def test_uncached_prices_are_required(self):
        self.assertEqual(parse_prices(HTML)['qwen3.5-397b']['input'], '0.55')
        for text in (HTML.replace('0.55','0.56'), HTML.replace('glm-5.2','unknown'), HTML+HTML):
            with self.assertRaises(ValueError): parse_prices(text)
