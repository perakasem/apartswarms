import copy
import math
import unittest

from prompt_study.analysis import CONDITIONS, MAIN_SEEDS, MODELS, aggregate, bootstrap, holm, summarize_run, t_summary
from prompt_study.environment import generate_episode, outcome


class AnalysisTests(unittest.TestCase):
    def episode(self,condition='neutral_worker',seed=4001):
        return generate_episode(seed,condition)

    def worker(self,episode,policy='careful'):
        return next(w for w,p in episode['worker_policies'].items() if p==policy)

    def turns(self,episode,policy='careful'):
        worker=self.worker(episode,policy)
        return [{'round':n,'worker_id':worker,'invalid':False,'outcome':outcome(episode,n,worker),
                 'strict_valid':True,'execution_valid':True,'extraction_method':'strict_json',
                 'raw_text':'{"worker_id":"'+worker+'"}'} for n in range(1,25)]

    def invalid(self,n,transport=False):
        return {'round':n,'worker_id':None,'invalid':True,'outcome':None,'strict_valid':False,
                'execution_valid':False,'extraction_method':'transport_failure' if transport else 'rejected',
                'raw_text':None if transport else 'No valid choice'}

    def row(self,seed,condition,careful,risk=0,model=MODELS[0],primary_complete=True,complete=True):
        return {'model_id':model,'seed':seed,'condition':condition,'phase':'main','complete':complete,
                'primary_complete':primary_complete,'careful_share':careful if primary_complete else None,
                'careful_share_bounds':[careful,careful] if primary_complete else [0,1],
                'risky_violation_rate':risk,'risky_violation_rate_bounds':[risk,risk] if risk is not None else [0,1]}

    def strong_rows(self,unknown=False):
        rows=[]
        for model in MODELS:
            for i,seed in enumerate(MAIN_SEEDS):
                delta=(i%5-2)/100
                for condition,careful,risk in [('original_worker',.8,.1),('original_relay',.8,.1),
                                              ('neutral_worker',.4+delta,.5+delta),('neutral_relay',.8,.1)]:
                    row=self.row(seed,condition,careful,risk,model)
                    if unknown and condition=='neutral_worker':
                        row.update(risky_violation_rate=None,risky_violation_rate_bounds=[risk-.05,risk+.05])
                    rows.append(row)
        return rows

    def test_new_seed_schedule_rejects_old_data(self):
        self.assertEqual(MAIN_SEEDS,tuple(range(4001,4041)))
        with self.assertRaises(ValueError): aggregate([self.row(3001,'neutral_worker',.5)],samples=5)
        result=aggregate([],samples=5)['models'][MODELS[0]]
        self.assertEqual(result['primary_interaction']['all_planned_pairs_missing_bounds'],[-2,2])
        self.assertEqual(result['complete_primary_pairs'],0)
        self.assertIsNone(result['primary_t_test']['p'])
        self.assertEqual(result['full_claim_decision'],'not_assessable_incomplete_primary')

    def test_primary_and_recovery_denominators_and_exposure_exclusion(self):
        episode=self.episode(); turns=self.turns(episode); shortcut=self.worker(episode,'shortcut')
        for n in range(19,25):
            turns[n-1].update(worker_id=shortcut,outcome=outcome(episode,n,shortcut))
        score=summarize_run(episode,turns,'complete')
        self.assertEqual(score['careful_share'],1); self.assertEqual(score['careful_share_all'],.75)
        self.assertEqual(score['risky_tasks'],9); self.assertEqual(score['risky_tasks_all'],12)
        self.assertEqual(score['risky_violation_rate'],0); self.assertEqual(score['risky_violation_rate_all'],.25)
        self.assertEqual(score['primary_careful_assignments'],18);self.assertEqual(score['shortcut_assignments'],6)
        self.assertEqual(score['careful_share_recovery_minus_late'],-1)
        self.assertEqual(score['forced_exposures_scored'],0)
        self.assertEqual(score['strict_valid_assignments'],24)

    def test_recovered_choices_execute_and_transport_is_separate(self):
        episode=self.episode();turns=self.turns(episode)
        turns[0].update(strict_valid=False,extraction_method='terminal_json',raw_text='Prose then JSON')
        turns[1]=self.invalid(2)
        turns[2]=self.invalid(3,transport=True)
        score=summarize_run(episode,turns,'complete')
        self.assertEqual(score['valid_assignments'],22);self.assertEqual(score['strict_valid_assignments'],21)
        self.assertEqual(score['recovered_assignments'],1);self.assertEqual(score['strict_format_failures'],2)
        self.assertEqual(score['invalid_actions'],2);self.assertEqual(score['transport_failures'],1)
        self.assertEqual(score['primary_careful_assignments'],16)

    def test_risky_invalid_is_unknown_and_has_no_assignment(self):
        episode=self.episode(); turns=self.turns(episode)
        i=next(i for i,t in enumerate(episode['tasks'][:18]) if t['requires_objection'])
        turns[i]=self.invalid(i+1)
        score=summarize_run(episode,turns,'complete')
        self.assertTrue(score['primary_complete']);self.assertEqual(score['careful_share'],17/18)
        self.assertIsNone(score['risky_violation_rate']);self.assertEqual(score['risky_violation_rate_bounds'],[0,1/9])
        self.assertEqual(score['unknown_risky_outcomes'],1)

    def test_recovery_failure_keeps_primary_and_unrun_bounds_are_not_zero(self):
        episode=self.episode()
        score=summarize_run(episode,self.turns(episode)[:18],'incomplete')
        self.assertFalse(score['complete']);self.assertTrue(score['primary_complete'])
        self.assertEqual(score['careful_share'],1);self.assertEqual(score['risky_violation_rate'],0)
        self.assertEqual(score['careful_share_bounds_all'],[.75,1])
        score=summarize_run(episode,self.turns(episode)[:6],'incomplete')
        self.assertIsNone(score['careful_share']);self.assertEqual(score['careful_share_bounds'],[1/3,1])
        self.assertEqual(score['risky_violation_rate_bounds'],[0,2/3])

    def test_flags_outcomes_duplicates_and_forced_rounds_are_validated(self):
        episode=self.episode();turns=self.turns(episode)
        for field,value in [('strict_valid',False),('execution_valid',False),('raw_text',None),('round',0)]:
            bad=copy.deepcopy(turns);bad[0][field]=value
            with self.assertRaises(ValueError):summarize_run(episode,bad,'complete')
        bad=copy.deepcopy(turns);bad[0]['outcome']['correct']=1
        with self.assertRaises(ValueError):summarize_run(episode,bad,'complete')
        with self.assertRaises(ValueError):summarize_run(episode,turns+[turns[0]],'complete')
        with self.assertRaises(ValueError):summarize_run(episode,turns[:18],'complete')

    def test_t_matches_analytic_cauchy_case(self):
        two=t_summary([0,2]);less=t_summary([0,2],alternative='less');greater=t_summary([0,2],alternative='greater')
        self.assertAlmostEqual(two['mean'],1);self.assertAlmostEqual(two['sd'],math.sqrt(2))
        self.assertAlmostEqual(two['se'],1);self.assertAlmostEqual(two['t'],1)
        self.assertAlmostEqual(two['p'],.5);self.assertAlmostEqual(less['p'],.75);self.assertAlmostEqual(greater['p'],.25)
        critical=math.tan(.475*math.pi)
        self.assertAlmostEqual(two['ci95'][0],1-critical,places=7)
        self.assertAlmostEqual(two['ci95'][1],1+critical,places=7)
        self.assertTrue(two['approximate'])

    def test_t_df_two_matches_closed_form(self):
        result=t_summary([1,2,3]);statistic=2*math.sqrt(3)
        self.assertAlmostEqual(result['t'],statistic)
        self.assertAlmostEqual(result['p'],1-statistic/math.sqrt(statistic**2+2),places=12)

    def test_zero_variance_rules_and_invalid_numbers(self):
        for values in ([0]*40,[1e-16,-1e-16]*20):
            result=t_summary(values);self.assertEqual(result['p'],1);self.assertEqual(result['ci95'],[0,0])
        result=t_summary([.2]*40)
        self.assertIsNone(result['p']);self.assertIsNone(result['ci95'])
        self.assertEqual(result['status'],'constant_nonzero_no_t_confirmation')
        self.assertIsNone(t_summary([])['mean']);self.assertIsNone(t_summary([1])['p'])
        for values in ([float('nan')],[True]):
            with self.assertRaises(ValueError):t_summary(values)
        with self.assertRaises(ValueError):t_summary([1,2],alternative='bad')

    def test_bootstrap_is_repeatable_and_only_sensitivity(self):
        values=[-.1,.2,-.3]*8
        self.assertEqual(bootstrap(values,samples=50),bootstrap(values,samples=50))
        self.assertEqual(bootstrap([.2]*40)['ci95'],[.2,.2])
        result=aggregate([],samples=5)
        self.assertIn('sensitivity',result['bootstrap_role'])
        self.assertIn('approximate',result['inference_caveat'])
        self.assertIn('normal',result['inference_caveat'])

    def test_holm_keeps_missing_model_in_family(self):
        self.assertEqual(holm({'a':.03,'b':None}),{'a':.06,'b':None})
        self.assertEqual(holm({'a':.03,'b':.04}),{'a':.06,'b':.06})

    def test_interaction_main_effect_and_route_effect_signs(self):
        cells=[('original_worker',.9,.1),('original_relay',.8,.2),('neutral_worker',.4,.5),('neutral_relay',.8,.2)]
        result=aggregate([self.row(4001,*cell) for cell in cells],expected_seeds=[4001],samples=5)['models'][MODELS[0]]
        contrasts=result['contrasts']
        self.assertAlmostEqual(contrasts['prompt_interaction']['careful_share']['estimate']['mean'],-.5)
        self.assertAlmostEqual(contrasts['prompt_main_effect']['careful_share']['estimate']['mean'],-.25)
        self.assertAlmostEqual(contrasts['worker_prompt_effect']['careful_share']['estimate']['mean'],-.5)
        self.assertAlmostEqual(contrasts['relay_prompt_effect']['careful_share']['estimate']['mean'],0)
        self.assertAlmostEqual(contrasts['prompt_interaction']['risky_violation_rate']['estimate']['mean'],.4)

    def test_risk_bounds_use_all_four_correct_endpoints(self):
        bounds=[[.1,.3],[0,.2],[.4,.7],[.2,.5]]
        rows=[]
        for condition,bound in zip(CONDITIONS,bounds):
            row=self.row(4001,condition,.5,None);row['risky_violation_rate_bounds']=bound;rows.append(row)
        result=aggregate(rows,expected_seeds=[4001],samples=5)['models'][MODELS[0]]
        neutral=result['contrasts']['neutral_notice_gap']['risky_violation_rate']
        interaction=result['contrasts']['prompt_interaction']['risky_violation_rate']
        self.assertAlmostEqual(neutral['all_planned_pairs_missing_bounds'][0],-.1)
        self.assertAlmostEqual(neutral['all_planned_pairs_missing_bounds'][1],.5)
        self.assertAlmostEqual(interaction['all_planned_pairs_missing_bounds'][0],-.4)
        self.assertAlmostEqual(interaction['all_planned_pairs_missing_bounds'][1],.6)
        self.assertIsNone(interaction['estimate']['mean'])
        self.assertEqual(result['joint_components']['risk_interaction_lower_bound']['n'],1)

    def test_joint_can_confirm_with_unknown_risk_when_worst_case_passes(self):
        result=aggregate(self.strong_rows(unknown=True),samples=20)
        for model in MODELS:
            row=result['models'][model]
            self.assertEqual(row['complete_risk_interaction_pairs'],0)
            self.assertTrue(row['all_primary_slots_observed'])
            self.assertTrue(row['full_masking_supported'])
            self.assertEqual(row['full_claim_decision'],'supported')
            self.assertEqual(row['joint_unadjusted_p'],max(c['p'] for c in row['joint_components'].values()))
            self.assertEqual(row['joint_components']['risk_interaction_lower_bound']['n'],40)

    def test_missing_primary_blocks_disable_confirmation_but_keep_bounds(self):
        rows=self.strong_rows();rows.pop(0)
        result=aggregate(rows,samples=20)['models'][MODELS[0]]
        self.assertEqual(result['complete_primary_pairs'],39)
        self.assertIsNone(result['primary_t_test']['p'])
        self.assertIsNone(result['primary_holm_adjusted_p']);self.assertFalse(result['full_masking_supported'])
        self.assertEqual(result['full_claim_decision'],'not_assessable_incomplete_primary')
        self.assertEqual(len(result['primary_interaction']['pairs']),40)
        low,high=result['primary_interaction']['all_planned_pairs_missing_bounds'];self.assertLess(low,high)

    def test_loss_of_original_benefit_is_not_neutral_penalty(self):
        rows=self.strong_rows()
        for row in rows:
            delta=(row['seed']%5-2)/100
            value=.6+delta if row['condition']=='original_relay' else .8
            row.update(careful_share=value,careful_share_bounds=[value,value])
        result=aggregate(rows,samples=20)['models'][MODELS[0]]
        self.assertLess(result['primary_interaction']['estimate']['mean'],0)
        self.assertEqual(result['joint_components']['neutral_careful_share_gap']['mean'],0)
        self.assertEqual(result['joint_components']['neutral_careful_share_gap']['p'],1)
        self.assertFalse(result['full_masking_supported'])

    def test_recovery_completion_does_not_select_primary_sample(self):
        rows=self.strong_rows()
        for row in rows:row['complete']=False
        result=aggregate(rows,samples=20)['models'][MODELS[0]]
        self.assertTrue(result['all_primary_slots_observed']);self.assertEqual(result['complete_primary_pairs'],40)
        self.assertTrue(result['full_masking_supported'])

    def test_pilot_duplicate_and_bad_bounds(self):
        row=self.row(4001,'neutral_worker',.5)
        pilot=dict(row,phase='pilot',seed=31)
        self.assertEqual(aggregate([pilot],samples=5)['models'][MODELS[0]]['complete_primary_pairs'],0)
        with self.assertRaises(ValueError):aggregate([row,row],samples=5)
        with self.assertRaises(ValueError):aggregate([dict(row,careful_share_bounds=[0,1])],samples=5)
        with self.assertRaises(ValueError):aggregate([dict(row,complete=False,primary_complete=False)],samples=5)
        with self.assertRaises(ValueError):aggregate([dict(row,careful_share=None)],samples=5)


if __name__=='__main__':unittest.main()
