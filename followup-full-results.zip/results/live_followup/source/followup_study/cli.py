"""Check and run the fixed follow-up study. Never repeat saved calls."""
import argparse
import asyncio
from contextlib import ExitStack
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import io
from pathlib import Path
import shutil
import sys
import unittest
from unittest.mock import patch

from .common import read_json, write_json, digest
from .ledger import read_prior
from .authorization import claim_authorization
from .runner import Runner, OfflineProvider, manifest, MODELS
from .tokenization import NativeCounter
from .transport import AdaptionProvider, MODEL_PRICES, INPUT_CAP, OUTPUT_CAP
from .environment import CONDITIONS

BASE = Path(__file__).resolve().parents[1]
TEST_REPORT = 'followup_offline_test_report.json'
NATIVE_REPORT = 'followup_verification.json'
PROTOCOL = 'followup-1.0'


def source_hashes():
    files = list((BASE / 'followup_study').glob('*.py')) + list((BASE / 'tests_followup').glob('*.py'))
    files += [BASE / name for name in ('FOLLOWUP_PROTOCOL.md', 'FOLLOWUP_PLAN.md', 'requirements.txt', 'key_prompt.py')]
    return {str(path.relative_to(BASE)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(files) if path.is_file()}


def verify():
    """Run all follow-up tests with every socket connection blocked."""
    stream = io.StringIO()
    suite = unittest.defaultTestLoader.discover(str(BASE / 'tests_followup'))
    with ExitStack() as stack:
        stack.enter_context(patch('socket.create_connection', side_effect=AssertionError('Network disabled')))
        stack.enter_context(patch('socket.socket.connect', side_effect=AssertionError('Network disabled')))
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    report = {'passed': result.wasSuccessful() and not result.skipped and result.testsRun > 0,
              'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
              'skipped': len(result.skipped), 'network_blocked': True, 'paid_calls': 0,
              'source_hashes': source_hashes(), 'log': stream.getvalue(),
              'python': sys.version, 'time_utc': datetime.now(timezone.utc).isoformat()}
    write_json(BASE / TEST_REPORT, report)
    print(stream.getvalue(), end='')
    return 0 if report['passed'] else 1


def counters():
    result = {model: NativeCounter(model, BASE / 'tokenizers' / key)
              for model, key in zip(MODELS, ('qwen', 'glm'))}
    verified = read_json(BASE / 'tokenizers' / NATIVE_REPORT)
    if not verified.get('network_blocked') or verified.get('paid_calls') != 0:
        raise ValueError('The native tokenizer check is missing')
    if (verified.get('environment_source_hash') != hashlib.sha256((BASE / 'followup_study' / 'environment.py').read_bytes()).hexdigest()
            or verified.get('task_seeds') != [20, 21, 22] + list(range(3001, 3041))
            or verified.get('conditions') != list(CONDITIONS)):
        raise ValueError('The native context check is stale')
    for key, model in zip(('qwen', 'glm'), MODELS):
        if verified['models'][key]['counter'] != result[model].name:
            raise ValueError('The native tokenizer check is stale')
    return result


def require_offline_checks():
    report = read_json(BASE / TEST_REPORT)
    if (not report.get('passed') or not report.get('network_blocked') or report.get('paid_calls') != 0
            or type(report.get('tests')) is not int or report['tests'] <= 0 or report.get('skipped') != 0
            or report.get('source_hashes') != source_hashes()):
        raise ValueError('Run the offline checks after the last source change')


def require_full_simulation():
    report = read_json(BASE / 'followup_offline_integration_report.json')
    if (report.get('passed') is not True or report.get('mode') != 'offline'
            or report.get('paid_calls') != 0 or report.get('calls') != 8072
            or report.get('main_runs') != 320 or report.get('source_hashes') != source_hashes()):
        raise ValueError('A full checked offline simulation is required before live calls')


async def execute(args):
    root = args.result_root.resolve()
    # These checks run before any key access or provider access.
    if root.exists():
        raise ValueError('This result folder already exists. Automatic repeat calls are disabled')
    if args.mode == 'live':
        if not args.execute_paid:
            raise ValueError('Live inference requires --execute-paid')
        if not args.key_receipt:
            raise ValueError('Live inference requires a private key receipt')
        if args.available_credits < 100:
            raise ValueError('The reported credit balance is below the fixed study limit')
    require_offline_checks()
    if args.mode == 'live':
        require_full_simulation()
    native = counters()
    hashes = source_hashes()
    carry = read_prior(args.prior_root) if args.mode == 'live' else None
    prior_audit = None
    if args.mode == 'live':
        prior_audit = read_json(args.prior_root / 'audit.json')
        if prior_audit.get('passed') is not True or prior_audit.get('issues') != []:
            raise ValueError('The prior study audit did not pass')
        from key_prompt import receive_key
        key = receive_key(args.key_receipt)
        provider = AdaptionProvider(key)
        key = None
        catalog = await asyncio.to_thread(provider.list_models)
        if not set(MODELS).issubset({item['id'] for item in catalog['data']}):
            raise ValueError('A required hosted model is not available to this key')
        # The old cost record must not change during setup.
        if carry != read_prior(args.prior_root):
            raise ValueError('The prior study changed during setup')
    else:
        provider = OfflineProvider()
        catalog = {'object': 'list', 'data': [], 'offline': True}
    if hashes != source_hashes():
        raise ValueError('The source changed during setup')
    authorization = (claim_authorization(BASE, root, carry, source_hashes=hashes)
                     if args.mode == 'live' else None)
    # Atomic creation prevents two processes from using the same result folder.
    root.mkdir(parents=True, exist_ok=False)
    write_json(root / 'model_catalog.json', catalog)
    if authorization is not None:
        write_json(root / 'authorization.json', authorization)
    if carry is not None:
        write_json(root / 'prior_study_receipt.json', carry)
        write_json(root / 'prior_audit.json', prior_audit)
    config = {'protocol': PROTOCOL, 'mode': args.mode, 'models': list(MODELS),
              'started_utc': datetime.now(timezone.utc).isoformat(),
              'source_hashes': hashes, 'model_prices': MODEL_PRICES,
              'reported_available_adaption_credits': args.available_credits,
              'limit_adaption_credits': 100, 'new_limit_adaption_credits': 70, 'actual_billing_verified': False,
              'input_cap': INPUT_CAP, 'output_cap': OUTPUT_CAP, 'temperature': .7,
              'inference_concurrency': 4, 'active_episode_limit': 8,
              'initial_requests_per_second': 4, 'minimum_cooldown_seconds': 60,
              'rate_limit_rates_per_second': [4, 2, 1], 'stop_after_rate_limit_cycles': 3,
              'reasoning_setting': 'requested_none_reported_zero_required',
              'reasoning_request': {'effort': 'none'},
              'deployment_revision': 'not_pinned_or_verified',
              'probe_seed': 20, 'pilot_seeds': [21, 22], 'main_seeds': list(range(3001, 3041)),
              'conditions': list(CONDITIONS),
              'condition_order': 'four-position rotation, ten main seeds per position',
              'primary_rounds': 18, 'recovery_rounds': 6, 'audit_release_before_choice': 19,
              'prior_results_excluded_from_new_analysis': True, 'prior_carry_hash': digest(carry) if carry else None,
              'prior_audit_hash': digest(prior_audit) if prior_audit else None,
              'token_counters': {model: native[model].name for model in MODELS},
              'libraries': {name: importlib.metadata.version(name)
                            for name in ('transformers', 'tokenizers', 'jinja2', 'certifi')},
              'pricing_source': 'https://docs.adaptionlabs.ai/inference-stacks/models/',
              'openrouter_calls': 0, 'openrouter_spend_cad': 0}
    write_json(root / 'study.json', config)
    write_json(root / 'manifest.json', manifest())
    write_json(root / 'offline_test_report.json', read_json(BASE / TEST_REPORT))
    if args.mode == 'live':
        write_json(root / 'offline_integration_report.json', read_json(BASE / 'followup_offline_integration_report.json'))
    write_json(root / 'tokenizer_verification.json', read_json(BASE / 'tokenizers' / NATIVE_REPORT))
    for name, expected in hashes.items():
        target = root / 'source' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(BASE / name, target)
        if hashlib.sha256(target.read_bytes()).hexdigest() != expected:
            raise ValueError('A source copy does not match its frozen hash')
    runner = Runner(root, provider, native, limit='100', new_limit='70', concurrency=4, carry=carry)
    initial_status = {'status': 'running', 'mode': args.mode, 'ledger': runner.ledger.snapshot()}
    write_json(root / 'status.json', initial_status)
    from .reporting import write_report
    write_report(root, initial_status)
    try:
        status = await runner.pipeline(main=not args.pilot_only)
    except BaseException:
        runner.stop = True
        runner.ledger.freeze('The process stopped before the planned end')
        status = {'status': 'interrupted', 'mode': args.mode, 'ledger': runner.ledger.snapshot(),
                  'finished_utc': datetime.now(timezone.utc).isoformat()}
        write_json(root / 'status.json', status)
        write_report(root, status)
        raise
    status.update({'mode': args.mode, 'result_root': str(root),
                   'finished_utc': datetime.now(timezone.utc).isoformat()})
    write_json(root / 'status.json', status)
    write_report(root, status)
    print(__import__('json').dumps(status, sort_keys=True))
    return 0 if status['status'] in ('complete', 'pilot_passed') else 1


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('verify')
    run = sub.add_parser('run')
    run.add_argument('--mode', choices=('offline', 'live'), default='offline')
    run.add_argument('--execute-paid', action='store_true')
    run.add_argument('--key-receipt', type=Path)
    run.add_argument('--available-credits', type=int, default=4500)
    run.add_argument('--result-root', type=Path, required=True)
    run.add_argument('--prior-root', type=Path, default=BASE / 'results' / 'live_paced')
    run.add_argument('--pilot-only', action='store_true')
    args = parser.parse_args(argv)
    try:
        return verify() if args.command == 'verify' else asyncio.run(execute(args))
    except (ValueError, OSError, RuntimeError, KeyError) as error:
        print(f'Study stopped: {type(error).__name__}: {error}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
