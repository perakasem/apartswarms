from collections import Counter
from copy import deepcopy
import json
import unittest

from followup_study.environment import (
    CONDITIONS, NOTICE_SOURCES, RESPONSE_CHARACTERS, build_messages, failure_outcome,
    generate_episode, observation, outcome,
)


def make_history(episode, until, policy='careful'):
    worker = next(w for w in episode['worker_ids'] if episode['worker_policies'][w] == policy)
    return [outcome(episode, number, worker) for number in range(1, until)]


class EnvironmentTests(unittest.TestCase):
    def test_four_cells_share_all_private_cases_and_worker_rules(self):
        for seed in range(20):
            episodes = [generate_episode(seed, c) for c in CONDITIONS]
            for ep in episodes:
                self.assertEqual(ep['worker_policies'][ep['focal_id']], 'careful')
                ep.pop('condition')
            self.assertTrue(all(ep == episodes[0] for ep in episodes))

    def test_balanced_free_task_blocks_and_first18_risk_denominator(self):
        first18 = Counter()
        for seed in range(40):
            tasks = generate_episode(seed, CONDITIONS[0])['tasks']
            self.assertEqual(len(tasks), 24)
            self.assertEqual(sum(t['requires_objection'] for t in tasks[:18]), 9)
            self.assertEqual(sum(t['requires_objection'] for t in tasks), 12)
            self.assertEqual(Counter((t['family'],t['requires_objection']) for t in tasks),
                             {('permission',True):6,('permission',False):6,('evidence',True):6,('evidence',False):6})
            for start in range(0,24,6):
                self.assertEqual(sum(t['requires_objection'] for t in tasks[start:start+6]),3)
                self.assertEqual(Counter(t['family'] for t in tasks[start:start+6]), {'permission':3,'evidence':3})
            first18.update((t['family'],t['requires_objection']) for t in tasks[:18])
        self.assertEqual(first18, {('permission',True):180,('permission',False):180,
                                  ('evidence',True):180,('evidence',False):180})

    def test_private_truth_matches_rules_and_is_absent_from_task_brief(self):
        for seed in range(10):
            ep = generate_episode(seed, CONDITIONS[0])
            for task in ep['tasks'] + [x['task'] for x in ep['exposures']]:
                facts = task['private_facts']
                needs = facts['authorization'] != 'valid' if task['family']=='permission' else \
                        not set(facts['required_sources']).issubset(facts['available_sources'])
                self.assertEqual(needs, task['requires_objection'])
                brief = json.dumps(task['visible'])
                for field in ('private_facts','requires_objection','authorization','available_sources','required_sources'):
                    self.assertNotIn('"'+field+'"', brief)

    def test_fixed_worker_outcomes_control_competence_time_and_refusal(self):
        for seed in range(10):
            ep=generate_episode(seed, CONDITIONS[0])
            self.assertEqual(Counter(ep['worker_policies'].values()), {'careful':2,'shortcut':2})
            for n,task in enumerate(ep['tasks'],1):
                rows=[outcome(ep,n,w) for w in ep['worker_ids']]
                self.assertEqual({row['latency_units'] for row in rows},{1})
                self.assertEqual({row['cost_units'] for row in rows},{1})
                self.assertEqual({len(row['actiondescription']) for row in rows},{RESPONSE_CHARACTERS})
                self.assertEqual(sum(row['violation'] for row in rows), 2 if task['requires_objection'] else 0)
                for row in rows:
                    careful=ep['worker_policies'][row['worker_id']]=='careful'
                    self.assertEqual(row['objection'],task['requires_objection'] and careful)
                    self.assertEqual(row['correct'],not row['violation'])
                    self.assertEqual(row['success_credit'],int(row['correct']))
                    if not task['requires_objection']:
                        self.assertFalse(row['objection']);self.assertTrue(row['acted'])

    def test_equal_verified_permitted_calibration(self):
        ep=generate_episode(3001,CONDITIONS[0])
        for w in ep['worker_ids']:
            rows=[x for x in ep['calibration'] if x['worker_id']==w]
            self.assertEqual(len(rows),2)
            self.assertEqual({r['case'] for r in rows},{'permission_permitted','evidence_permitted'})
            for field in ('success_credit','latency_units','cost_units'):
                self.assertEqual(sum(r[field] for r in rows),2)
            self.assertTrue(all(r['audit']=='correct' for r in rows))

    def test_exposure_schedule_and_equal_case_for_all_workers(self):
        ep=generate_episode(3001,CONDITIONS[2])
        self.assertEqual([e['before_round'] for e in ep['exposures']],[1,7,13])
        for batch in ep['exposures']:
            self.assertTrue(batch['task']['requires_objection'])
            self.assertEqual([r['worker_id'] for r in batch['results']],ep['worker_ids'])
            self.assertEqual({r['task_id'] for r in batch['results']},{batch['task']['task_id']})
            self.assertEqual({r['round_number'] for r in batch['results']},{0})
            self.assertEqual(sum(r['objection'] for r in batch['results']),2)
            self.assertEqual(sum(r['violation'] for r in batch['results']),2)
        for n,wanted in [(1,1),(6,1),(7,2),(12,2),(13,3),(24,3)]:
            view=observation(ep,make_history(ep,n),n)
            self.assertEqual(len(view['fixed_exposures']),wanted)
            self.assertEqual(len(view['history']),n-1)
            self.assertTrue(all(r[0].startswith('T') for r in view['history']))

    def test_worker_policy_and_exposures_do_not_depend_on_free_history(self):
        ep=generate_episode(3002,CONDITIONS[0]);before=deepcopy(ep)
        worker=ep['focal_id'];expected=outcome(ep,15,worker)
        for n in range(1,15):outcome(ep,n,ep['worker_ids'][n%4])
        self.assertEqual(outcome(ep,15,worker),expected)
        self.assertEqual(ep,before)
        for policy in ('careful','shortcut'):
            self.assertEqual(observation(ep,make_history(ep,13,policy),13)['fixed_exposures'],
                             observation(ep,make_history(ep,13),13)['fixed_exposures'])

    def test_notice_route_is_the_only_message_change_at_fixed_timing(self):
        for left,right in [(CONDITIONS[0],CONDITIONS[1]),(CONDITIONS[2],CONDITIONS[3])]:
            a=generate_episode(3003,left);b=generate_episode(3003,right)
            for n in (1,7,13,19,24):
                ha=make_history(a,n);hb=make_history(b,n)
                ta=json.dumps(build_messages(a,ha,n),ensure_ascii=False)
                tb=json.dumps(build_messages(b,hb,n),ensure_ascii=False)
                self.assertEqual(len(ta),len(tb))
                # Source labels in the common instructions are shared. Only
                # the exact padded report field is changed by this replacement.
                va=observation(a,ha,n);vb=observation(b,hb,n)
                for v in (va,vb):
                    for row in v['history']+[r for batch in v['fixed_exposures'] for r in batch['reports']]:
                        if row[2]=='held':row[3]='ROUTE___'
                self.assertEqual(va,vb)
                for worker in a['worker_ids']:
                    self.assertEqual(ta.count(worker),tb.count(worker))
                held=[r for batch in observation(a,ha,n)['fixed_exposures'] for r in batch['reports'] if r[2]=='held']
                self.assertEqual({r[1] for r in held},{w for w,p in a['worker_policies'].items() if p=='careful'})
                self.assertEqual({r[3] for r in held},{NOTICE_SOURCES['worker']})

    def test_delayed_audits_do_not_leak_truth_or_zero_pending_scores(self):
        ep=generate_episode(3001,CONDITIONS[2])
        for n in (1,6,7,12,13,18):
            view=observation(ep,make_history(ep,n,'shortcut'),n)
            self.assertEqual(view['AUDITOR'],[])
            # Baseline scores are verified permitted cases. No pending result
            # gets a correctness field, risk flag, score, or hidden case facts.
            pending=json.dumps({'exposures':view['fixed_exposures'],'history':view['history'],'current':view['current_task']})
            for forbidden in ('private_facts','requires_objection','success_credit','correct','violation','available_sources','required_sources','"authorization"'):
                self.assertNotIn(forbidden,pending)

    def test_audits_release_exactly_before19_then_track_new_reports(self):
        for condition in CONDITIONS:
            ep=generate_episode(3004,condition)
            for n in range(1,25):
                view=observation(ep,make_history(ep,n),n)
                released=condition.endswith('immediate') or n>=19
                expected=n-1+4*sum(b['before_round']<=n for b in ep['exposures']) if released else 0
                self.assertEqual(len(view['AUDITOR']),expected)
                ids=[row[0] for row in view['AUDITOR']]
                self.assertEqual(len(ids),len(set(ids)))
                self.assertNotIn(f'T{n:02d}',ids)
                if released:
                    for record,verdict,credit,facts in view['AUDITOR']:
                        self.assertIn(verdict,{'correct_hold','correct_action','violation'})
                        self.assertIn(credit,(0,1))
                        self.assertTrue('authorization' in facts or 'required_sources' in facts)
        delayed=generate_episode(3004,CONDITIONS[2]);immediate=generate_episode(3004,CONDITIONS[0])
        dv=observation(delayed,make_history(delayed,19),19)
        iv=observation(immediate,make_history(immediate,19),19)
        dv.pop('audit_schedule');iv.pop('audit_schedule')
        self.assertEqual(dv,iv)

    def test_private_sentinels_and_policy_labels_never_enter_messages(self):
        ep=generate_episode(8,CONDITIONS[2]);history=make_history(ep,24)
        ep['private_marker']='HIDDEN_TEST_SENTINEL'
        ep['tasks'][23]['private_facts']['marker']='HIDDEN_TEST_SENTINEL'
        ep['exposures'][0]['task']['private_facts']['marker']='HIDDEN_TEST_SENTINEL'
        history[0]['private_marker']='HIDDEN_TEST_SENTINEL'
        messages=build_messages(ep,history,24);text=json.dumps(messages)
        for forbidden in ('HIDDEN_TEST_SENTINEL','worker_policies','requires_objection','worker_delayed','notifier_delayed','focal_id'):
            self.assertNotIn(forbidden,text)
        self.assertEqual([m['role'] for m in messages],['system','user','user'])
        self.assertLess(sum(len(m['content']) for m in messages),18000)

    def test_current_case_truth_stays_private_even_with_immediate_audit(self):
        for condition in CONDITIONS:
            ep=generate_episode(3005,condition);n=17
            before=build_messages(ep,make_history(ep,n),n)
            task=ep['tasks'][n-1]
            task['private_facts']={'authorization':'SECRET_UNSEEN'} if task['family']=='permission' else {'required_sources':['SECRET_UNSEEN'],'available_sources':[]}
            task['requires_objection']=not task['requires_objection']
            after=build_messages(ep,make_history(ep,n),n)
            self.assertEqual(before,after)

    def test_observations_are_isolated_copies(self):
        ep=generate_episode(3001,CONDITIONS[0]);original=deepcopy(ep)
        obs=observation(ep,[],1)
        obs['calibration'][0]['worker_id']='BAD'
        obs['current_task']['rule']='BAD'
        obs['worker_ids'][0]='BAD'
        obs['fixed_exposures'][0]['case']['rule']='BAD'
        obs['fixed_exposures'][0]['reports'][0][1]='BAD'
        self.assertEqual(ep,original)

    def test_identity_and_display_order_vary_across_seeds(self):
        episodes=[generate_episode(seed,CONDITIONS[0]) for seed in range(30)]
        self.assertEqual(generate_episode(1,CONDITIONS[0]),generate_episode(1,CONDITIONS[0]))
        self.assertEqual(len({tuple(ep['worker_ids']) for ep in episodes}),30)
        self.assertEqual({ep['worker_ids'].index(ep['focal_id']) for ep in episodes},{0,1,2,3})
        self.assertTrue(all(len(set(ep['worker_ids']))==4 for ep in episodes))

    def test_failure_audit_has_unknown_safety_and_no_fake_pending_score(self):
        for condition in CONDITIONS:
            ep=generate_episode(3001,condition)
            failed=failure_outcome(ep,1,'invalid_choice')
            view=observation(ep,[failed],2)
            self.assertEqual(view['history'][0][1:4],[None,'no_assignment','NONE    '])
            free_audits=[r for r in view['AUDITOR'] if r[0]=='T01']
            if condition.endswith('immediate'):
                self.assertEqual(free_audits[0][1:3],['unknown_no_assignment',None])
            else:self.assertEqual(free_audits,[])
            self.assertFalse(failed['valid'])
            self.assertFalse(failed['violation'])

    def test_invalid_inputs_and_history_are_rejected(self):
        for seed in [True,-1,2**63,'1']:
            with self.assertRaises(ValueError):generate_episode(seed,CONDITIONS[0])
        with self.assertRaises(ValueError):generate_episode(1,'invalid')
        ep=generate_episode(1,CONDITIONS[0])
        for n in [True,0,25]:
            with self.assertRaises(ValueError):outcome(ep,n,ep['focal_id'])
        with self.assertRaises(ValueError):outcome(ep,1,'UNKNOWN')
        with self.assertRaises(ValueError):observation(ep,[],2)
        result=failure_outcome(ep,1,'invalid_choice')
        with self.assertRaises(ValueError):failure_outcome(ep,1,'raw API secret')
        for replacement in ({'round_number':2},{'record_id':'E01_1'},{'task_id':'BAD'},{'worker_id':'BAD'},{'valid':0}):
            with self.assertRaises(ValueError):observation(ep,[dict(result,**replacement)],2)


if __name__=='__main__':unittest.main()
