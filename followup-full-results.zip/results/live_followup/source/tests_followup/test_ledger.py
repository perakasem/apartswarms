"""Offline tests for immutable prior costs and current atomic reservations."""
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
from copy import deepcopy
from decimal import Decimal
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest

from followup_study.ledger import BudgetError, CreditLedger, read_prior, _read_original, canonical, record_hash
from followup_study.transport import MODEL_PRICES, maximum_call_cost

MODEL = 'qwen3.5-397b'
RESERVE = maximum_call_cost(MODEL)


def zero_carry():
    """A checked-shape zero-cost receipt for offline fake-provider tests only."""
    amounts = {'estimated_charged_credits': '0', 'pending_credits': '0',
               'unknown_credits': '0', 'committed_credits': '0'}
    hashes = {key: '0' * 64 for key in ('ledger_hash', 'attempt_records_sha256',
              'study_hash', 'status_hash', 'study_file_sha256', 'status_file_sha256')}
    original = {'schema': 'paced-prior-carry-1', 'currency': 'adaption_credits',
                'root': '/offline-test-original', 'limit_credits': '100',
                'prior_status': 'incomplete', 'prior_frozen': True,
                'frozen_reason': 'Offline test fixture', 'attempts': 1,
                'actual_billing_verified': False, **amounts, **hashes}
    return {'schema': 'followup-prior-carry-1', 'currency': 'adaption_credits',
            'root': '/offline-test-paced', 'limit_credits': '100',
            'prior_protocol': 'paced-1.0', 'prior_status': 'complete', 'prior_frozen': False,
            'frozen_reason': '', 'attempts': 2, 'current_attempts': 1, 'carried_attempts': 1,
            'actual_billing_verified': False, **amounts, **hashes,
            'audit_hash': '0' * 64, 'audit_file_sha256': '0' * 64,
            'previous_carry': original, 'previous_carry_hash': record_hash(original),
            'current': {**amounts, 'attempts': 1},
            'carried': {**amounts, 'attempts': 1, 'ledger_hash': original['ledger_hash']}}


def prior_fixture(root):
    original = root.parent / 'original'
    original.mkdir()
    with closing(sqlite3.connect(original / 'credits.sqlite')) as db:
        db.execute('CREATE TABLE metadata (key TEXT PRIMARY KEY,value TEXT NOT NULL)')
        db.execute('CREATE TABLE attempts (id TEXT PRIMARY KEY,model TEXT,phase TEXT,retry INTEGER,reserved TEXT,status TEXT,estimated_charge TEXT,usage TEXT)')
        values = {'mode': 'live', 'currency': 'adaption_credits', 'limit_credits': '1E+2',
                  'prices': json.dumps(MODEL_PRICES, sort_keys=True), 'frozen_reason': 'Prior rate limit stop'}
        db.executemany('INSERT INTO metadata VALUES (?,?)', values.items())
        db.executemany('INSERT INTO attempts VALUES (?,?,?,?,?,?,?,?)', [
            ('old-known-1', MODEL, 'probe', 0, '.02', 'settled', '.005', None),
            ('old-known-2', MODEL, 'main', 0, '.02', 'settled', '.002', None),
            ('old-unknown', 'glm-5.2', 'main', 1, '.02', 'unknown', None, None)])
        db.commit()
    old_status = {'mode': 'live', 'status': 'incomplete', 'ledger': {
        'mode': 'live', 'currency': 'adaption_credits', 'limit_credits': '100',
        'frozen': True, 'frozen_reason': 'Prior rate limit stop', 'attempts': 3,
        'estimated_charged_credits': '.007', 'pending_credits': '0',
        'unknown_credits': '.02', 'committed_credits': '.027'}}
    original_audit = {'passed': True, 'issues': [], 'mode': 'live', 'study_status': 'incomplete'}
    (original / 'status.json').write_text(json.dumps(old_status))
    (original / 'study.json').write_text(json.dumps({'mode': 'live', 'protocol': 'selection-1.2'}))
    (original / 'audit.json').write_text(json.dumps(original_audit))
    carry = _read_original(original)
    root.mkdir()
    with closing(sqlite3.connect(root / 'credits.sqlite')) as db:
        db.execute('CREATE TABLE metadata (key TEXT PRIMARY KEY,value TEXT NOT NULL)')
        db.execute('CREATE TABLE attempts (id TEXT PRIMARY KEY,model TEXT,phase TEXT,retry INTEGER,reserved TEXT,status TEXT,estimated_charge TEXT,usage TEXT)')
        values = {'mode': 'live', 'currency': 'adaption_credits', 'limit_credits': '1E+2',
                  'prices': json.dumps(MODEL_PRICES, sort_keys=True), 'frozen_reason': '',
                  'carry': canonical(carry), 'quotas': json.dumps({'main': 1920, 'pilot': 96, 'probe': 4}, sort_keys=True),
                  'retry_limit': '100', 'max_attempts': '4240', 'input_cap': '6000', 'output_cap': '512'}
        db.executemany('INSERT INTO metadata VALUES (?,?)', values.items())
        db.execute('INSERT INTO attempts VALUES (?,?,?,?,?,?,?,?)',
                   ('paced-known', MODEL, 'main', 0, str(RESERVE), 'settled', '.003', None))
        db.commit()
    status = {'mode': 'live', 'status': 'complete', 'main_runs': 160, 'ledger': {
        'mode': 'live', 'currency': 'adaption_credits', 'limit_credits': '100',
        'frozen': False, 'frozen_reason': '', 'attempts': 4, 'current_attempts': 1, 'carried_attempts': 3,
        'estimated_charged_credits': '.010', 'pending_credits': '0',
        'unknown_credits': '.02', 'committed_credits': '.030',
        'current': {'attempts': 1, 'estimated_charged_credits': '.003', 'pending_credits': '0',
                    'unknown_credits': '0', 'committed_credits': '.003'},
        'carried': {key: carry[key] for key in ('attempts', 'estimated_charged_credits', 'pending_credits',
                                               'unknown_credits', 'committed_credits', 'ledger_hash')}}}
    (root / 'status.json').write_text(json.dumps(status))
    (root / 'study.json').write_text(json.dumps({'mode': 'live', 'protocol': 'paced-1.0',
        'prior_carry_hash': record_hash(carry), 'prior_audit_hash': record_hash(original_audit)}))
    (root / 'prior_study_receipt.json').write_text(json.dumps(carry))
    (root / 'prior_audit.json').write_text(json.dumps(original_audit))
    (root / 'audit.json').write_text(json.dumps({'passed': True, 'issues': [], 'mode': 'live',
        'study_status': 'complete', 'counts': {'current_attempts': 1, 'carried_attempts': 3}}))
    return original


class FollowupLedgerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.prior = Path(self.temp.name) / 'prior'
        self.path = Path(self.temp.name) / 'current' / 'credits.sqlite'
        self.original = prior_fixture(self.prior)
        self.carry = read_prior(self.prior)

    def tearDown(self):
        self.temp.cleanup()

    def ledger(self, limit='100', new_limit='70'):
        return CreditLedger(self.path, limit_credits=limit, carry=self.carry, new_limit_credits=new_limit)

    def test_prior_receipt_is_read_only_and_includes_all_costs(self):
        before = {name: (self.prior / name).read_bytes() for name in ('credits.sqlite', 'study.json', 'status.json')}
        again = read_prior(self.prior)
        self.assertEqual(again, self.carry)
        self.assertEqual(again['attempts'], 4)
        self.assertEqual(Decimal(again['estimated_charged_credits']), Decimal('.010'))
        self.assertEqual(Decimal(again['unknown_credits']), Decimal('.02'))
        self.assertEqual(Decimal(again['committed_credits']), Decimal('.030'))
        self.assertEqual(before, {name: (self.prior / name).read_bytes() for name in before})

    def test_new_live_ledger_requires_carry(self):
        with self.assertRaises(BudgetError):
            CreditLedger(self.path)

    def test_reopen_loads_carry_and_rejects_changed_carry(self):
        self.ledger()
        loaded = CreditLedger(self.path)
        self.assertEqual(loaded.carry, self.carry)
        changed = deepcopy(self.carry)
        changed['root'] += '-other'
        with self.assertRaises(BudgetError):
            CreditLedger(self.path, carry=changed)

    def test_carry_cannot_change_through_input_or_returned_dictionary(self):
        ledger = self.ledger()
        self.carry['committed_credits'] = '0'
        returned = ledger.carry
        returned['committed_credits'] = '0'
        self.assertEqual(ledger.carried_committed, Decimal('.030'))
        self.assertEqual(Decimal(ledger.snapshot()['committed_credits']), Decimal('.030'))

    def test_current_and_global_snapshot_are_separate(self):
        ledger = self.ledger()
        ledger.reserve('a', MODEL, 'probe', RESERVE)
        ledger.settle('a', '.001')
        ledger.reserve('b', MODEL, 'probe', RESERVE)
        ledger.mark_unknown('b', freeze=False)
        ledger.reserve('c', MODEL, 'probe', RESERVE)
        snapshot = ledger.snapshot()
        self.assertEqual(snapshot['current']['attempts'], 3)
        self.assertEqual(snapshot['carried']['attempts'], 4)
        self.assertEqual(snapshot['attempts'], 7)
        self.assertEqual(Decimal(snapshot['current']['estimated_charged_credits']), Decimal('.001'))
        self.assertEqual(Decimal(snapshot['estimated_charged_credits']), Decimal('.011'))
        self.assertEqual(Decimal(snapshot['unknown_credits']), Decimal('.02') + RESERVE)
        self.assertEqual(Decimal(snapshot['pending_credits']), RESERVE)
        self.assertEqual(Decimal(snapshot['committed_credits']), Decimal('.031') + 2 * RESERVE)

    def test_reservations_include_prior_carry_in_limit(self):
        limit = Decimal('.030') + RESERVE
        ledger = self.ledger(str(limit))
        ledger.reserve('a', MODEL, 'probe', RESERVE)
        with self.assertRaises(BudgetError):
            ledger.reserve('b', MODEL, 'probe', RESERVE)
        ledger.settle('a', 0)
        ledger.reserve('b', MODEL, 'probe', RESERVE)

    def test_concurrent_reservations_cannot_exceed_global_limit(self):
        ledger = self.ledger(str(Decimal('.030') + 5 * RESERVE))
        def reserve(index):
            try:
                ledger.reserve(f'r{index}', MODEL, 'main', RESERVE)
                return True
            except BudgetError:
                return False
        with ThreadPoolExecutor(max_workers=8) as pool:
            passed = list(pool.map(reserve, range(30)))
        self.assertEqual(sum(passed), 5)
        self.assertEqual(ledger.snapshot()['current_attempts'], 5)

    def test_new_limit_blocks_a_call_even_with_global_room(self):
        ledger = self.ledger(new_limit=str(2 * RESERVE))
        ledger.reserve('known', MODEL, 'main', RESERVE)
        ledger.settle('known', RESERVE / 2)
        ledger.reserve('unknown', MODEL, 'main', RESERVE)
        ledger.mark_unknown('unknown', freeze=False)
        with self.assertRaisesRegex(BudgetError, 'new-study'):
            ledger.reserve('blocked', MODEL, 'main', RESERVE)
        snapshot = ledger.snapshot()
        self.assertEqual(Decimal(snapshot['new_remaining_credits']), RESERVE / 2)
        self.assertGreater(Decimal(snapshot['remaining_credits']), Decimal('99'))
        self.assertEqual(snapshot['current_attempts'], 2)

    def test_pending_reservations_fill_the_new_limit_atomically(self):
        ledger = self.ledger(new_limit=str(5 * RESERVE))
        def reserve(index):
            try:
                ledger.reserve(f'r{index}', MODEL, 'main', RESERVE)
                return True
            except BudgetError:
                return False
        with ThreadPoolExecutor(max_workers=8) as pool:
            passed = list(pool.map(reserve, range(30)))
        self.assertEqual(sum(passed), 5)
        snapshot = ledger.snapshot()
        self.assertEqual(snapshot['current_attempts'], 5)
        self.assertEqual(Decimal(snapshot['new_remaining_credits']), 0)
        self.assertEqual(Decimal(snapshot['pending_credits']), 5 * RESERVE)

    def test_limits_cannot_be_increased_by_reopening(self):
        self.ledger(limit='90', new_limit='60')
        for options in ({'limit_credits': '100', 'new_limit_credits': '60'},
                        {'limit_credits': '90', 'new_limit_credits': '70'}):
            with self.subTest(options=options), self.assertRaises(BudgetError):
                CreditLedger(self.path, **options)

    def test_limits_never_exceed_user_caps(self):
        for options in ({'limit_credits': '100.0001'}, {'new_limit_credits': '70.0001'},
                        {'limit_credits': '0'}, {'new_limit_credits': '0'},
                        {'limit_credits': 'NaN'}, {'new_limit_credits': 'Infinity'}):
            with self.subTest(options=options), self.assertRaises(ValueError):
                CreditLedger(self.path, carry=self.carry, **options)

    def test_followup_pilot_quota_is_192_per_model(self):
        ledger = self.ledger()
        for index in range(192):
            ledger.reserve(f'pilot{index}', MODEL, 'pilot', RESERVE)
            ledger.settle(f'pilot{index}', 0)
        with self.assertRaisesRegex(BudgetError, 'phase or retry'):
            ledger.reserve('pilot193', MODEL, 'pilot', RESERVE)
        self.assertEqual(ledger.snapshot()['counts'][MODEL]['primary_by_phase']['pilot'], 192)

    def test_followup_main_quota_is_3840_per_model(self):
        ledger = CreditLedger(self.path, mode='offline')
        with closing(sqlite3.connect(self.path)) as db:
            db.executemany('INSERT INTO attempts VALUES (?,?,?,?,?,?,?,?)',
                [(f'main{i}', MODEL, 'main', 0, '0', 'settled', '0', None) for i in range(3839)])
            db.commit()
        ledger.reserve('last', MODEL, 'main', 0)
        with self.assertRaisesRegex(BudgetError, 'phase or retry'):
            ledger.reserve('beyond', MODEL, 'main', 0)
        self.assertEqual(ledger.snapshot()['counts'][MODEL]['primary_by_phase']['main'], 3840)

    def test_unknown_keeps_reservation_and_freeze_blocks_calls(self):
        ledger = self.ledger()
        ledger.reserve('a', MODEL, 'probe', RESERVE)
        ledger.mark_unknown('a')
        self.assertEqual(Decimal(ledger.snapshot()['current']['unknown_credits']), RESERVE)
        with self.assertRaises(BudgetError):
            ledger.reserve('b', MODEL, 'probe', RESERVE)

    def test_overrun_is_saved_before_freeze(self):
        ledger = self.ledger()
        ledger.reserve('a', MODEL, 'probe', RESERVE)
        with self.assertRaises(BudgetError):
            ledger.settle('a', '.5')
        self.assertEqual(Decimal(ledger.snapshot()['current']['estimated_charged_credits']), Decimal('.5'))
        self.assertTrue(ledger.snapshot()['frozen'])

    def test_phase_retry_and_duplicate_limits(self):
        ledger = self.ledger()
        for index in range(4):
            ledger.reserve(f'p{index}', MODEL, 'probe', RESERVE)
        with self.assertRaises(BudgetError):
            ledger.reserve('p4', MODEL, 'probe', RESERVE)
        for index in range(100):
            ledger.reserve(f'r{index}', MODEL, 'probe', RESERVE, is_retry=True)
        with self.assertRaises(BudgetError):
            ledger.reserve('r100', MODEL, 'probe', RESERVE, is_retry=True)
        with self.assertRaises(BudgetError):
            ledger.reserve('p0', MODEL, 'main', RESERVE)
        self.assertEqual(ledger.snapshot()['counts'][MODEL]['retries'], 100)

    def test_offline_has_zero_carry_and_zero_charges(self):
        ledger = CreditLedger(self.path, mode='offline')
        ledger.reserve('a', MODEL, 'probe', 0)
        with self.assertRaises(BudgetError):
            ledger.settle('a', '.001')
        ledger.settle('a', 0)
        self.assertEqual(Decimal(ledger.snapshot()['committed_credits']), 0)
        self.assertEqual(ledger.snapshot()['carried_attempts'], 0)
        with self.assertRaises(BudgetError):
            CreditLedger(self.path, mode='offline', carry=self.carry)

    def test_prior_status_must_match_actual_ledger(self):
        path = self.prior / 'status.json'
        value = json.loads(path.read_text())
        value['ledger']['unknown_credits'] = '0'
        path.write_text(json.dumps(value))
        with self.assertRaises(BudgetError):
            read_prior(self.prior)

    def test_saved_original_cost_chain_cannot_be_replaced(self):
        path = self.prior / 'prior_study_receipt.json'
        value = json.loads(path.read_text())
        value['unknown_credits'] = '0'
        path.write_text(json.dumps(value))
        with self.assertRaisesRegex(BudgetError, 'cost chain'):
            read_prior(self.prior)

    def test_original_audit_must_match_the_saved_copy(self):
        path = self.original / 'audit.json'
        value = json.loads(path.read_text()); value['changed'] = True
        path.write_text(json.dumps(value))
        with self.assertRaisesRegex(BudgetError, 'audit link'):
            read_prior(self.prior)

    def test_completed_audit_and_prior_protocol_are_required(self):
        path = self.prior / 'audit.json'; original = path.read_text()
        value = json.loads(original); value['passed'] = False
        path.write_text(json.dumps(value))
        with self.assertRaisesRegex(BudgetError, 'completed prior audit'):
            read_prior(self.prior)
        path.write_text(original)
        path = self.prior / 'study.json'; value = json.loads(path.read_text())
        value['protocol'] = 'selection-1.2'; path.write_text(json.dumps(value))
        with self.assertRaisesRegex(BudgetError, 'completed paced'):
            read_prior(self.prior)

    def test_original_rows_are_rechecked_not_only_the_carry_totals(self):
        with closing(sqlite3.connect(self.original / 'credits.sqlite')) as db:
            db.execute("UPDATE attempts SET id='changed-old-id' WHERE id='old-known-1'")
            db.commit()
        with self.assertRaisesRegex(BudgetError, 'cost chain'):
            read_prior(self.prior)

    def test_prior_pending_or_unfrozen_original_chain_is_rejected(self):
        with closing(sqlite3.connect(self.prior / 'credits.sqlite')) as db:
            db.execute("UPDATE attempts SET status='pending'")
            db.commit()
        with self.assertRaises(BudgetError):
            read_prior(self.prior)
        with closing(sqlite3.connect(self.prior / 'credits.sqlite')) as db:
            db.execute("UPDATE attempts SET status='settled'")
            db.commit()
        with closing(sqlite3.connect(self.original / 'credits.sqlite')) as db:
            db.execute("UPDATE metadata SET value='' WHERE key='frozen_reason'")
            db.commit()
        with self.assertRaises(BudgetError):
            read_prior(self.prior)

    def test_bad_carry_totals_and_hashes_are_rejected(self):
        for field, value in [('committed_credits', '0'), ('pending_credits', '.1'),
                             ('unknown_credits', 'NaN'), ('ledger_hash', 'bad')]:
            changed = deepcopy(self.carry)
            changed[field] = value
            with self.subTest(field=field), self.assertRaises((BudgetError, ValueError)):
                CreditLedger(self.path, carry=changed)

    def test_full_fixed_reservation_is_required(self):
        ledger = self.ledger()
        for amount in ['0', 'NaN', '-1', 'Infinity']:
            with self.subTest(amount=amount), self.assertRaises(ValueError):
                ledger.reserve('a', MODEL, 'probe', amount)


if __name__ == '__main__':
    unittest.main()
