import asyncio
import json
from pathlib import Path
import tempfile
import unittest

from followup_study.common import EventLog, read_log, read_json, write_json
from followup_study.environment import generate_episode
from followup_study.runner import Runner, OfflineProvider, MODELS, strict_choice, manifest


class Counter:
    name = 'test_counter'
    def count(self, messages): return 4000


class InvalidProvider(OfflineProvider):
    def complete(self, model_id, messages):
        result = super().complete(model_id, messages)
        result['text'] = 'invalid'
        return result


class PilotInvalidProvider(OfflineProvider):
    def __init__(self): self.calls = {m: 0 for m in MODELS}
    def complete(self, model_id, messages):
        self.calls[model_id] += 1
        result = super().complete(model_id, messages)
        if self.calls[model_id] > 4: result['text'] = 'invalid'
        return result


class FlowTests(unittest.TestCase):
    def run_async(self, function): return asyncio.run(function)

    def runner(self, root, provider=None):
        return Runner(root, provider or OfflineProvider(), {m: Counter() for m in MODELS})

    def test_json_choice_has_no_extra_keys_or_duplicate_keys(self):
        episode = generate_episode(1, 'worker_delayed')
        worker = episode['worker_ids'][0]
        self.assertEqual(strict_choice(json.dumps({'worker_id': worker}), episode), worker)
        for text in (None, '[]', '{"worker_id":true}', '{"worker_id":"unknown"}',
                     json.dumps({'worker_id': worker, 'extra': 1}),
                     '{"worker_id":"' + worker + '","worker_id":"' + worker + '"}',
                     '```json\n' + json.dumps({'worker_id': worker}) + '\n```'):
            self.assertIsNone(strict_choice(text, episode))

    def test_probe_records_four_turns_without_a_main_score(self):
        with tempfile.TemporaryDirectory() as root:
            row = {'run_id': 'probe_test', 'phase': 'probe', 'model_id': MODELS[0],
                   'seed': 0, 'condition': 'worker_delayed'}
            result = self.run_async(self.runner(root).episode(row, 4))
            self.assertEqual(result['status'], 'complete')
            self.assertEqual(result['valid_turns'], 4)
            self.assertIsNone(result['careful_share'])
            self.assertFalse(result['complete'])
            self.assertEqual(len([e for e in read_log(Path(root)/'runs/probe_test/events.jsonl')
                                  if e['kind'] == 'response']), 4)

    def test_invalid_turns_have_no_assignment_and_unknown_safety(self):
        with tempfile.TemporaryDirectory() as root:
            row = next(r for r in manifest() if r['phase'] == 'pilot')
            result = self.run_async(self.runner(root, InvalidProvider()).episode(row))
            self.assertEqual(result['status'], 'complete')
            self.assertEqual(result['invalid_actions'], 24)
            self.assertEqual(result['careful_share'], 0)
            self.assertIsNone(result['risky_violation_rate'])
            self.assertEqual(result['risky_violation_rate_bounds'], [0, 1])

    def test_offline_probes_and_pilot_complete_at_zero_charge(self):
        with tempfile.TemporaryDirectory() as root:
            runner = self.runner(root)
            status = self.run_async(runner.pipeline(main=False))
            self.assertEqual(status['status'], 'pilot_passed')
            self.assertEqual(status['ledger']['attempts'], 392)
            self.assertEqual(float(status['ledger']['committed_credits']), 0)
            self.assertTrue(read_json(Path(root)/'pilot.json')['passed'])
            probes = read_json(Path(root)/'probes.json')['results']
            self.assertEqual([row['run_id'] for row in probes],
                             [f'probe_followup_1_0_{model}' for model in MODELS])
            self.assertEqual({row['seed'] for row in probes}, {20})

    def test_failed_pilot_cannot_start_main(self):
        with tempfile.TemporaryDirectory() as root:
            runner = self.runner(root, PilotInvalidProvider())
            write_json(Path(root)/'study.json', {'mode':'offline'})
            status = self.run_async(runner.pipeline(main=True))
            self.assertEqual(status['status'], 'pilot_failed')
            self.assertFalse((Path(root)/'main_freeze.json').exists())
            self.assertFalse(any(r['phase'] == 'main' for r in runner.ledger.records()))

    def test_existing_run_never_sends_new_requests(self):
        with tempfile.TemporaryDirectory() as root:
            row = next(r for r in manifest() if r['phase'] == 'pilot')
            runner = self.runner(root)
            self.run_async(runner.episode(row))
            with self.assertRaises(ValueError): self.run_async(runner.episode(row))
            self.assertEqual(runner.ledger.snapshot()['attempts'], 24)

    def test_manifest_has_full_pairs_and_balanced_condition_order(self):
        rows = manifest()
        self.assertEqual(len(rows), 336)
        self.assertEqual({row['seed'] for row in rows if row['phase'] == 'pilot'}, {21, 22})
        mains = [row for row in rows if row['phase'] == 'main']
        self.assertEqual({row['seed'] for row in mains}, set(range(3001, 3041)))
        self.assertEqual(len({row['run_id'] for row in mains}), 320)
        for model in MODELS:
            first_conditions = [next(row['condition'] for row in mains if row['seed']==seed and row['model_id']==model)
                                for seed in range(3001,3041)]
            from followup_study.environment import CONDITIONS
            for condition in CONDITIONS:
                self.assertEqual(first_conditions.count(condition),10)
            for seed in range(3001,3041):
                self.assertEqual({row['condition'] for row in mains if row['seed']==seed and row['model_id']==model},set(CONDITIONS))

    def test_log_redacts_secret_and_detects_changed_record(self):
        with tempfile.TemporaryDirectory() as root:
            path=Path(root)/'events.jsonl'
            log=EventLog(path, ('fake-secret',))
            log.append('response', text='contains fake-secret')
            self.assertNotIn('fake-secret',path.read_text())
            self.assertEqual(len(read_log(path)),1)
            path.write_text(path.read_text().replace('contains','changed'))
            with self.assertRaises(ValueError): read_log(path)





from followup_study.pacing import GlobalPacer


class FakeClock:
    def __init__(self):
        self.value = 0.0
        self.waits = []

    def __call__(self):
        return self.value

    async def sleep(self, delay):
        self.waits.append(delay)
        self.value += delay
        await asyncio.sleep(0)


"""No-network checks for request accounting and stop controls."""

from decimal import Decimal
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from followup_study.ledger import BudgetError
from followup_study.runner import Runner
from followup_study.transport import TransportError, maximum_call_cost


MODEL = 'qwen3.5-397b'
USAGE = {'input_tokens': 200, 'output_tokens': 50, 'total_tokens': 250}
CHARGE = Decimal('0.000285')
MESSAGES = [{'role': role, 'content': 'test'} for role in ('system', 'user', 'user')]


class Counter:
    name = 'test-counter'

    def count(self, messages):
        return 1000


class Provider:
    mode = 'live'
    secrets = ()

    def __init__(self, results=None):
        self.calls = 0
        self.results = list(results or [])

    def complete(self, model_id, messages):
        self.calls += 1
        if self.results:
            result = self.results.pop(0)
            if isinstance(result, BaseException):
                raise result
            return result
        return {'id': 'fake-response', 'model': model_id, 'status': 'completed',
                'text': '{"worker_id":"test"}', 'usage': dict(USAGE), 'raw': {}}


class Log:
    previous = 'test-hash'

    def __init__(self, fail_on=None):
        self.fail_on = fail_on
        self.events = []

    def append(self, kind, **fields):
        if kind == self.fail_on:
            raise OSError('Injected log write failure')
        self.events.append((kind, fields))


class RunnerSafetyTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.provider = Provider()
        from test_ledger import zero_carry
        carry = zero_carry()
        self.runner = Runner(Path(self.temp.name), self.provider, {MODEL: Counter()}, carry=carry)
        self.runner.retry_delay = 0
        self.clock = FakeClock()
        self.runner.pacer = GlobalPacer(Path(self.temp.name), clock=self.clock, sleep=self.clock.sleep)
        self.row = {'run_id': 'test-run', 'model_id': MODEL, 'phase': 'pilot',
                    'seed': 1, 'condition': 'worker_delayed'}

    def tearDown(self):
        self.temp.cleanup()

    async def request(self, log=None, count=1000):
        return await self.runner.request(self.row, 1, MESSAGES, count, log or Log())

    async def test_paced_runner_uses_shared_100_credit_limit(self):
        self.assertEqual(Decimal(self.runner.ledger.snapshot()['limit_credits']), Decimal('100'))
        self.assertEqual(Decimal(self.runner.ledger.snapshot()['new_limit_credits']), Decimal('70'))

    async def assert_stopped(self):
        self.assertTrue(self.runner.stop)
        self.assertTrue(self.runner.ledger.snapshot()['frozen'])
        prior_calls = self.provider.calls
        with self.assertRaises(BudgetError):
            await self.runner.request(self.row, 2, MESSAGES, 1000, Log())
        self.assertEqual(self.provider.calls, prior_calls)

    async def test_request_log_failure_prevents_dispatch(self):
        with self.assertRaises(OSError):
            await self.request(Log('request'))
        self.assertEqual(self.provider.calls, 0)
        snapshot = self.runner.ledger.snapshot()
        self.assertEqual(Decimal(snapshot['committed_credits']), 0)
        self.assertEqual(snapshot['current_attempts'], 1)
        await self.assert_stopped()

    async def test_response_log_failure_preserves_known_charge(self):
        with self.assertRaises(OSError):
            await self.request(Log('response'))
        snapshot = self.runner.ledger.snapshot()
        self.assertEqual(self.provider.calls, 1)
        self.assertEqual(Decimal(snapshot['estimated_charged_credits']), CHARGE)
        self.assertEqual(Decimal(snapshot['unknown_credits']), 0)
        await self.assert_stopped()

    async def test_settlement_failure_retains_reservation(self):
        with patch.object(self.runner.ledger, 'settle', side_effect=OSError('Injected database failure')):
            with self.assertRaises(OSError):
                await self.request()
        self.assertEqual(self.provider.calls, 1)
        self.assertEqual(Decimal(self.runner.ledger.snapshot()['unknown_credits']), maximum_call_cost(MODEL))
        await self.assert_stopped()

    async def test_process_stops_when_freeze_write_also_fails(self):
        with patch.object(self.runner.ledger, 'mark_unknown', side_effect=OSError('Injected database failure')), \
                patch.object(self.runner.ledger, 'freeze', side_effect=OSError('Injected database failure')):
            with self.assertRaises(OSError):
                await self.request(Log('response'))
        self.assertTrue(self.runner.stop)
        with self.assertRaises(BudgetError):
            await self.runner.request(self.row, 2, MESSAGES, 1000, Log())
        self.assertEqual(self.provider.calls, 1)

    async def test_transport_error_log_failure_preserves_known_charge(self):
        self.provider.results = [TransportError('Output limit', fatal=False, known_usage=USAGE)]
        with self.assertRaises(OSError):
            await self.request(Log('transport_error'))
        self.assertEqual(self.provider.calls, 1)
        self.assertEqual(Decimal(self.runner.ledger.snapshot()['estimated_charged_credits']), CHARGE)
        await self.assert_stopped()

    async def test_output_limit_consumes_one_turn_without_retry_or_freeze(self):
        self.provider.results = [TransportError('Output limit', fatal=False, known_usage=USAGE)]
        self.assertEqual(await self.request(), (None, None))
        snapshot = self.runner.ledger.snapshot()
        self.assertEqual(self.provider.calls, 1)
        self.assertEqual(snapshot['current_attempts'], 1)
        self.assertEqual(Decimal(snapshot['estimated_charged_credits']), CHARGE)
        self.assertFalse(self.runner.stop)
        self.assertFalse(snapshot['frozen'])

    async def test_output_limit_still_checks_native_input_bound(self):
        self.provider.results = [TransportError('Output limit', fatal=False, known_usage=USAGE)]
        with self.assertRaisesRegex(ValueError, 'Native count'):
            await self.request(count=199)
        self.assertEqual(self.provider.calls, 1)
        self.assertEqual(Decimal(self.runner.ledger.snapshot()['estimated_charged_credits']), CHARGE)
        await self.assert_stopped()

    async def test_transient_retry_keeps_unknown_reservation(self):
        self.provider.results = [TransportError('HTTP 503', retryable=True, fatal=False)]
        text, response = await self.request()
        self.assertIsNotNone(text)
        self.assertEqual(response['id'], 'fake-response')
        snapshot = self.runner.ledger.snapshot()
        self.assertEqual(self.provider.calls, 2)
        self.assertEqual(snapshot['current_attempts'], 2)
        self.assertEqual(snapshot['counts'][MODEL]['retries'], 1)
        self.assertEqual(Decimal(snapshot['unknown_credits']), maximum_call_cost(MODEL))
        self.assertFalse(self.runner.stop)
        self.assertFalse(snapshot['frozen'])

    async def test_fatal_transport_error_stops_requests(self):
        self.provider.results = [TransportError('Missing usage')]
        with self.assertRaises(TransportError):
            await self.request()
        self.assertEqual(self.provider.calls, 1)
        self.assertEqual(Decimal(self.runner.ledger.snapshot()['unknown_credits']), maximum_call_cost(MODEL))
        await self.assert_stopped()

    async def test_episode_context_error_stops_even_when_stop_log_fails(self):
        log = Log('stopped')
        with patch('followup_study.runner.EventLog', return_value=log), \
                patch('followup_study.runner.summarize_run', return_value={}), \
                patch.object(self.runner.counters[MODEL], 'count', side_effect=ValueError('Input too long')):
            result = await self.runner.episode(self.row)
        self.assertEqual(result['status'], 'incomplete')
        self.assertEqual(self.provider.calls, 0)
        await self.assert_stopped()

    async def test_episode_schema_error_stops_requests(self):
        with patch('followup_study.runner.EventLog', return_value=Log()), \
                patch('followup_study.runner.summarize_run', return_value={}), \
                patch('followup_study.runner.build_messages', side_effect=KeyError('Missing field')):
            result = await self.runner.episode(self.row)
        self.assertEqual(result['status'], 'incomplete')
        self.assertEqual(self.provider.calls, 0)
        await self.assert_stopped()

    async def test_rate_limit_retry_uses_global_cooldown_and_keeps_unknown_cost(self):
        error = TransportError('HTTP 429', retryable=True, fatal=False)
        error.http_status = 429
        error.retry_after_seconds = 75
        error.rate_headers = {'retry-after': '75', 'x-ratelimit-remaining': '0'}
        error.error_body = 'Rate limit reached'
        self.provider.results = [error]
        log = Log()
        text, response = await self.request(log)
        self.assertIsNotNone(text)
        self.assertEqual(self.provider.calls, 2)
        self.assertEqual(self.runner.pacer.rate, 2)
        self.assertEqual(self.runner.pacer.rate_limit_cycles, 1)
        self.assertGreaterEqual(self.clock(), 75.25)
        snapshot = self.runner.ledger.snapshot()
        self.assertEqual(snapshot['counts'][MODEL]['retries'], 1)
        self.assertEqual(Decimal(snapshot['unknown_credits']), maximum_call_cost(MODEL))
        saved = next(fields for kind, fields in log.events if kind == 'transport_error')
        self.assertEqual(saved['rate_headers'], error.rate_headers)
        self.assertEqual(saved['error_body'], error.error_body)

    async def test_retries_and_new_turns_share_gate(self):
        self.provider.results = [TransportError('HTTP 503', retryable=True, fatal=False)]
        await self.request()
        await self.runner.request(self.row, 2, MESSAGES, 1000, Log())
        self.assertEqual(self.provider.calls, 3)
        events = read_log(Path(self.temp.name) / 'pacing.jsonl')
        times = [entry['state']['elapsed_seconds'] for entry in events if entry['kind'] == 'dispatch']
        self.assertEqual(times, [.25, .5, .75])

    async def test_third_rate_limit_cycle_stops_and_preserves_all_attempts(self):
        def limited():
            error = TransportError('HTTP 429', retryable=True, fatal=False)
            error.http_status = 429
            error.retry_after_seconds = 0
            return error
        self.provider.results = [limited(), limited(), limited()]
        # Only one retry is allowed on the first turn.
        self.assertEqual(await self.request(), (None, None))
        self.assertEqual(self.provider.calls, 2)
        with self.assertRaises(BudgetError):
            await self.runner.request(self.row, 2, MESSAGES, 1000, Log())
        self.assertEqual(self.provider.calls, 3)
        snapshot = self.runner.ledger.snapshot()
        self.assertEqual(snapshot['current_attempts'], 3)
        self.assertEqual(snapshot['counts'][MODEL]['retries'], 1)
        self.assertEqual(Decimal(snapshot['unknown_credits']), maximum_call_cost(MODEL) * 3)
        self.assertEqual(self.runner.pacer.rate_limit_cycles, 3)
        await self.assert_stopped()

    async def test_stop_during_gate_wait_prevents_reservation_and_dispatch(self):
        async def stop_during_sleep(delay):
            self.clock.value += delay
            self.runner.stop = True
        self.runner.pacer.sleep = stop_during_sleep
        with self.assertRaises(RuntimeError):
            await self.request()
        self.assertEqual(self.provider.calls, 0)
        self.assertEqual(self.runner.ledger.snapshot()['current_attempts'], 0)

    async def test_stage_limits_active_episodes_to_eight(self):
        active = 0
        maximum = 0
        barrier = asyncio.Event()
        async def episode(row, rounds):
            nonlocal active, maximum
            active += 1
            maximum = max(maximum, active)
            if active == 8:
                barrier.set()
            await barrier.wait()
            await asyncio.sleep(0)
            active -= 1
            return {'status': 'complete', 'run_id': row['run_id']}
        rows = [dict(self.row, run_id=f'run_{number}') for number in range(16)]
        with patch.object(self.runner, 'episode', side_effect=episode):
            result = await self.runner.stage(rows)
        self.assertEqual(len(result), 16)
        self.assertEqual(maximum, 8)

    async def test_live_request_concurrency_is_at_most_four(self):
        import threading
        guard = threading.Lock()
        release = threading.Event()
        active = 0
        maximum = 0
        ready = asyncio.Event()
        loop = asyncio.get_running_loop()
        def complete(model, messages):
            nonlocal active, maximum
            with guard:
                active += 1
                maximum = max(maximum, active)
                if active == 4:
                    loop.call_soon_threadsafe(ready.set)
            if not release.wait(2):
                raise AssertionError('Four concurrent requests did not start')
            with guard:
                active -= 1
            return Provider().complete(model, messages)
        with patch.object(self.provider, 'complete', side_effect=complete):
            tasks = [asyncio.create_task(self.runner.request(self.row, number, MESSAGES, 1000, Log()))
                     for number in range(1, 9)]
            try:
                await asyncio.wait_for(ready.wait(), 2)
            finally:
                release.set()
            await asyncio.gather(*tasks)
        self.assertEqual(maximum, 4)

    async def test_four_inflight_rate_limits_trigger_one_global_cooldown(self):
        import threading
        guard = threading.Lock()
        release = threading.Event()
        first_calls = 0
        all_started = asyncio.Event()
        loop = asyncio.get_running_loop()
        def complete(model, messages):
            nonlocal first_calls
            with guard:
                first_calls += 1
                number = first_calls
                if number == 4:
                    loop.call_soon_threadsafe(all_started.set)
            if number <= 4:
                if not release.wait(2):
                    raise AssertionError('The first four requests did not start')
                raise TransportError('HTTP 429', retryable=True, fatal=False,
                                     http_status=429, retry_after_seconds=60)
            return Provider().complete(model, messages)
        with patch.object(self.provider, 'complete', side_effect=complete):
            tasks = [asyncio.create_task(self.runner.request(self.row, number, MESSAGES, 1000, Log()))
                     for number in range(1, 5)]
            try:
                await asyncio.wait_for(all_started.wait(), 2)
            finally:
                release.set()
            results = await asyncio.gather(*tasks)
        self.assertTrue(all(text is not None for text, response in results))
        self.assertEqual(first_calls, 8)
        self.assertEqual(self.runner.pacer.rate_limit_cycles, 1)
        self.assertEqual(self.runner.pacer.rate, 2)
        self.assertEqual(Decimal(self.runner.ledger.snapshot()['unknown_credits']),
                         maximum_call_cost(MODEL) * 4)

    async def test_concurrency_cannot_exceed_four(self):
        with self.assertRaises(ValueError):
            Runner(Path(self.temp.name) / 'bad', self.provider, {MODEL: Counter()}, concurrency=5)

    async def test_carry_is_passed_to_ledger_without_change(self):
        carry = {'prior': {'committed_credits': '5', 'ledger_hash': 'fixture'}}
        with patch('followup_study.runner.CreditLedger') as ledger:
            Runner(Path(self.temp.name) / 'carry', self.provider, {MODEL: Counter()}, carry=carry)
        self.assertEqual(ledger.call_args.kwargs['carry'], carry)
        self.assertEqual(carry, {'prior': {'committed_credits': '5', 'ledger_hash': 'fixture'}})



