"""Offline tests for the single follow-up authorization claim."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from followup_study.authorization import AuthorizationError, claim_authorization
from followup_study.ledger import read_prior, record_hash
from test_ledger import prior_fixture, zero_carry


class AuthorizationTests(unittest.TestCase):
    def test_claim_binds_result_root_carry_and_both_limits(self):
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder)
            carry = zero_carry()
            receipt = claim_authorization(base, base/'live_followup', carry, source_hashes={'runner.py': 'abc'})
            saved = json.loads((base/'results/followup_authorization/claim.json').read_text())
            self.assertEqual(saved, receipt)
            self.assertEqual(saved['result_root'], str((base/'live_followup').resolve()))
            self.assertEqual(saved['prior_carry_sha256'], record_hash(carry))
            self.assertEqual(saved['global_limit_credits'], '100')
            self.assertEqual(saved['new_limit_credits'], '70')
            self.assertFalse(saved['automatic_release'])
            carry['committed_credits'] = '99'
            receipt['new_limit_credits'] = '99'
            self.assertEqual(json.loads((base/'results/followup_authorization/claim.json').read_text()), saved)

    def test_claim_blocks_same_or_different_result_roots(self):
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder)
            claim_authorization(base, base/'first', zero_carry())
            for name in ('first', 'second'):
                with self.subTest(name=name), self.assertRaises(AuthorizationError):
                    claim_authorization(base, base/name, zero_carry())

    def test_simultaneous_claims_allow_exactly_one_live_run(self):
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder)
            def attempt(index):
                try:
                    return claim_authorization(base, base/f'run-{index}', zero_carry())
                except AuthorizationError:
                    return None
            with ThreadPoolExecutor(max_workers=8) as pool:
                receipts = list(pool.map(attempt, range(24)))
            accepted = [value for value in receipts if value is not None]
            self.assertEqual(len(accepted), 1)
            self.assertEqual(json.loads((base/'results/followup_authorization/claim.json').read_text()), accepted[0])

    def test_an_empty_or_incomplete_claim_still_blocks(self):
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder)
            (base/'results/followup_authorization').mkdir(parents=True)
            with self.assertRaises(AuthorizationError):
                claim_authorization(base, base/'new', zero_carry())

    def test_failed_write_keeps_the_claim_and_blocks_retry(self):
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder)
            with patch('followup_study.authorization._sync_directory', side_effect=OSError('simulated disk error')):
                with self.assertRaises(OSError):
                    claim_authorization(base, base/'new', zero_carry())
            self.assertTrue((base/'results/followup_authorization').is_dir())
            with self.assertRaises(AuthorizationError):
                claim_authorization(base, base/'retry', zero_carry())

    def test_invalid_inputs_do_not_claim_the_authorization(self):
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder)
            with self.assertRaises((ValueError, RuntimeError)):
                claim_authorization(base, base/'new', None)
            with self.assertRaises(ValueError):
                claim_authorization(base, base/'new', zero_carry(), source_hashes={'bad': object()})
            with self.assertRaises(ValueError):
                claim_authorization(base, base/'results', zero_carry())
            self.assertFalse((base/'results/followup_authorization').exists())

    def test_claim_does_not_change_either_prior_root(self):
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder)
            prior_root = base/'paced'
            original_root = prior_fixture(prior_root)
            before = {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                      for root in (prior_root, original_root) for p in root.iterdir() if p.is_file()}
            carry = read_prior(prior_root)
            claim_authorization(base, base/'new', carry)
            after = {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                     for root in (prior_root, original_root) for p in root.iterdir() if p.is_file()}
            self.assertEqual(before, after)
            self.assertTrue((base/'results/followup_authorization/claim.json').is_file())


if __name__ == '__main__':
    unittest.main()
