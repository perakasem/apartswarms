"""Build tables and charts after the follow-up collection and record audit finish."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

MODELS = ('qwen3.5-397b', 'glm-5.2')
CONDITIONS = ('worker_immediate', 'notifier_immediate', 'worker_delayed', 'notifier_delayed')
LABELS = {'worker_immediate': 'Worker notice, immediate audit',
          'notifier_immediate': 'Relay notice, immediate audit',
          'worker_delayed': 'Worker notice, delayed audit',
          'notifier_delayed': 'Relay notice, delayed audit'}
METRICS = ('careful_share', 'risky_violation_rate', 'supported_task_success',
           'careful_share_late_minus_early', 'careful_share_recovery_minus_late')


def read(path):
    return json.loads(path.read_text())


def write_csv(path, rows):
    if not rows:
        raise ValueError('The output table has no rows')
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def percent(value):
    return value * 100 if value is not None else None


def build(root):
    root = Path(root).resolve()
    status, audit, analysis, runs = [read(root/name) for name in
                                    ('status.json', 'audit.json', 'analysis.json', 'results.json')]
    if (status.get('status') != 'complete' or status.get('mode') not in ('live', 'offline')
            or audit.get('passed') is not True or audit.get('issues') != []):
        raise ValueError('A complete collection and a passed record audit are required')
    mode = status['mode']
    if set(analysis.get('models', {})) != set(MODELS):
        raise ValueError('The saved analysis needs both planned models')
    conditions, effects, seed_rows, run_rows, block_rows = [], [], [], [], []
    for model in MODELS:
        result = analysis['models'][model]
        if result.get('expected_pairs') != 40:
            raise ValueError('The final figure needs the fixed 40-seed schedule')
        for condition in CONDITIONS:
            group = [row for row in runs if row['model_id'] == model and row['condition'] == condition]
            if len(group) != 40 or any(row.get('complete') is not True for row in group):
                raise ValueError('A model condition lacks 40 complete runs')
            means = result['secondary_condition_means'][condition]
            conditions.append({'mode': mode, 'model': model, 'condition': condition, 'runs': len(group),
                               **{metric: means[metric]['mean'] for metric in METRICS},
                               **{metric+'_evaluable_runs': means[metric]['runs'] for metric in METRICS},
                               'valid_assignments_all24': sum(row['valid_assignments'] for row in group),
                               'invalid_assignments_all24': sum(row['invalid_actions'] for row in group),
                               'primary_valid_assignments': sum(row['primary_valid_assignments'] for row in group),
                               'primary_invalid_assignments': sum(row['primary_invalid_actions'] for row in group),
                               'primary_known_violations': sum(row['primary_known_violations'] for row in group),
                               'primary_unknown_risky_outcomes': sum(row['unknown_risky_outcomes'] for row in group)})
            for block, item in enumerate(means['block_careful_shares'], 1):
                block_rows.append({'mode': mode, 'model': model, 'condition': condition, 'block': block,
                                   'start_choice': (block-1)*6+1, 'end_choice': block*6,
                                   'mean_careful_share': item['mean'], 'evaluable_runs': item['runs'],
                                   'missing_runs': item['missing_runs'], 'descriptive_only': True})
            for row in sorted(group, key=lambda x: x['seed']):
                run_rows.append({'mode': mode, 'model': model, 'condition': condition, 'seed': row['seed'],
                                 'complete': row['complete'], 'primary_complete': row['primary_complete'],
                                 **{metric: row[metric] for metric in METRICS},
                                 'valid_assignments_all24': row['valid_assignments'],
                                 'invalid_assignments_all24': row['invalid_actions'],
                                 'primary_valid_assignments': row['primary_valid_assignments'],
                                 'primary_invalid_assignments': row['primary_invalid_actions'],
                                 'primary_known_violations': row['primary_known_violations'],
                                 'primary_unknown_risky_outcomes': row['unknown_risky_outcomes']})
        for contrast_name, saved_name in [('delayed_worker_minus_relay', 'delayed_paired_differences'),
                                           ('immediate_worker_minus_relay', 'immediate_paired_differences'),
                                           ('audit_delay_interaction', 'audit_delay_interactions')]:
            for metric, item in result[saved_name].items():
                estimate = item['estimate']
                p, role = None, 'supporting_unadjusted_interval'
                if contrast_name == 'delayed_worker_minus_relay' and metric == 'careful_share':
                    p, role = result['primary_holm_adjusted_p'], 'primary'
                elif contrast_name == 'delayed_worker_minus_relay' and metric == 'risky_violation_rate':
                    p, role = result['risk_holm_adjusted_p'], 'planned_secondary_risk'
                effects.append({'mode': mode, 'model': model, 'contrast': contrast_name,
                                'outcome': metric, 'role': role, 'complete_seed_blocks': estimate['pairs'],
                                'missing_seed_blocks': item['missing_pairs'],
                                'effect_percentage_points': percent(estimate['mean']),
                                'ci95_low_percentage_points': percent(estimate['ci95'][0]) if estimate['ci95'] else None,
                                'ci95_high_percentage_points': percent(estimate['ci95'][1]) if estimate['ci95'] else None,
                                'degenerate_bootstrap': estimate['degenerate'], 'holm_adjusted_directional_p': p,
                                'full_sample_bound_low_percentage_points': percent(item['all_planned_pairs_missing_bounds'][0]),
                                'full_sample_bound_high_percentage_points': percent(item['all_planned_pairs_missing_bounds'][1])})
                for pair in item['pairs']:
                    seed_rows.append({'mode': mode, 'model': model, 'contrast': contrast_name,
                                      'outcome': metric, 'seed': pair['seed'],
                                      'difference': pair['difference'],
                                      'lower_bound': pair['difference_bounds'][0],
                                      'upper_bound': pair['difference_bounds'][1],
                                      'missing_conditions': ';'.join(pair['missing_conditions']),
                                      'condition_values_json': json.dumps(pair['values'], sort_keys=True, separators=(',', ':'))})
    write_csv(root/'condition_means.csv', conditions)
    write_csv(root/'paired_effects.csv', effects)
    write_csv(root/'seed_contrasts.csv', seed_rows)
    write_csv(root/'main_runs.csv', run_rows)
    write_csv(root/'block_means.csv', block_rows)
    claim = {'mode': mode, 'primary_direction': 'less', 'risk_direction': 'greater',
             'models': {model: {name: analysis['models'][model][name] for name in
                               ('complete_primary_pairs', 'complete_risk_pairs', 'primary_holm_adjusted_p',
                                'risk_holm_adjusted_p', 'joint_unadjusted_p', 'joint_holm_adjusted_p',
                                'full_safety_failure_supported', 'full_claim_decision')} for model in MODELS},
             'rule': analysis['joint_claim_rule']}
    (root/'claim_tests.json').write_text(json.dumps(claim, indent=2)+'\n')

    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False,
                         'svg.fonttype': 'none', 'font.family': 'DejaVu Sans'})
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4), layout='constrained')
    for ax, metric, title in zip(axes, ('careful_share', 'risky_violation_rate'),
                                 ('Careful workers: share of free choices', 'Team: violations on risky tasks')):
        tick_labels = []
        for y, model, color in zip((1,0), MODELS, ('#276b95','#9b5834')):
            item = next(item for item in effects if item['model']==model and item['outcome']==metric
                        and item['contrast']=='delayed_worker_minus_relay')
            tick_labels.append(f'{model} (n={item["complete_seed_blocks"]})')
            value, low, high = [item[key] for key in ('effect_percentage_points',
                                'ci95_low_percentage_points','ci95_high_percentage_points')]
            if value is None:
                ax.text(0,y,'No estimate',va='center'); continue
            ax.errorbar(value,y,xerr=[[max(0,value-low)],[max(0,high-value)]],fmt='o',
                        color=color,capsize=5,markersize=7)
        ax.set_yticks([1,0],tick_labels); ax.set_ylim(-.6,1.6)
        ax.axvline(0,color='#666666',linewidth=1,linestyle='--')
        ax.grid(axis='x',alpha=.18)
        ax.set_title(title,fontsize=12,loc='left'); ax.set_xlabel('Difference (percentage points)')
    prefix = 'OFFLINE SIMULATION — ' if mode=='offline' else ''
    fig.suptitle(prefix+'Delayed audit: worker notices minus relay notices',fontsize=13)
    caption = 'Primary window: choices 1–18. Bars show 95% paired bootstrap intervals.\nRisk is a planned secondary outcome; significance decisions use the saved adjusted tests.'
    if mode=='offline': caption='Program test only. These are not live model findings.\n'+caption
    fig.supxlabel(caption,fontsize=9)
    fig.savefig(root/'followup_effects.svg',metadata={'Date':None}); fig.savefig(root/'followup_effects.png',dpi=180)
    plt.close(fig)

    fig, axes = plt.subplots(1,2,figsize=(10.5,4.8),sharey=True)
    fig.subplots_adjust(left=.07,right=.99,top=.84,bottom=.31,wspace=.06)
    styles = {'worker_immediate':('#0072B2','-','o'), 'notifier_immediate':('#0072B2','--','s'),
              'worker_delayed':('#D55E00','-','o'), 'notifier_delayed':('#D55E00','--','s')}
    for ax, model in zip(axes,MODELS):
        for condition in CONDITIONS:
            points=analysis['models'][model]['secondary_condition_means'][condition]['block_careful_shares']
            values=[percent(item['mean']) if item['mean'] is not None else float('nan') for item in points]
            color,linestyle,marker=styles[condition]
            ax.plot(range(1,5),values,color=color,linestyle=linestyle,marker=marker,label=LABELS[condition])
        ax.axvline(3.5,color='#888888',linestyle=':',linewidth=1)
        ax.set_xticks([1,2,3,4],['1–6','7–12','13–18','19–24'])
        ax.set_ylim(-2,102); ax.set_title(model); ax.set_xlabel('Free-choice rounds')
        ax.grid(axis='y',alpha=.18)
    axes[0].set_ylabel('Mean careful-worker share (%)')
    handles,labels=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.5,.08),ncol=2,fontsize=9)
    fig.suptitle(prefix+'Careful-worker selection across four blocks',fontsize=13)
    fig.text(.5,.02,'Descriptive means. The dotted line marks common audit release before choice 19.\nThe recovery change is not a separate randomized effect.',ha='center',fontsize=9)
    fig.savefig(root/'followup_blocks.svg',metadata={'Date':None}); fig.savefig(root/'followup_blocks.png',dpi=180)
    plt.close(fig)
    names=['condition_means.csv','paired_effects.csv','seed_contrasts.csv','main_runs.csv','block_means.csv',
           'claim_tests.json','followup_effects.svg','followup_effects.png','followup_blocks.svg','followup_blocks.png']
    provenance={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                'mode':mode,'paid_calls':0,'matplotlib_version':matplotlib.__version__,
                'inputs':{name:hashlib.sha256((root/name).read_bytes()).hexdigest()
                          for name in ('status.json','audit.json','analysis.json','results.json')},
                'outputs':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in names}}
    (root/'result_files_provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
    print(json.dumps({'built':names,'mode':mode,'paid_calls':0}))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('result_root',type=Path)
    build(parser.parse_args().result_root)
