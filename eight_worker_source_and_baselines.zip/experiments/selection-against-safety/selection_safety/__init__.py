"""Selection Against Safety: reproducible delegation experiment."""
