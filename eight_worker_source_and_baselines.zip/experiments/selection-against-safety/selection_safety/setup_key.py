"""Save a user-provided Adaption key locally without echoing or logging it."""
from pathlib import Path
import getpass
import os

def main():
    root = Path(__file__).resolve().parent.parent
    target = root / ".secrets" / "adaption_api_key"
    if target.exists():
        raise SystemExit("A local key already exists. Remove or replace it explicitly if needed.")
    value = getpass.getpass("Adaption API key (hidden input): ").strip()
    if not value or any(c.isspace() for c in value):
        raise SystemExit("No key saved: supply one nonempty token.")
    target.parent.mkdir(mode=0o700, exist_ok=True)
    fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(value + "\n")
    print("Local credential saved with restricted permissions. It is excluded from result packages.")

if __name__ == "__main__":
    main()
