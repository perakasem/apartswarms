"""Install a verified v2 source repair while preserving credentials and results.

Payload manifest.json format: {"files": {"relative/path.py": "sha256 hex"}}.
Only direct selection_safety/*.py, selection_safety/*.md and the named launcher
are eligible. All validation finishes before any target writes occur.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import tempfile


class RepairError(ValueError):
    pass


def _regular(path: Path) -> None:
    try:
        mode = path.lstat().st_mode
    except FileNotFoundError:
        raise RepairError(f"Required file is missing: {path}") from None
    if not stat.S_ISREG(mode):
        raise RepairError(f"Expected a regular file without symlinks: {path}")


def _directory(path: Path) -> None:
    try:
        mode = path.lstat().st_mode
    except FileNotFoundError:
        raise RepairError(f"Required directory is missing: {path}") from None
    if not stat.S_ISDIR(mode):
        raise RepairError(f"Expected a directory without symlinks: {path}")


def _hash(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise RepairError("Manifest contains a duplicate key")
        result[key] = value
    return result


def _atomic_write(path: Path, data: bytes, mode: int) -> None:
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(prefix=".repair-v2-", dir=path.parent, delete=False) as handle:
            temporary = Path(handle.name)
            os.fchmod(handle.fileno(), mode)
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def install(payload: Path, target: Path) -> dict:
    payload, target = Path(payload).absolute(), Path(target).absolute()
    _directory(payload)
    _directory(target)
    _directory(target / "selection_safety")
    _regular(target / "selection_safety/core.py")
    _regular(target / "Run_Adaption_Pilot.command")
    manifest_path = payload / "manifest.json"
    _regular(manifest_path)
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"), object_pairs_hook=_unique_object)
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise RepairError("Repair manifest is not valid UTF-8 JSON") from exc
    files = manifest.get("files") if isinstance(manifest, dict) else None
    if not isinstance(files, dict) or not files:
        raise RepairError("Repair manifest must contain a nonempty files mapping")

    backups = target / "backups"
    if backups.exists() or backups.is_symlink():
        _directory(backups)
    planned, skipped = [], []
    for name, digest in sorted(files.items()):
        allowed = isinstance(name, str) and (
            name == "Run_Adaption_Pilot.command"
            or re.fullmatch(r"selection_safety/[A-Za-z0-9_][A-Za-z0-9_.-]*\.(?:py|md)", name)
        )
        if not allowed:
            raise RepairError(f"Manifest path is not allowlisted: {name!r}")
        if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
            raise RepairError(f"Invalid SHA-256 value for {name}")
        source, destination = payload / name, target / name
        _directory(source.parent)
        _directory(destination.parent)
        _regular(source)
        content = source.read_bytes()
        if _hash(content) != digest:
            raise RepairError(f"Payload SHA-256 mismatch for {name}")
        desired_mode = 0o700 if name == "Run_Adaption_Pilot.command" else 0o644
        previous = None
        previous_mode = None
        if destination.exists() or destination.is_symlink():
            _regular(destination)
            previous = destination.read_bytes()
            previous_mode = stat.S_IMODE(destination.stat().st_mode)
        if previous == content and previous_mode == desired_mode:
            skipped.append(name)
        else:
            planned.append((name, content, desired_mode, previous, previous_mode))

    # Validation above includes every file, hash, source/destination parent and
    # existing destination. No target write has happened at this point.
    if not planned:
        return {"changed_files": [], "skipped_files": skipped, "backup_dir": None}
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    backup_dir = backups / ("repair_v2_" + stamp)
    if backup_dir.exists() or backup_dir.is_symlink():
        raise RepairError("Backup destination already exists; retry the repair")

    # Save all original source bytes before replacing any source file.
    backups.mkdir(mode=0o700, exist_ok=True)
    backup_dir.mkdir(mode=0o700)
    for name, _, _, previous, previous_mode in planned:
        if previous is not None:
            backup = backup_dir / name
            backup.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            _atomic_write(backup, previous, previous_mode)
    for name, content, desired_mode, _, _ in planned:
        _atomic_write(target / name, content, desired_mode)
    return {
        "changed_files": [entry[0] for entry in planned],
        "skipped_files": skipped,
        "backup_dir": str(backup_dir),
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--payload", type=Path, required=True)
    parser.add_argument("--target", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        result = install(args.payload, args.target)
    except (RepairError, OSError) as exc:
        parser.exit(1, f"Repair stopped: {exc}\n")
    print(f"Updated {len(result['changed_files'])} file(s); {len(result['skipped_files'])} already current.")
    if result["backup_dir"]:
        print(f"Backups: {result['backup_dir']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
