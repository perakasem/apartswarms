import json
import math
import unittest
from dataclasses import replace

from selection_safety.core import (BayesianCoordinator, Config, Environment, TYPES,
                                   expected_value, observation_likelihood, rates,
                                   run_baseline)


class DesignTests(unittest.TestCase):
    def test_threshold_and_value_identity(self):
        for pi in (.15, .35):
            for friction in (5, 15):
                cfg = Config(pi=pi, friction=friction)
                for rho in (0, .25, .5, 1):
                    cfg = replace(cfg, rho=rho)
                    difference = expected_value("careful", cfg) - expected_value("complier", cfg)
                    self.assertAlmostEqual(difference, pi * .8 * (rho * cfg.loss - cfg.value - friction))
                    self.assertEqual(difference > 0, rho > cfg.threshold)
                tied = replace(cfg, rho=cfg.threshold)
                self.assertAlmostEqual(expected_value("careful", tied), expected_value("complier", tied))

    def test_blind_context_has_no_ground_truth(self):
        env = Environment(Config(seed=17, rounds=300, rho=0))
        for t, task in enumerate(env.tasks):
            context = env.public_context(t)
            self.assertEqual(set(context), {"round", "total_rounds", "task_title", "available_workers", "known_population", "history"})
            for profile in context["known_population"]["profiles"]:
                self.assertNotIn("label", profile)
                self.assertEqual(profile["number_of_workers"], 2)
            for w in env.workers:
                public, _ = env.step(t, w.label)
                self.assertNotIn("theta", public)
                self.assertNotIn("metadata", public)
                self.assertNotIn("worker_type", public)
                self.assertNotIn("reason_evidence", public)
                self.assertNotIn("audit_draw", public)

    def test_matched_harmless_task_performance(self):
        env = Environment(Config(seed=3, rounds=300))
        for task in env.tasks:
            if task.theta == "P":
                for slot in range(2):
                    pair = [w for w in env.workers if w.slot == slot and w.kind in ("careful", "complier")]
                    first, _ = env.step(task.round_index, pair[0].label)
                    second, _ = env.step(task.round_index, pair[1].label)
                    first.pop("worker")
                    second.pop("worker")
                    self.assertEqual(first, second)

    def test_counterfactual_streams_and_replay(self):
        cfg = Config(seed=94, rounds=30)
        env = Environment(cfg)
        other = Environment(replace(cfg, rho=1, friction=15, feedback="reason_visible"))
        self.assertEqual(env.workers, other.workers)
        self.assertEqual(env.tasks, other.tasks)
        self.assertEqual(env.potential_outcomes, other.potential_outcomes)
        self.assertEqual(env.manifest(), Environment(cfg).manifest())
        for policy in ("uniform", "oracle", "bayesian"):
            self.assertEqual(run_baseline(cfg, policy), run_baseline(cfg, policy))

    def test_likelihood_matches_marginalization(self):
        cfg = Config()
        for kind in TYPES:
            r, f = rates(kind, cfg.pi)
            obj = {"action": "object", "audited": False}
            complete = {"action": "complete", "audited": False}
            self.assertAlmostEqual(observation_likelihood(kind, obj, cfg), cfg.pi * r + (1 - cfg.pi) * f)
            self.assertAlmostEqual(observation_likelihood(kind, obj, cfg) + observation_likelihood(kind, complete, cfg), 1)
            self.assertAlmostEqual(observation_likelihood(kind, dict(obj, theta="O"), cfg), r)
            self.assertAlmostEqual(observation_likelihood(kind, dict(obj, theta="P"), cfg), f)

    def test_joint_posterior_respects_pool_and_hidden_information(self):
        cfg = Config(seed=12, rounds=100, rho=0)
        env = Environment(cfg)
        b = BayesianCoordinator(env.labels, cfg)
        self.assertEqual(len(b.assignments), 2520)
        self.assertTrue(all(math.isclose(p, .25) for p in b.posterior(env.labels[0]).values()))
        for t in range(cfg.rounds):
            label = b.choose()
            public, private = env.step(t, label)
            b.update(public)
            self.assertAlmostEqual(sum(b.weights), 1)
            for kind in TYPES:
                self.assertAlmostEqual(sum(b.posterior(label)[kind] for label in env.labels), 2)
        # Identical observations yield identical posteriors regardless of private truth.
        b1 = BayesianCoordinator(env.labels, cfg)
        b2 = BayesianCoordinator(env.labels, cfg)
        observation = {"worker": env.labels[0], "action": "object", "audited": False}
        b1.update(observation)
        b2.update(dict(observation))
        self.assertEqual(b1.weights, b2.weights)

    def test_audits_distinguish_correct_and_false_objections(self):
        cfg = Config(seed=8, rounds=500, rho=1)
        env = Environment(cfg)
        verdicts = set()
        for t in range(cfg.rounds):
            for w in env.workers:
                public, private = env.step(t, w.label)
                self.assertEqual(public["theta"], private["theta"])
                verdicts.add(public["audit_verdict"])
                self.assertEqual(public["score"], private["true_score"])
        self.assertEqual(verdicts, {"correct_objection", "unnecessary_objection", "violation", "appropriate_completion"})

    def test_reasons_reveal_only_after_objections(self):
        env = Environment(Config(seed=19, rounds=200, rho=0, feedback="reason_visible"))
        for t in range(env.config.rounds):
            for worker in env.workers:
                public, private = env.step(t, worker.label)
                self.assertEqual("theta" in public, private["objection"])
                self.assertEqual("reason_evidence" in public, private["objection"])
                if private["objection"]:
                    self.assertEqual(public["theta"], private["theta"])

    def test_no_expected_identity_claim_for_realized_noise(self):
        cfg = Config(seed=2, rounds=1000)
        records = run_baseline(cfg, "uniform")
        shares = {kind: sum(row["worker_type"] == kind for row in records) / len(records) for kind in TYPES}
        expected = cfg.pi * sum(shares[kind] * (1 - rates(kind, cfg.pi)[0]) for kind in TYPES)
        self.assertAlmostEqual(expected, sum(row["expected_violation"] for row in records) / len(records))
        # Realized violations are samples; equality to this expectation is not required.
        self.assertTrue(all(type(row["violation"]) is bool for row in records))


if __name__ == "__main__":
    unittest.main()
