"""Repair installer tests use temporary projects only."""

import hashlib
import json
from pathlib import Path
import stat
import tempfile
import unittest

from selection_safety.install_repair import RepairError, install


class RepairTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.target, self.payload = root / "project (1)", root / "payload"
        for base in (self.target, self.payload):
            (base / "selection_safety").mkdir(parents=True)
        (self.target / "selection_safety/core.py").write_bytes(b"original core\n")
        (self.target / "Run_Adaption_Pilot.command").write_bytes(b"original launcher\n")
        (self.target / ".secrets").mkdir()
        (self.target / ".secrets/key").write_bytes(b"secret sentinel")
        (self.target / "outputs/existing").mkdir(parents=True)
        (self.target / "outputs/existing/result.json").write_bytes(b"output sentinel")
        self.files = {
            "selection_safety/core.py": b"repaired core\n",
            "selection_safety/new_module.py": b"new source\n",
            "Run_Adaption_Pilot.command": b"repaired launcher\n",
        }
        for name, data in self.files.items():
            (self.payload / name).write_bytes(data)
        self.mapping = {name: hashlib.sha256(data).hexdigest() for name, data in self.files.items()}
        self.write_manifest()

    def write_manifest(self):
        (self.payload / "manifest.json").write_text(json.dumps({"files": self.mapping}))

    def assert_untouched(self):
        self.assertEqual((self.target / "selection_safety/core.py").read_bytes(), b"original core\n")
        self.assertEqual((self.target / "Run_Adaption_Pilot.command").read_bytes(), b"original launcher\n")
        self.assertFalse((self.target / "backups").exists())
        self.assertFalse((self.target / "selection_safety/new_module.py").exists())

    def test_install_backup_preservation_and_idempotence(self):
        result = install(self.payload, self.target)
        self.assertEqual(set(result["changed_files"]), set(self.files))
        backup = Path(result["backup_dir"])
        self.assertTrue(backup.name.startswith("repair_v2_"))
        self.assertEqual((backup / "selection_safety/core.py").read_bytes(), b"original core\n")
        self.assertEqual((backup / "Run_Adaption_Pilot.command").read_bytes(), b"original launcher\n")
        self.assertFalse((backup / "selection_safety/new_module.py").exists())
        self.assertFalse((backup / ".secrets").exists())
        self.assertFalse((backup / "outputs").exists())
        self.assertEqual((self.target / ".secrets/key").read_bytes(), b"secret sentinel")
        self.assertEqual((self.target / "outputs/existing/result.json").read_bytes(), b"output sentinel")
        for name, data in self.files.items():
            self.assertEqual((self.target / name).read_bytes(), data)
        self.assertEqual(stat.S_IMODE((self.target / "Run_Adaption_Pilot.command").stat().st_mode), 0o700)
        self.assertEqual(stat.S_IMODE((self.target / "selection_safety/core.py").stat().st_mode), 0o644)
        again = install(self.payload, self.target)
        self.assertEqual(again["changed_files"], [])
        self.assertEqual(set(again["skipped_files"]), set(self.files))
        self.assertIsNone(again["backup_dir"])
        self.assertEqual(len(list((self.target / "backups").iterdir())), 1)

    def test_reject_traversal_and_protected_paths_before_writes(self):
        for path in ("selection_safety/../escape.py", "../escape.py", ".secrets/key", "outputs/result.py", "/tmp/escape.py"):
            with self.subTest(path=path):
                self.mapping[path] = "0" * 64
                self.write_manifest()
                with self.assertRaises(RepairError):
                    install(self.payload, self.target)
                self.assert_untouched()
                del self.mapping[path]

    def test_reject_hash_mismatch_before_writes(self):
        self.mapping["selection_safety/new_module.py"] = "0" * 64
        self.write_manifest()
        with self.assertRaises(RepairError):
            install(self.payload, self.target)
        self.assert_untouched()

    def test_reject_destination_symlink_before_writes(self):
        elsewhere = Path(self.temp.name) / "other.py"
        elsewhere.write_text("untouched")
        (self.target / "selection_safety/new_module.py").symlink_to(elsewhere)
        with self.assertRaises(RepairError):
            install(self.payload, self.target)
        self.assertEqual(elsewhere.read_text(), "untouched")
        self.assertFalse((self.target / "backups").exists())

    def test_reject_symlink_parent_before_writes(self):
        (self.target / "backups").symlink_to(self.payload, target_is_directory=True)
        with self.assertRaises(RepairError):
            install(self.payload, self.target)
        self.assertEqual((self.target / "selection_safety/core.py").read_bytes(), b"original core\n")

    def test_reject_payload_symlink_before_writes(self):
        (self.payload / "selection_safety/core.py").unlink()
        (self.payload / "selection_safety/core.py").symlink_to(self.target / "selection_safety/core.py")
        with self.assertRaises(RepairError):
            install(self.payload, self.target)
        self.assert_untouched()


if __name__ == "__main__":
    unittest.main()
