#!/usr/bin/env python3
"""Run-clustered descriptive analysis of the selection-against-safety experiment.

Only standard-library dependencies. Inference never treats rounds as independent.
Missing contrasts stay null and are counted. All numeric results come from logs.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
import math
import random
from collections import defaultdict
from pathlib import Path
from statistics import mean

TYPES = ("careful", "complier", "over_refuser", "random_objector")
CONDITION_KEYS = ("rho", "friction", "pi", "feedback", "rounds", "value", "loss")
DEFAULTS = dict(rho=.25, friction=5, pi=.35, feedback="outcome_only", rounds=60,
                value=10, loss=40)


def canonical_type(value):
    value = str(value).lower().replace("-", "_").replace(" ", "_")
    return {"k": "careful", "c": "complier", "overrefuser": "over_refuser",
            "random": "random_objector"}.get(value, value)


def quantile(values, p):
    values = sorted(values)
    if not values:
        return None
    loc = (len(values) - 1) * p
    low = math.floor(loc)
    return values[low] + (values[math.ceil(loc)] - values[low]) * (loc - low)


def normalize_record(row, source=""):
    """Accommodate flattened records and {private_record: ..., config: ...}."""
    merged = dict(row)
    for key in ("private_record", "private", "record"):
        if isinstance(row.get(key), dict):
            merged.update(row[key])
    config = dict(DEFAULTS)
    config.update(row.get("config", merged.get("config", {})))
    for key in CONDITION_KEYS:
        if key in merged:
            config[key] = merged[key]
    if "c" in config:
        config["friction"] = config["c"]
    if "v" in config:
        config["value"] = config["v"]
    if "L" in config:
        config["loss"] = config["L"]
    worker = merged.get("worker", {})
    worker_dict = worker if isinstance(worker, dict) else {}
    label = merged.get("worker_label", merged.get("label", worker_dict.get("label", worker)))
    kind = canonical_type(merged.get("worker_type", merged.get("type", worker_dict.get("kind", worker_dict.get("type", "")))))
    if kind not in TYPES:
        raise ValueError(f"Unknown or absent worker_type: {kind!r}")
    theta = merged.get("theta", merged.get("task_type"))
    if theta is None and isinstance(merged.get("task"), dict):
        theta = merged["task"].get("theta")
    if theta not in ("O", "P"):
        raise ValueError(f"theta must be O/P, got {theta!r}")
    round_index = merged.get("round_index", merged.get("round", merged.get("t")))
    if round_index is None:
        raise ValueError("Missing round index")
    violation = merged.get("violation", merged.get("true_violation"))
    if violation is None:
        raise ValueError("Missing programmatic violation label")
    coordinator = row.get("coordinator", row.get("policy", row.get("model", merged.get("coordinator", "unknown"))))
    model = row.get("model", merged.get("model", coordinator))
    if coordinator in ("llm", "adaption"):
        coordinator = model
    seed = row.get("seed", config.get("seed", merged.get("seed")))
    run_id = row.get("run_id", merged.get("run_id"))
    if run_id is None:
        run_id = f"{coordinator}:{seed}:{json.dumps({k: config[k] for k in CONDITION_KEYS}, sort_keys=True)}"
    recall = merged.get("r", merged.get("recall", worker_dict.get("recall")))
    if recall is None:
        recall = {"careful": .9, "complier": .1, "over_refuser": .9,
                  "random_objector": float(config["pi"]) * .9 + (1 - float(config["pi"])) * .05}[kind]
    return dict(run_id=str(run_id), coordinator=str(coordinator), model=str(model),
                seed=seed, config=config, round=int(round_index), worker_label=str(label),
                worker_type=kind, theta=theta, violation=int(bool(violation)),
                recall=float(recall), source=source)


def load_records(paths):
    records = []
    for path in paths:
        path = Path(path)
        files = sorted(path.rglob("*.jsonl")) if path.is_dir() else [path]
        for file in files:
            for number, line in enumerate(file.read_text().splitlines(), 1):
                if not line.strip():
                    continue
                row = json.loads(line)
                # Request/response audit logs are not outcome records.
                if row.get("event") in ("request", "response", "api_attempt", "error"):
                    continue
                if ("validation_attempt" in row and any(key in row for key in ("result", "api_error", "error"))
                        and "private_record" not in row and "theta" not in row):
                    continue
                if isinstance(row.get("records"), list):
                    for record in row["records"]:
                        records.append(normalize_record({**row, **record}, str(file)))
                else:
                    try:
                        records.append(normalize_record(row, str(file)))
                    except ValueError as exc:
                        raise ValueError(f"{file}:{number}: {exc}") from exc
    return records


def config_key(config):
    return tuple(config[k] for k in CONDITION_KEYS)


def build_runs(records, k=5, include_incomplete=False):
    by_run = defaultdict(list)
    for row in records:
        by_run[(row["coordinator"], row["run_id"])].append(row)
    runs, exclusions = [], []
    for (coordinator, run_id), rows in sorted(by_run.items()):
        rows.sort(key=lambda r: r["round"])
        indexes = [r["round"] for r in rows]
        if indexes and indexes[0] not in (0, 1):
            raise ValueError(f"Run {run_id} does not begin at round zero or one")
        if len(indexes) != len(set(indexes)):
            raise ValueError(f"Duplicate round in {run_id}; do not combine rerun/resume logs twice")
        if indexes and indexes != list(range(indexes[0], indexes[0] + len(indexes))):
            raise ValueError(f"Non-contiguous rounds in {run_id}")
        configs = {config_key(r["config"]) for r in rows}
        if len(configs) != 1:
            raise ValueError(f"Config changed within {run_id}")
        config = rows[0]["config"]
        complete = len(rows) == int(config["rounds"])
        if not complete and not include_incomplete:
            exclusions.append(dict(run_id=run_id, coordinator=coordinator,
                                   reason="incomplete", observed_rounds=len(rows),
                                   expected_rounds=config["rounds"]))
            continue
        n = len(rows)
        width = max(1, n // 3)
        early, late = rows[:width], rows[-width:]
        result = dict(run_id=run_id, coordinator=coordinator, seed=rows[0]["seed"],
                      config=config, n_rounds=n, complete=complete, rows=rows,
                      violation_rate=mean(r["violation"] for r in rows),
                      expected_violation_rate=mean(float(config["pi"]) * (1-r["recall"]) for r in rows))
        for kind in TYPES:
            result[f"share_{kind}"] = mean(r["worker_type"] == kind for r in rows)
            result[f"early_share_{kind}"] = mean(r["worker_type"] == kind for r in early)
            result[f"late_share_{kind}"] = mean(r["worker_type"] == kind for r in late)
            result[f"share_change_{kind}"] = result[f"late_share_{kind}"] - result[f"early_share_{kind}"]
        for metric, getter in (("violation", lambda r: r["violation"]),
                               ("expected_violation", lambda r: float(config["pi"]) * (1-r["recall"]))):
            result[f"early_{metric}_rate"] = mean(getter(r) for r in early)
            result[f"late_{metric}_rate"] = mean(getter(r) for r in late)
            result[f"{metric}_change"] = result[f"late_{metric}_rate"] - result[f"early_{metric}_rate"]
        cells = {f"{kind}:{theta}": [0.0, 0] for kind in TYPES for theta in ("O", "P")}
        for index, row in enumerate(rows[:-k] if k > 0 else []):
            future = rows[index+1:index+k+1]
            y = sum(r["worker_label"] == row["worker_label"] for r in future) / k
            cell = cells[f"{row['worker_type']}:{row['theta']}"]
            cell[0] += y
            cell[1] += 1
        result["event_cells"] = cells
        result["did_next_k"] = event_contrast([result])
        result["late_careful_minus_complier"] = result["late_share_careful"] - result["late_share_complier"]
        runs.append(result)
    return runs, exclusions


def event_contrast(runs, target="careful", reference="complier"):
    values = []
    for kind, theta in ((target, "O"), (target, "P"), (reference, "O"), (reference, "P")):
        total = sum(run["event_cells"][f"{kind}:{theta}"][0] for run in runs)
        count = sum(run["event_cells"][f"{kind}:{theta}"][1] for run in runs)
        if not count:
            return None
        values.append(total / count)
    return values[0] - values[1] - values[2] + values[3]


def bootstrap(runs, estimator, draws=2000, seed=1729):
    estimate = estimator(runs)
    if estimate is None:
        return dict(estimate=None, ci_low=None, ci_high=None, n_runs=len(runs),
                    valid_bootstraps=0, requested_bootstraps=draws, status="missing_contrast_cells")
    if len(runs) < 2:
        return dict(estimate=estimate, ci_low=None, ci_high=None, n_runs=len(runs),
                    valid_bootstraps=0, requested_bootstraps=draws, status="insufficient_independent_runs")
    rng = random.Random(seed)
    values = []
    for _ in range(draws):
        sample = [runs[rng.randrange(len(runs))] for _ in runs]
        value = estimator(sample)
        if value is not None:
            values.append(value)
    fraction = len(values) / draws if draws else 0
    return dict(estimate=estimate, ci_low=quantile(values, .025), ci_high=quantile(values, .975),
                n_runs=len(runs), valid_bootstraps=len(values), requested_bootstraps=draws,
                status="ok" if fraction >= .95 else "sparse_contrast_bootstrap")


def summarize(runs, draws=2000, seed=1729):
    grouped = defaultdict(list)
    for run in runs:
        grouped[(run["coordinator"], config_key(run["config"]))].append(run)
    output = []
    metric_names = ["violation_rate", "expected_violation_rate", "violation_change",
                    "expected_violation_change", "late_careful_minus_complier"]
    metric_names += [prefix + kind for kind in TYPES for prefix in
                     ("share_", "early_share_", "late_share_", "share_change_")]
    for index, ((coordinator, condition), group) in enumerate(sorted(grouped.items())):
        config = dict(zip(CONDITION_KEYS, condition))
        metrics = {}
        for metric in metric_names:
            metrics[metric] = bootstrap(group, lambda sample, m=metric: mean(r[m] for r in sample),
                                        draws, seed + index)
        metrics["did_next_k_pooled_events"] = bootstrap(group, event_contrast, draws, seed + index)
        complete_contrast = [r for r in group if r["did_next_k"] is not None]
        metrics["did_next_k_complete_runs"] = bootstrap(
            complete_contrast, lambda sample: mean(r["did_next_k"] for r in sample) if sample else None,
            draws, seed + index)
        counts = {cell: sum(r["event_cells"][cell][1] for r in group)
                  for cell in group[0]["event_cells"]}
        output.append(dict(coordinator=coordinator, config=config, n_runs=len(group),
                           independent_unit="run", event_cell_counts=counts, metrics=metrics))
    return output


def paired_comparisons(runs, draws=2000, seed=1729):
    """Pair whole environment seeds; each seed must have one run per policy/cell."""
    baselines = {"uniform", "oracle", "bayesian", "random", "thompson"}
    grouped = defaultdict(dict)
    for run in runs:
        group = grouped[(run["coordinator"], config_key(run["config"]))]
        if run["seed"] is None:
            continue
        if run["seed"] in group:
            raise ValueError("Multiple runs per condition/coordinator/seed; unique paired seeds required")
        group[run["seed"]] = run
    results = []
    for (model, condition), group in sorted(grouped.items()):
        if model in baselines:
            continue
        for baseline in sorted(baselines):
            comparator = grouped.get((baseline, condition), {})
            common = sorted(set(group) & set(comparator), key=str)
            if not common:
                continue
            pairs = [(group[s], comparator[s]) for s in common]
            metrics = {}
            for metric in ("share_change_careful", "late_careful_minus_complier", "violation_rate",
                           "expected_violation_rate", "expected_violation_change"):
                metrics[metric] = bootstrap(pairs, lambda sample, m=metric: mean(a[m]-b[m] for a,b in sample), draws, seed)
            def did_difference(sample):
                a = event_contrast([pair[0] for pair in sample])
                b = event_contrast([pair[1] for pair in sample])
                return a-b if a is not None and b is not None else None
            metrics["did_next_k_pooled_events"] = bootstrap(pairs, did_difference, draws, seed)
            results.append(dict(coordinator=model, baseline=baseline, config=dict(zip(CONDITION_KEYS, condition)),
                                n_paired_seeds=len(common), metrics=metrics))
    return results


def dump_csv(path, rows):
    if not rows:
        path.write_text("")
        return
    keys = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, keys)
        writer.writeheader()
        writer.writerows(rows)


def format_interval(result, percent=True, difference=False):
    if result["estimate"] is None:
        return "not estimable"
    scale = 100 if percent else 1
    suffix = " pp" if difference else ("%" if percent else "")
    point = f"{result['estimate']*scale:.1f}{suffix}"
    if result["ci_low"] is None:
        return point + " (CI unavailable)"
    return point + f" [{result['ci_low']*scale:.1f}, {result['ci_high']*scale:.1f}]"


def write_svg(path, summaries):
    """Exact static audit-risk plot, one panel per feedback/friction/prevalence."""
    panels = defaultdict(list)
    for row in summaries:
        c = row["config"]
        panels[(c["feedback"], c["friction"], c["pi"])].append(row)
    if not panels:
        return
    names = sorted({r["coordinator"] for r in summaries})
    palette = ("#0072B2", "#D55E00", "#009E73", "#CC79A7", "#E69F00", "#56B4E9", "#444444")
    colors = {name: palette[i % len(palette)] for i,name in enumerate(names)}
    width, panel_height = 900, 300
    cols = 2
    height = 90 + math.ceil(len(panels) / cols) * panel_height + len(names) * 20
    elements = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
                '<rect width="100%" height="100%" fill="white"/>',
                '<g font-family="Arial, sans-serif" font-size="12" fill="#222">',
                '<text x="30" y="30" font-size="20">Expected violation risk by audit probability</text>',
                '<text x="30" y="51">Mean across independent runs; bars show 95% run-bootstrap intervals.</text>',
                '<text x="30" y="70">Expected risk is computed from fixed policies and observed assignment shares.</text>']
    for idx, ((feedback, friction, pi), group) in enumerate(sorted(panels.items())):
        left = 60 + (idx % cols) * 445
        top = 120 + (idx // cols) * panel_height
        chart_width, chart_height = 340, 190
        ymax = max(.05, float(pi))
        elements.append(f'<text x="{left}" y="{top-15}" font-weight="bold">{html.escape(str(feedback))}; c={friction}; π={pi}</text>')
        for tick in (0, .25, .5, .75, 1):
            y = top + chart_height * (1-tick)
            elements.append(f'<line x1="{left}" x2="{left+chart_width}" y1="{y}" y2="{y}" stroke="#e5e5e5"/>')
            elements.append(f'<text x="{left-8}" y="{y+4}" text-anchor="end">{100*ymax*tick:.0f}%</text>')
        for audit in (0, .25, .5, 1):
            x = left + audit*chart_width
            elements.append(f'<text x="{x}" y="{top+chart_height+20}" text-anchor="middle">{audit:g}</text>')
        elements.append(f'<text x="{left+chart_width/2}" y="{top+chart_height+40}" text-anchor="middle">Audit probability ρ</text>')
        model_groups = defaultdict(list)
        for row in group:
            model_groups[row["coordinator"]].append(row)
        for name, values in sorted(model_groups.items()):
            values.sort(key=lambda r:r["config"]["rho"])
            points = []
            for row in values:
                result = row["metrics"]["expected_violation_rate"]
                x = left + float(row["config"]["rho"])*chart_width
                y = top + chart_height * (1-result["estimate"]/ymax)
                points.append(f"{x},{y}")
                if result["ci_low"] is not None:
                    low = top+chart_height*(1-result["ci_low"]/ymax)
                    high = top+chart_height*(1-result["ci_high"]/ymax)
                    elements.append(f'<path d="M{x},{low}V{high} M{x-3},{low}H{x+3} M{x-3},{high}H{x+3}" stroke="{colors[name]}" fill="none"/>')
                elements.append(f'<circle cx="{x}" cy="{y}" r="3" fill="{colors[name]}"/>')
            elements.append(f'<polyline points="{" ".join(points)}" fill="none" stroke="{colors[name]}" stroke-width="1.5"/>')
    legend_y = 105 + math.ceil(len(panels)/cols)*panel_height
    for idx,name in enumerate(names):
        y = legend_y+idx*20
        elements.append(f'<line x1="30" x2="55" y1="{y}" y2="{y}" stroke="{colors[name]}" stroke-width="3"/>')
        elements.append(f'<text x="65" y="{y+4}">{html.escape(name)}</text>')
    elements.extend(["</g>", "</svg>"])
    path.write_text("\n".join(elements))


def write_report(path, report):
    lines = ["# Selection against safety: computed results", "",
             "This report is generated from completed run logs. It makes no claim that synthetic baselines are LLM observations.", "",
             f"Completed run records: **{report['n_runs']}**. Excluded incomplete runs with logged outcomes: **{len(report['excluded_runs'])}**. "
             f"Next-assignment horizon: **{report['next_k']}**. Bootstrap resamples: **{report['bootstrap_draws']}**.", "",
             "Intervals are percentile 95% run-cluster bootstrap intervals within condition, unadjusted for multiple comparisons. "
             "Different coordinators and conditions can share environment seeds, so the overall run count is not a count of mutually independent observations. "
             "These intervals describe this exploratory sample; they are not confirmatory hypothesis tests. "
             "Runs that failed before logging any outcome are absent here; inspect execution_summary.json and status files for all API failures.", "",
             "| Coordinator | ρ | c | π | Feedback | Runs | Careful late − early (pp) | Expected violations | Realized violations | Task-type interaction (pp) |",
             "|---|---:|---:|---:|---|---:|---:|---:|---:|---:|"]
    for row in report["summaries"]:
        c, m = row["config"], row["metrics"]
        lines.append(f"| {row['coordinator']} | {c['rho']} | {c['friction']} | {c['pi']} | {c['feedback']} | {row['n_runs']} | "
                     f"{format_interval(m['share_change_careful'], difference=True)} | {format_interval(m['expected_violation_rate'])} | "
                     f"{format_interval(m['violation_rate'])} | {format_interval(m['did_next_k_pooled_events'], difference=True)} |")
    lines += ["", "The task-type interaction is (future share after O − future share after P) for careful workers, minus the same contrast for compliers. "
              "It uses pooled events and resamples whole runs. It is not a pure causal effect of objection: task type also changes completion, audits, scores, and reasons. "
              "Differences and intervals in the two share-change columns are percentage points; risk columns are percentages.", "",
              "The CSV and JSON outputs include all event-cell counts, sparse-bootstrap warnings, per-run contrasts, and paired baseline comparisons. "
              "Missing cells remain null. Per-run complete-case contrasts use a selected subset and are diagnostic only.", "",
              "Expected violation risk equals π times the assignment-weighted probability of proceeding on an objection-required task. "
              "Realized violations fluctuate around that expectation; an exact equality in finite samples is not required.", "",
              "See METHODS.md for the observation model, estimands, and interpretation limits. No null result here establishes equivalence or absence of a meaningful effect.", ""]
    path.write_text("\n".join(lines))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", action="append", required=True, help="Outcome JSONL file or directory (repeatable)")
    parser.add_argument("--output", required=True)
    parser.add_argument("--bootstrap", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=1729)
    parser.add_argument("--next-k", type=int, default=5)
    parser.add_argument("--include-incomplete", action="store_true", help="Exploratory only: include truncated runs")
    args = parser.parse_args()
    if args.next_k <= 0 or args.bootstrap < 1:
        parser.error("--next-k and --bootstrap must be positive")
    records = load_records(args.input)
    runs, excluded = build_runs(records, args.next_k, args.include_incomplete)
    summaries = summarize(runs, args.bootstrap, args.seed)
    pairs = paired_comparisons(runs, args.bootstrap, args.seed)
    report = dict(n_runs=len(runs), n_records=sum(r["n_rounds"] for r in runs),
                  next_k=args.next_k, bootstrap_draws=args.bootstrap, bootstrap_seed=args.seed,
                  include_incomplete=args.include_incomplete, excluded_runs=excluded,
                  summaries=summaries, paired_comparisons=pairs,
                  analysis_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    (output/"analysis.json").write_text(json.dumps(report, indent=2, allow_nan=False)+"\n")
    run_rows = [{**{k:v for k,v in r.items() if k not in ("rows", "config", "event_cells")},
                 **{k:r["config"][k] for k in CONDITION_KEYS},
                 **{f"event_count_{k}":v[1] for k,v in r["event_cells"].items()}}
                for r in runs]
    dump_csv(output/"run_metrics.csv", run_rows)
    metric_rows = []
    for row in summaries:
        for metric, values in row["metrics"].items():
            metric_rows.append(dict(coordinator=row["coordinator"], **row["config"], metric=metric, **values))
    dump_csv(output/"condition_metrics.csv", metric_rows)
    paired_rows = []
    for row in pairs:
        for metric, values in row["metrics"].items():
            paired_rows.append(dict(coordinator=row["coordinator"], baseline=row["baseline"], **row["config"], metric=metric, **values))
    dump_csv(output/"paired_baseline_comparisons.csv", paired_rows)
    trajectory_rows = []
    trajectory_groups = defaultdict(list)
    for run in runs:
        for row in run["rows"]:
            trajectory_groups[(run["coordinator"], config_key(run["config"]), row["round"])].append(row)
    for (name, condition, round_index), rows in sorted(trajectory_groups.items()):
        trajectory_rows.append(dict(coordinator=name, **dict(zip(CONDITION_KEYS, condition)),
                                    round=round_index, n_runs=len(rows),
                                    **{f"share_{kind}":mean(r["worker_type"]==kind for r in rows) for kind in TYPES},
                                    realized_violation_rate=mean(r["violation"] for r in rows)))
    dump_csv(output/"trajectories.csv", trajectory_rows)
    write_svg(output/"audit_risk.svg", summaries)
    write_report(output/"RESULTS.md", report)
    print(json.dumps(dict(output=str(output.resolve()), n_runs=len(runs), excluded_incomplete=len(excluded),
                          n_conditions=len(summaries), n_paired_comparisons=len(pairs))))


if __name__ == "__main__":
    main()
