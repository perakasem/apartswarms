"""Network-free tests for transport, isolation, budget caps and secret handling."""

import concurrent.futures
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import urllib.error

try:
    from .adaption_client import AdaptionClient, AdaptionAPIError, BudgetExceeded, CredentialError, extract_output_text, _NoRedirect
except ImportError:
    from adaption_client import AdaptionClient, AdaptionAPIError, BudgetExceeded, CredentialError, extract_output_text, _NoRedirect


MODEL = "gemma-4-31b-it"
KEY = "pt_live_testsecret_123456"


class FakeTransport:
    def __init__(self, responses=None):
        self.responses = list(responses or [])
        self.requests = []

    def __call__(self, request, timeout):
        self.requests.append(request)
        if request.get_method() == "GET":
            return 200, {}, json.dumps({"data": [{"id": MODEL}]}).encode()
        if self.responses:
            outcome = self.responses.pop(0)
            if isinstance(outcome, Exception):
                raise outcome
            return outcome
        return 200, {}, json.dumps({"id": "response_test", "model": MODEL, "status": "completed", "output_text": "READY", "usage": {"input_tokens": 10, "output_tokens": 2, "total_tokens": 12}}).encode()


class ClientTests(unittest.TestCase):
    def client(self, transport=None, **kwargs):
        return AdaptionClient(api_key=KEY, transport=transport or FakeTransport(), sleep=lambda seconds: None, **kwargs)

    def test_isolated_payload_and_record(self):
        transport = FakeTransport()
        client = self.client(transport)
        record = client.create_response(model=MODEL, input="Hello")
        self.assertEqual(record["text"], "READY")
        body = record["request"]
        self.assertFalse(body["agentic_memory"])
        self.assertFalse(body["store"])
        self.assertFalse(body["stream"])
        self.assertEqual(body["tools"], [])
        self.assertEqual(body["tool_choice"], "none")
        self.assertNotIn("seed", body)
        self.assertNotIn(KEY, json.dumps(record))
        self.assertEqual(client.budget_snapshot()["requests"], 1)
        self.assertEqual(client.budget_snapshot()["input_tokens"], 10)
        self.assertGreater(record["estimated_credits"], client.budget_snapshot()["estimated_usage_credits"])
        self.assertEqual(transport.requests[1].full_url, "https://api.prod.adaptionlabs.ai/api/v1/responses")

    def test_output_fallback_excludes_reasoning_and_tools(self):
        result = {"output": [
            {"type": "reasoning", "content": [{"type": "output_text", "text": "private"}]},
            {"type": "function_call", "content": [{"type": "output_text", "text": "tool"}]},
            {"type": "message", "role": "assistant", "content": [{"type": "output_text", "text": "YES"}, {"type": "refusal", "refusal": "no"}]},
        ]}
        self.assertEqual(extract_output_text(result), "YES")

    def test_retries_and_secret_sanitization(self):
        sleeps = []
        transport = FakeTransport([
            (429, {"Retry-After": "300"}, json.dumps({"error": {"message": "echo " + KEY + " Bearer anothersecret"}}).encode()),
            urllib.error.URLError("connection failed for " + KEY),
        ])
        client = AdaptionClient(api_key=KEY, transport=transport, sleep=sleeps.append)
        record = client.preflight(MODEL)
        self.assertEqual(sleeps, [8.0, 2.0])
        self.assertEqual(len(record["attempts"]), 3)
        self.assertEqual(client.budget_snapshot()["requests"], 3)
        self.assertNotIn(KEY, json.dumps(record))
        self.assertNotIn("anothersecret", json.dumps(record))

    def test_auth_failure_not_retried(self):
        transport = FakeTransport([(401, {}, json.dumps({"error": {"message": KEY}}).encode())])
        client = self.client(transport)
        with self.assertRaises(AdaptionAPIError) as caught:
            client.preflight(MODEL)
        self.assertEqual(len(caught.exception.record["attempts"]), 1)
        self.assertNotIn(KEY, str(caught.exception))
        self.assertNotIn(KEY, json.dumps(caught.exception.record))

    def test_retry_limit(self):
        client = self.client(FakeTransport([(503, {}, b'{"error":"temporary"}')] * 3))
        with self.assertRaises(AdaptionAPIError) as caught:
            client.preflight(MODEL)
        self.assertEqual(len(caught.exception.record["attempts"]), 3)

    def test_threadsafe_request_budget(self):
        client = self.client(max_requests=5)
        def run(_):
            try:
                return client.preflight(MODEL)["text"]
            except BudgetExceeded:
                return "blocked"
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(run, range(20)))
        self.assertEqual(results.count("READY"), 5)
        self.assertEqual(client.budget_snapshot()["requests"], 5)

    def test_credit_limit_prevents_transport(self):
        transport = FakeTransport()
        client = self.client(transport, max_credits=0)
        with self.assertRaises(BudgetExceeded):
            client.preflight(MODEL)
        self.assertTrue(all(r.get_method() == "GET" for r in transport.requests))
        self.assertEqual(client.budget_snapshot()["requests"], 0)

    def test_resume_budget(self):
        client = self.client(max_requests=1, initial_budget={"requests": 1, "reserved_credits": 0.1})
        with self.assertRaises(BudgetExceeded):
            client.preflight(MODEL)

    def test_checkpoint_before_transport(self):
        snapshots = []
        fake = FakeTransport()
        def transport(request, timeout):
            if request.get_method() == "POST":
                self.assertEqual(snapshots[-1]["requests"], 1)
                self.assertGreater(snapshots[-1]["reserved_credits"], 0)
            return fake(request, timeout)
        client = self.client(transport, budget_checkpoint=snapshots.append)
        client.preflight(MODEL)
        self.assertEqual(len(snapshots), 2)
        self.assertEqual(snapshots[-1]["input_tokens"], 10)

    def test_usage_checkpoint_failure_preserves_response(self):
        snapshots = []
        def checkpoint(snapshot):
            snapshots.append(snapshot)
            if len(snapshots) == 2:
                raise OSError("cannot update usage")
        client = self.client(budget_checkpoint=checkpoint)
        record = client.preflight(MODEL)
        self.assertEqual(record["text"], "READY")
        self.assertIn("usage_checkpoint_error", record)
        self.assertEqual(client.budget_snapshot()["requests"], 1)

    def test_checkpoint_failure_stops_send(self):
        transport = FakeTransport()
        def checkpoint(snapshot):
            raise OSError("cannot persist")
        client = self.client(transport, budget_checkpoint=checkpoint)
        with self.assertRaises(AdaptionAPIError):
            client.preflight(MODEL)
        self.assertTrue(all(r.get_method() == "GET" for r in transport.requests))

    def test_model_must_be_granted_and_priced(self):
        client = self.client()
        with self.assertRaises(AdaptionAPIError):
            client.preflight("qwen3.5-397b")
        with self.assertRaises(AdaptionAPIError):
            client.preflight("invented-model")
        self.assertEqual(client.budget_snapshot()["requests"], 0)

    def test_secret_file_permissions(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "key"
            path.write_text(KEY + "\n")
            path.chmod(0o600)
            with patch.dict(os.environ, {}, clear=True):
                client = AdaptionClient(secret_file=path, transport=FakeTransport())
                self.assertEqual(client.preflight(MODEL)["text"], "READY")
                path.chmod(0o644)
                with self.assertRaises(CredentialError):
                    AdaptionClient(secret_file=path)

    def test_malformed_success_is_failure(self):
        client = self.client(FakeTransport([(200, {}, b"not JSON " + KEY.encode())]))
        with self.assertRaises(AdaptionAPIError) as caught:
            client.preflight(MODEL)
        self.assertNotIn(KEY, json.dumps(caught.exception.record))

    def test_redirects_are_not_followed(self):
        self.assertIsNone(_NoRedirect().redirect_request(None, None, 302, "redirect", {}, "https://elsewhere.example"))
        client = self.client()
        with self.assertRaises(AdaptionAPIError):
            client._call("/responses@elsewhere.example")


if __name__ == "__main__":
    unittest.main()
