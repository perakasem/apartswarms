import unittest

from analysis import (bootstrap, build_runs, event_contrast, normalize_record,
                      paired_comparisons)


class AnalysisTests(unittest.TestCase):
    def record(self, index, kind="careful", label="w1", theta="P", run_id="r1", seed=1):
        return normalize_record(dict(config=dict(rounds=12, pi=.35, seed=seed),
                                     run_id=run_id, coordinator="model_a", round=index,
                                     worker_type=kind, worker_label=label,
                                     theta=theta, violation=False))

    def test_last_k_events_are_excluded(self):
        records = [self.record(i) for i in range(12)]
        runs, _ = build_runs(records, k=5)
        self.assertEqual(runs[0]["event_cells"]["careful:P"], [7.0, 7])
        self.assertIsNone(runs[0]["did_next_k"])

    def test_horizon_tracks_worker_not_type(self):
        records = [self.record(i, label="w1" if i%2 == 0 else "w2") for i in range(12)]
        runs, _ = build_runs(records, k=5)
        self.assertAlmostEqual(runs[0]["event_cells"]["careful:P"][0], 7*.4)

    def test_missing_contrast_is_not_zero(self):
        runs, _ = build_runs([self.record(i) for i in range(12)])
        result = bootstrap(runs, event_contrast, draws=30)
        self.assertIsNone(result["estimate"])
        self.assertEqual(result["status"], "missing_contrast_cells")

    def test_incomplete_run_excluded(self):
        runs, excluded = build_runs([self.record(i) for i in range(11)])
        self.assertEqual(runs, [])
        self.assertEqual(excluded[0]["reason"], "incomplete")

    def test_duplicate_round_fails(self):
        with self.assertRaises(ValueError):
            build_runs([self.record(0), self.record(0)])

    def test_expected_risk_identity(self):
        records = [self.record(i, "careful" if i < 6 else "complier") for i in range(12)]
        runs, _ = build_runs(records)
        self.assertAlmostEqual(runs[0]["expected_violation_rate"], .35*.5)
        self.assertAlmostEqual(runs[0]["expected_violation_change"], .35*(.9-.1))
        self.assertEqual(runs[0]["violation_rate"], 0)

    def test_single_run_has_no_interval(self):
        result = bootstrap([dict(x=3)], lambda sample: sample[0]["x"], draws=30)
        self.assertEqual(result["estimate"], 3)
        self.assertIsNone(result["ci_low"])

    def test_paired_bootstrap_keeps_seed_pairs(self):
        records = []
        for seed in (1, 2, 3):
            for policy in ("model_a", "uniform"):
                for i in range(12):
                    row = self.record(i, "careful" if seed == 1 else "complier",
                                      run_id=f"{policy}:{seed}", seed=seed)
                    row["coordinator"] = policy
                    records.append(row)
        runs, _ = build_runs(records)
        paired = paired_comparisons(runs, draws=30)
        result = paired[0]["metrics"]["expected_violation_rate"]
        self.assertEqual(paired[0]["n_paired_seeds"], 3)
        self.assertEqual((result["estimate"], result["ci_low"], result["ci_high"]), (0, 0, 0))


if __name__ == "__main__":
    unittest.main()
