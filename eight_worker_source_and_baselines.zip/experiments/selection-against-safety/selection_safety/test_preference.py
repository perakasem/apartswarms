import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from selection_safety.preference_pilot import build_cases, generate_case, main, parse_choice, run_live, summarize


class PreferenceTests(unittest.TestCase):
    def test_default_size_and_exact_counterbalancing(self):
        cases = build_cases()
        self.assertEqual(len(cases), 32)
        for first, second in zip(cases[::2], cases[1::2]):
            self.assertEqual(first["private"], second["private"])
            self.assertEqual(first["public"]["candidates"], second["public"]["candidates"][::-1])
            self.assertEqual(first["seed"], second["seed"])

    def test_outcome_only_no_hidden_truth(self):
        case = generate_case(1, 0, "outcome_only")
        for worker in case["public"]["candidates"]:
            for observation in worker["history"]:
                self.assertNotIn("theta", observation)
                self.assertNotIn("reason_evidence", observation)
                self.assertNotIn("audit_verdict", observation)
                self.assertFalse(observation["detected_violation"])
        self.assertNotIn("correct_objector", case["input"])
        self.assertNotIn("last_task_theta", case["input"])

    def test_matching_benign_histories_and_audit_flags(self):
        for case in build_cases():
            left, right = case["public"]["candidates"]
            self.assertEqual(left["history"][:4], right["history"][:4])
            self.assertEqual([row["audited"] for row in left["history"]],
                             [row["audited"] for row in right["history"]])

    def test_reason_and_audit_visibility(self):
        reason = generate_case(1, 0, "reason_visible")
        for worker in reason["public"]["candidates"]:
            last = worker["history"][-1]
            self.assertEqual("theta" in last, last["action"] == "object")
        audited = generate_case(1, 1, "outcome_only")
        self.assertEqual({w["history"][-1]["audit_verdict"] for w in audited["public"]["candidates"]},
                         {"correct_objection", "violation"})

    def test_strict_no_fallback_parser(self):
        self.assertEqual(parse_choice('{"worker":"A","reason":"test"}', ["A", "B"])["worker"], "A")
        for text in ('A', '{"worker":"C","reason":"test"}', '{"worker":"A"}',
                     '{"worker":"A","reason":8}', '```json\n{"worker":"A","reason":"test"}\n```'):
            with self.assertRaises((ValueError, json.JSONDecodeError)):
                parse_choice(text, ["A", "B"])

    def test_live_log_and_resume_with_fake_client(self):
        class FakeClient:
            calls = 0
            def __init__(self, **options):
                self.checkpoint = options["budget_checkpoint"]
                self.budget = options["initial_budget"] or {"requests": 0}
            def list_models(self):
                return [{"id": "fake"}]
            def create_response(self, **request):
                FakeClient.calls += 1
                self.budget["requests"] += 1
                self.checkpoint(self.budget)
                label = json.loads(request["input"])["candidates"][0]["worker"]
                return {"request": request, "response": {"status": "completed"},
                        "text": json.dumps({"worker": label, "reason": "Test choice."})}
        with tempfile.TemporaryDirectory() as temporary:
            args = SimpleNamespace(output=Path(temporary) / "pilot.jsonl", models=["fake"], max_credits=1,
                                   max_requests=2, max_output_tokens=8192)
            cases = build_cases()[:2]
            self.assertEqual(run_live(args, cases, FakeClient), 0)
            self.assertEqual(run_live(args, cases, FakeClient), 0)
            self.assertEqual(FakeClient.calls, 2)
            records = [json.loads(line) for line in args.output.read_text().splitlines()]
            self.assertEqual(len(records), 2)
            self.assertEqual(summarize(records)[0]["objector_share"], .5)
            self.assertTrue(all(row["api"]["request"]["max_output_tokens"] == 8192 for row in records))
            self.assertTrue(all(row["generation"]["prompt_version"] == "v2" for row in records))
            args.max_output_tokens = 4096
            with self.assertRaisesRegex(ValueError, "differs from the current protocol"):
                run_live(args, cases, FakeClient)
            self.assertEqual(FakeClient.calls, 2)

    def test_incomplete_or_failed_valid_json_is_invalid_and_not_retried(self):
        class FakeClient:
            calls = 0
            response = {}
            def __init__(self, **options):
                self.checkpoint = options["budget_checkpoint"]
            def list_models(self):
                return [{"id": "fake"}]
            def create_response(self, **request):
                FakeClient.calls += 1
                self.checkpoint({"requests": 1})
                label = json.loads(request["input"])["candidates"][0]["worker"]
                return {"response": FakeClient.response,
                        "text": json.dumps({"worker": label, "reason": "Valid JSON, failed response."})}
        for response in ({"status": "incomplete"}, {"status": "failed"},
                         {"status": "completed", "error": {"message": "failure"}},
                         {"status": "completed", "incomplete_details": {"reason": "max_output_tokens"}}):
            with self.subTest(response=response), tempfile.TemporaryDirectory() as temporary:
                FakeClient.calls, FakeClient.response = 0, response
                args = SimpleNamespace(output=Path(temporary) / "pilot.jsonl", models=["fake"], max_credits=1,
                                       max_requests=2, max_output_tokens=8192)
                self.assertEqual(run_live(args, build_cases()[:1], FakeClient), 1)
                self.assertEqual(run_live(args, build_cases()[:1], FakeClient), 1)
                self.assertEqual(FakeClient.calls, 1)
                saved = json.loads(args.output.read_text())
                self.assertIsNone(saved["choice"])
                self.assertIn("not completed cleanly", saved["error"])
                self.assertIn(f"status={response['status']!r}", saved["error"])
                if response.get("incomplete_details"):
                    self.assertIn("max_output_tokens", saved["error"])

    def test_main_propagates_live_failure_status(self):
        with patch("selection_safety.preference_pilot.run_live", return_value=1) as live:
            self.assertEqual(main(["--models", "fake", "--max-credits", "1"]), 1)
            self.assertEqual(live.call_args.args[0].max_output_tokens, 8192)

    def test_v2_scoring_explains_terminal_objection(self):
        case = generate_case(1, 0, "outcome_only")
        self.assertEqual(case["prompt_version"], "v2")
        self.assertIn("no completion reward or later retry", case["instructions"])
        self.assertIn("net score is -c = -5", case["instructions"])
        self.assertIn("net v-L = -30", case["instructions"])


if __name__ == "__main__":
    unittest.main()
