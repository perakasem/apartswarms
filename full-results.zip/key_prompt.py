"""Read a key in Terminal and keep it in a temporary local memory service."""
import argparse
import getpass
import json
import os
from pathlib import Path
import socket
import tempfile
import time
import warnings


def receive_key(receipt):
    """Return the key to a local caller. Never print or save it."""
    data = json.loads(Path(receipt).read_text())
    if data['uid'] != os.getuid() or time.time() > data['expires_at']:
        raise ValueError('The local key prompt has expired')
    with socket.socket(socket.AF_UNIX) as connection:
        connection.settimeout(5)
        connection.connect(data['socket'])
        connection.sendall(b'key\n')
        chunks = []
        while True:
            chunk = connection.recv(4096)
            if not chunk:
                break
            chunks.append(chunk)
    return json.loads(b''.join(chunks))['key']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--receipt', type=Path, required=True)
    args = parser.parse_args()
    os.umask(0o077)
    print('Enter the Adaption API key here. Do not send it in chat.')
    print('This prompt does not send an inference request.')
    with warnings.catch_warnings():
        warnings.simplefilter('error', getpass.GetPassWarning)
        key = getpass.getpass('Adaption API key (input is hidden): ')
    if not key or key != key.strip() or not key.isascii() or any(c.isspace() for c in key):
        raise SystemExit('The key format is not valid. No key was saved.')
    # macOS limits Unix socket paths to 104 bytes. Use a private temporary path.
    with tempfile.TemporaryDirectory(prefix='swarm-key-', dir='/tmp') as directory:
        address = str(Path(directory) / 'key.sock')
        with socket.socket(socket.AF_UNIX) as server:
            server.bind(address)
            os.chmod(address, 0o600)
            server.listen(1)
            server.settimeout(1)
            args.receipt.parent.mkdir(parents=True, exist_ok=True)
            expiry = time.time() + 7200
            args.receipt.write_text(json.dumps({'socket': address, 'uid': os.getuid(), 'expires_at': expiry}))
            os.chmod(args.receipt, 0o600)
            print('Key ready in memory. Keep this Terminal window open during the run.')
            print('The local key service expires after two hours. Press Control-C to close it.')
            try:
                while time.time() < expiry:
                    try:
                        connection, _ = server.accept()
                    except socket.timeout:
                        continue
                    with connection:
                        connection.settimeout(3)
                        if connection.recv(16) == b'key\n':
                            connection.sendall(json.dumps({'key': key}).encode())
            except KeyboardInterrupt:
                pass
            finally:
                args.receipt.unlink(missing_ok=True)
                key = None
    print('The local key service is closed.')


if __name__ == '__main__':
    main()
