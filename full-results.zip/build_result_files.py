"""Build tables and a figure after the fixed study and record audit are complete."""
import argparse
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import statistics


def read(path):
    return json.loads(path.read_text())


def build(root):
    root = Path(root).resolve()
    status, audit, analysis, rows = [read(root/name) for name in
                                    ('status.json', 'audit.json', 'analysis.json', 'results.json')]
    if (status.get('status') != 'complete' or status.get('mode') != 'live'
            or audit.get('passed') is not True or audit.get('issues') != []):
        raise ValueError('A complete live study and passed audit are required')
    model_order = ['qwen3.5-397b', 'glm-5.2']
    conditions = ['worker_objection', 'checker_objection']
    fields = ['focal_share', 'careful_share', 'risky_violation_rate', 'supported_task_success',
              'careful_share_late_minus_early']
    summary = []
    for model in model_order:
        for condition in conditions:
            group = [row for row in rows if row['model_id'] == model and row['condition'] == condition]
            if len(group) != 40 or any(not row['complete'] for row in group):
                raise ValueError('A model condition does not have 40 complete runs')
            summary.append({'model': model, 'condition': condition, 'runs': len(group),
                            **{name: statistics.fmean(row[name] for row in group if row[name] is not None)
                               if any(row[name] is not None for row in group) else None for name in fields},
                            **{name+'_evaluable_runs': sum(row[name] is not None for row in group)
                               for name in fields},
                            'invalid_assignments': sum(row['invalid_actions'] for row in group),
                            'known_violations': sum(row['known_violations'] for row in group)})
    with (root/'condition_means.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(summary[0])); writer.writeheader(); writer.writerows(summary)
    effects = []
    for model in model_order:
        result = analysis['models'][model]
        for name in fields:
            if name == 'focal_share':
                estimate = result['primary_focal_share_difference']
                p = result['primary_holm_adjusted_p']
                role = 'primary'
            else:
                estimate = result['secondary_paired_differences'][name]['estimate']
                p = None
                role = 'secondary'
            if name == 'focal_share' and (estimate['pairs'] != 40 or estimate['ci95'] is None):
                raise ValueError('A paired effect is incomplete')
            effects.append({'model': model, 'outcome': name, 'role': role, 'pairs': estimate['pairs'],
                            'effect_percentage_points': estimate['mean']*100 if estimate['mean'] is not None else None,
                            'ci95_low_percentage_points': estimate['ci95'][0]*100 if estimate['ci95'] else None,
                            'ci95_high_percentage_points': estimate['ci95'][1]*100 if estimate['ci95'] else None,
                            'degenerate_bootstrap': estimate['degenerate'],
                            'holm_adjusted_p': p})
    with (root/'paired_effects.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(effects[0])); writer.writeheader(); writer.writerows(effects)

    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False,
                         'svg.fonttype': 'none', 'font.family': 'DejaVu Sans'})
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.7), layout='constrained')
    names = ['focal_share', 'risky_violation_rate']
    labels = ['Focal worker: share of assignments', 'Team: violations on risky tasks']
    for ax, name, label in zip(axes, names, labels):
        for y, model, color in zip([1, 0], model_order, ['#276b95', '#9b5834']):
            item = next(item for item in effects if item['model'] == model and item['outcome'] == name)
            value, low, high = [item[key] for key in ('effect_percentage_points',
                                'ci95_low_percentage_points', 'ci95_high_percentage_points')]
            if value is None:
                ax.text(0, y, 'No estimate', va='center')
                continue
            ax.errorbar(value, y, xerr=[[max(0,value-low)], [max(0,high-value)]],
                        fmt='o', color=color, capsize=5, markersize=7)
        ax.axvline(0, color='#666666', linewidth=1, linestyle='--')
        ax.set_yticks([1, 0], model_order)
        ax.set_ylim(-.6, 1.6)
        ax.set_title(label, fontsize=12, loc='left')
        ax.set_xlabel('Difference (percentage points)')
        ax.grid(axis='x', alpha=.18)
    fig.suptitle('Worker-attributed objection minus checker-attributed objection', fontsize=13)
    fig.supxlabel('40 paired seeds per model. Bars show 95% paired bootstrap intervals.\nThe team outcome is secondary.', fontsize=10)
    fig.savefig(root/'paired_effects.svg', metadata={'Date': None})
    fig.savefig(root/'paired_effects.png', dpi=180)
    plt.close(fig)
    provenance = {'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  'inputs': {name: hashlib.sha256((root/name).read_bytes()).hexdigest()
                             for name in ('status.json','audit.json','analysis.json','results.json')},
                  'outputs': ['condition_means.csv', 'paired_effects.csv', 'paired_effects.svg', 'paired_effects.png'],
                  'matplotlib_version': matplotlib.__version__, 'paid_calls': 0}
    (root/'result_files_provenance.json').write_text(json.dumps(provenance, indent=2)+'\n')
    print(json.dumps({'built': provenance['outputs'], 'paid_calls': 0}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('result_root', type=Path)
    build(parser.parse_args().result_root)
