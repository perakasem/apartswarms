"""Read paced study records without model calls or changes to prior records.

Usage: python3 audit_paced.py RESULT_ROOT [--write-report]
By default, print the audit only. --write-report saves audit.json in a confirmed
paced-1.0 result folder. It never writes to the prior study folder.
"""
from __future__ import annotations

import argparse
from contextlib import closing
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import sqlite3

from paced_study.analysis import MODELS, aggregate, summarize_run
from paced_study.common import digest, read_json, read_log, write_json
from paced_study.environment import CONDITIONS, build_messages, failure_outcome, generate_episode, outcome

BASE = Path(__file__).resolve().parent
PRICES = {'qwen3.5-397b': ('0.55', '3.50'), 'glm-5.2': ('1.40', '4.40')}


def manifest():
    return [{'phase': phase, 'model_id': model, 'seed': seed, 'condition': condition,
             'run_id': f'{phase}_{model}_{seed}_{condition}'}
            for phase, seeds in [('pilot', (11, 12)), ('main', range(2001, 2041))]
            for seed in seeds for condition in (CONDITIONS if seed % 2 else CONDITIONS[::-1])
            for model in MODELS]


def probe_rows():
    return [{'phase': 'probe', 'model_id': model, 'seed': 10, 'condition': 'worker_objection',
             'run_id': f'probe_v1_3_{model}'} for model in MODELS]


def database(path):
    with closing(sqlite3.connect(Path(path).resolve().as_uri() + '?mode=ro', uri=True)) as db:
        db.row_factory = sqlite3.Row
        db.execute('BEGIN')
        metadata = dict(db.execute('SELECT key,value FROM metadata'))
        rows = [dict(row) for row in db.execute('SELECT * FROM attempts ORDER BY rowid')]
    return metadata, rows


def account(rows):
    charged = sum((Decimal(row['estimated_charge']) for row in rows if row['status'] == 'settled'), Decimal(0))
    pending = sum((Decimal(row['reserved']) for row in rows if row['status'] == 'pending'), Decimal(0))
    unknown = sum((Decimal(row['reserved']) for row in rows if row['status'] == 'unknown'), Decimal(0))
    return {'estimated_charged_credits': str(charged), 'pending_credits': str(pending),
            'unknown_credits': str(unknown), 'committed_credits': str(charged + pending + unknown),
            'attempts': len(rows)}


def strict_choice(text, episode):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('Duplicate JSON key')
            result[key] = value
        return result
    try:
        value = json.loads(text, object_pairs_hook=unique)
    except (TypeError, ValueError):
        return None
    if (not isinstance(value, dict) or set(value) != {'worker_id'}
            or not isinstance(value['worker_id'], str) or value['worker_id'] not in episode['worker_ids']):
        return None
    return value['worker_id']


def audit(root, *, write_report=False):
    root = Path(root).resolve()
    issues, counts = [], {'source_files': 0, 'runs': 0, 'complete_runs': 0, 'requests': 0,
                         'outcomes': 0, 'events': 0, 'current_attempts': 0, 'carried_attempts': 0}

    def require(condition, message):
        if not condition:
            issues.append(message)
        return bool(condition)

    def load(name, default=None, required=True):
        try:
            return read_json(root / name)
        except FileNotFoundError:
            if required:
                issues.append(f'Missing record: {name}.')
        except Exception as error:
            issues.append(f'Cannot read {name} ({type(error).__name__}).')
        return default

    def same_account(saved, expected, label):
        require(isinstance(saved, dict), f'The {label} account is missing.')
        if not isinstance(saved, dict):
            return
        for key, value in expected.items():
            if key == 'attempts':
                require(saved.get(key) == value, f'The {label} attempt count differs.')
            else:
                try:
                    require(Decimal(str(saved.get(key))) == Decimal(value), f'The {label} total differs: {key}.')
                except Exception:
                    require(False, f'The {label} total is invalid: {key}.')

    study, status = load('study.json', {}), load('status.json', {})
    mode = study.get('mode')
    if not require(study.get('protocol') == 'paced-1.0', 'The result folder is not a paced-1.0 study.'):
        report = {'passed': False, 'issues': issues, 'paid_calls': 0, 'research_result': False}
        return report
    require(mode in ('live', 'offline') and status.get('mode', mode) == mode, 'The study mode differs.')
    finished = status.get('status') != 'running' and (bool(status.get('finished_utc')) or
               status.get('status') in ('complete', 'probe_failed', 'pilot_failed', 'pilot_passed', 'incomplete'))
    require(status.get('status') != 'running', 'The study is still running. Audit it after it stops.')
    for name, expected in [('input_cap', 6000), ('output_cap', 512), ('temperature', .7),
                           ('limit_adaption_credits', 100), ('inference_concurrency', 4),
                           ('reasoning_request', {'effort': 'none'})]:
        require(study.get(name) == expected, f'The fixed study setting differs: {name}.')
    require(study.get('models') == list(MODELS), 'The fixed model list differs.')
    require(study.get('openrouter_calls') == 0 and study.get('openrouter_spend_cad') == 0,
            'The OpenRouter use record differs.')
    hashes = study.get('source_hashes', {})
    require(isinstance(hashes, dict) and bool(hashes), 'The source hash list is missing.')
    for name, expected in hashes.items():
        path = (root / 'source' / name).resolve()
        if require(path.is_relative_to(root / 'source') and path.is_file(), f'Missing or invalid source copy: {name}.'):
            require(hashlib.sha256(path.read_bytes()).hexdigest() == expected, f'The source copy differs: {name}.')
            counts['source_files'] += 1
    for name in ('paced_study/analysis.py', 'paced_study/environment.py', 'paced_study/common.py'):
        require(hashes.get(name) == hashlib.sha256((BASE / name).read_bytes()).hexdigest(),
                f'The active audit scorer differs from the saved source: {name}.')
    tokenizers = load('tokenizer_verification.json', {})
    require(tokenizers.get('task_seeds') == [10, 11, 12] + list(range(2001, 2041))
            and tokenizers.get('network_blocked') is True and tokenizers.get('paid_calls') == 0,
            'The paced native context check differs.')
    for key, model in [('qwen', 'qwen3.5-397b'), ('glm', 'glm-5.2')]:
        record = tokenizers.get('models', {}).get(key, {})
        require(record.get('counter') == study.get('token_counters', {}).get(model)
                and record.get('contexts_checked') == 6192 and record.get('maximum_count', 6001) <= 6000,
                f'The saved native context bound differs: {model}.')
    expected = manifest()
    require(load('manifest.json', []) == expected, 'The fixed main or pilot manifest differs.')
    rows_by_id = {row['run_id']: row for row in expected + probe_rows()}
    pilot, probes = load('pilot.json', required=False), load('probes.json', required=False)
    freeze = load('main_freeze.json', required=False)
    if freeze is not None:
        require(freeze.get('study_hash') == digest(study) and freeze.get('manifest_hash') == digest(expected),
                'The main freeze study or manifest hash differs.')
        require(isinstance(pilot, dict) and freeze.get('pilot_hash') == digest(pilot.get('results', [])),
                'The main freeze pilot hash differs.')
        require(isinstance(pilot, dict) and pilot.get('passed') is True
                and isinstance(probes, dict) and probes.get('passed') is True, 'The main freeze has no passed gates.')
    requests, terminals, results, intervals = {}, {}, {}, []
    for directory in sorted((root / 'runs').glob('*')):
        if not directory.is_dir():
            continue
        run_id = directory.name
        row = rows_by_id.get(run_id)
        counts['runs'] += 1
        if not require(row is not None, f'An unknown or old run is in the new result folder: {run_id}.'):
            continue
        if row['phase'] == 'main':
            require(freeze is not None, 'A main run has no fixed pre-main record.')
        try:
            episode, result = read_json(directory / 'episode.json'), read_json(directory / 'result.json')
            events = read_log(directory / 'events.jsonl')
            results[run_id] = result
            counts['events'] += len(events)
            require(episode == generate_episode(row['seed'], row['condition']), f'The task or worker rules differ: {run_id}.')
            require(all(result.get(k) == v for k, v in row.items()) and result.get('mode') == mode,
                    f'The saved run identity differs: {run_id}.')
            require(bool(events) and events[0].get('kind') == 'start'
                    and events[0].get('row') == row and events[0].get('episode_hash') == digest(episode),
                    f'The start identity differs: {run_id}.')
            require(bool(events) and result.get('log_hash') == events[-1]['hash'], f'The run log hash differs: {run_id}.')
            turns, history, tries, last_text = [], [], {}, {}
            for event in events[1:]:
                kind, attempt_id = event.get('kind'), event.get('attempt_id')
                if kind == 'request':
                    number = event.get('round_number')
                    attempt = tries.get(number, 0)
                    require(number == len(turns) + 1 and attempt < 2
                            and attempt_id == f'{run_id}|r{number}|attempt{attempt}'
                            and attempt_id not in requests, f'The request order or retry count differs: {run_id}.')
                    require(event.get('messages') == build_messages(episode, history, number),
                            f'The rendered request differs: {run_id}, round {number}.')
                    counted = event.get('counted_input_tokens')
                    require(type(counted) is int and 0 <= counted <= 6000
                            and event.get('counter') == study.get('token_counters', {}).get(row['model_id']),
                            f'The request token bound differs: {run_id}.')
                    requests[attempt_id] = {'model': row['model_id'], 'phase': row['phase'], 'retry': int(attempt > 0),
                                            'counted': counted, 'time': event.get('time'), 'round': number}
                    tries[number] = attempt + 1
                elif kind in ('response', 'transport_error'):
                    require(attempt_id in requests and attempt_id not in terminals, 'A terminal event has no unique request.')
                    terminals[attempt_id] = event
                    request = requests[attempt_id]
                    intervals.append((request['time'], event.get('time')))
                    if kind == 'response':
                        response = event.get('response', {})
                        usage = response.get('usage', {})
                        last_text[request['round']] = response.get('text')
                        require(response.get('model') == request['model'], 'A response model differs.')
                        require(type(usage.get('input_tokens')) is int and 0 <= usage['input_tokens'] <= request['counted']
                                and type(usage.get('output_tokens')) is int and 0 <= usage['output_tokens'] <= 512,
                                'A response exceeds a fixed token bound.')
                        require(usage.get('total_tokens') == usage.get('input_tokens', -1) + usage.get('output_tokens', -1),
                                'The response token total differs.')
                        if mode == 'live':
                            raw = response.get('raw', {})
                            zero = (usage.get('output_tokens_details') or {}).get('reasoning_tokens')
                            require((raw.get('reasoning') or {}).get('effort') == 'none' and type(zero) is int and zero == 0,
                                    'A response lacks the required reasoning control.')
                    else:
                        last_text[request['round']] = None
                elif kind == 'outcome':
                    number = event.get('round')
                    require(number == len(turns) + 1 and number in tries, 'An outcome has no sequential request.')
                    selected = strict_choice(last_text.get(number), episode)
                    require(event.get('worker_id') == selected and event.get('invalid') is (selected is None),
                            'The worker choice does not match the strict response parser.')
                    feedback = (outcome(episode, number, selected) if selected else
                                failure_outcome(episode, number, event.get('failure_reason')))
                    require(event.get('feedback') == feedback, 'The fixed task feedback differs.')
                    turns.append({key: event.get(key) for key in ('round', 'worker_id', 'outcome', 'invalid', 'failure_reason')})
                    history.append(feedback)
                elif kind != 'stopped':
                    require(False, 'The run has an unknown event kind.')
            scheduled = 4 if row['phase'] == 'probe' else 24
            require(result.get('scheduled_rounds') == scheduled and result.get('observed_turns') == len(turns)
                    and result.get('valid_turns') == sum(t['invalid'] is False for t in turns), 'The saved run counts differ.')
            if result.get('status') == 'complete':
                counts['complete_runs'] += 1
                require(len(turns) == scheduled, 'A complete run has missing turns.')
            score = summarize_run(episode, turns, 'incomplete' if scheduled == 4 else result['status'])
            for key, value in score.items():
                if scheduled == 4 and key in ('status', 'scheduled_rounds'):
                    continue
                require(key in result and type(result[key]) is type(value) and result[key] == value,
                        f'The score differs: {run_id}, {key}.')
            counts['outcomes'] += len(turns)
        except Exception as error:
            require(False, f'Cannot check run {run_id} ({type(error).__name__}).')
    counts['requests'] = len(requests)
    for gate, phase in [(probes, 'probe'), (pilot, 'pilot')]:
        if gate is None:
            continue
        group = gate.get('results', [])
        ids = [r.get('run_id') for r in group]
        require(len(ids) == len(set(ids)) and all(r == results.get(r.get('run_id')) for r in group),
                f'The {phase} gate contains changed or repeated results.')
        if phase == 'probe':
            passed = len(group) == 2 and all(r['status'] == 'complete' and r['valid_turns'] == 4 for r in group)
        else:
            passed = len(group) == 8
            for model in MODELS:
                subset = [r for r in group if r['model_id'] == model]
                passed &= len(subset) == 4 and all(r['status'] == 'complete' for r in subset) and sum(r['valid_turns'] for r in subset) >= 92
        require(gate.get('passed') is bool(passed), f'The saved {phase} gate differs.')
    main = load('results.json', required=False)
    analysis = load('analysis.json', required=False)
    if main is not None:
        require(isinstance(main, list) and len(main) == len({r.get('run_id') for r in main})
                and all(r.get('phase') == 'main' and r == results.get(r.get('run_id')) for r in main),
                'The main result list contains changed, repeated, or pooled old results.')
        if analysis is not None:
            try:
                require(analysis == aggregate(main), 'The complete paired analysis differs from the saved analysis.')
            except Exception as error:
                require(False, f'Cannot recompute the analysis ({type(error).__name__}).')
    if status.get('status') == 'complete':
        require(set(results) == set(rows_by_id) and counts['complete_runs'] == 170
                and isinstance(main, list) and len(main) == 160, 'The complete study has missing or extra runs.')
    try:
        metadata, entries = database(root / 'credits.sqlite')
        current = account(entries)
        counts['current_attempts'] = len(entries)
        require(metadata.get('mode') == mode and Decimal(metadata.get('limit_credits', '-1')) == 100
                and metadata.get('max_attempts') == '4240' and metadata.get('retry_limit') == '100'
                and json.loads(metadata.get('quotas', '{}')) == {'main': 1920, 'pilot': 96, 'probe': 4},
                'The paced ledger limits differ.')
        carry = json.loads(metadata.get('carry', 'null'))
        receipt = load('prior_study_receipt.json', required=mode == 'live')
        carried = {'estimated_charged_credits': '0', 'pending_credits': '0', 'unknown_credits': '0',
                   'committed_credits': '0', 'attempts': 0}
        if mode == 'live':
            require(carry == receipt and isinstance(receipt, dict), 'The prior carry receipt differs from the ledger.')
            require(study.get('prior_carry_hash') == digest(receipt)
                    and study.get('prior_main_batch_excluded') is True,
                    'The study does not fix the prior cost carry and batch exclusion.')
            prior_root = Path(receipt['root']).resolve()
            require(prior_root != root, 'The prior and current result folders must differ.')
            old_meta, old_rows = database(prior_root / 'credits.sqlite')
            old_study, old_status = read_json(prior_root / 'study.json'), read_json(prior_root / 'status.json')
            old_audit = read_json(prior_root / 'audit.json')
            saved_old_audit = load('prior_audit.json', {})
            require(saved_old_audit == old_audit and study.get('prior_audit_hash') == digest(old_audit),
                    'The saved prior audit or its study hash differs.')
            require(old_status.get('status') == 'incomplete' and old_meta.get('frozen_reason')
                    and old_audit.get('passed') is True, 'The prior study is not stopped, frozen, and audited.')
            for field, value in [('ledger_hash', digest({'metadata': old_meta, 'attempts': old_rows})),
                                 ('attempt_records_sha256', digest(old_rows)), ('study_hash', digest(old_study)),
                                 ('status_hash', digest(old_status)),
                                 ('study_file_sha256', hashlib.sha256((prior_root/'study.json').read_bytes()).hexdigest()),
                                 ('status_file_sha256', hashlib.sha256((prior_root/'status.json').read_bytes()).hexdigest())]:
                require(receipt.get(field) == value, f'The frozen prior record differs: {field}.')
            carried = account(old_rows)
            same_account(receipt, carried, 'carried')
            same_account(carried, {'estimated_charged_credits': '0.94606950', 'pending_credits': '0',
                                   'unknown_credits': '9.611280', 'committed_credits': '10.55734950',
                                   'attempts': 940}, 'fixed prior carry')
            old_main = read_json(prior_root / 'results.json')
            require(all(r.get('complete') is False for r in old_main), 'The excluded prior batch has a complete main run.')
            require(not {r['id'] for r in old_rows} & {r['id'] for r in entries}, 'An old attempt is pooled into the new ledger.')
        else:
            require(carry is None and receipt is None, 'An offline study must not have a live cost carry.')
        counts['carried_attempts'] = carried['attempts']
        global_account = {key: str(Decimal(current[key]) + Decimal(carried[key])) for key in current if key != 'attempts'}
        global_account['attempts'] = len(entries) + carried['attempts']
        require(Decimal(global_account['committed_credits']) <= 100 and len(entries) <= 4240,
                'The global budget or current attempt limit is exceeded.')
        by_id = {r['id']: r for r in entries}
        if finished:
            require(set(by_id) == set(requests), 'The finished request log and new ledger IDs differ.')
            require(all(r['status'] != 'pending' for r in entries), 'The finished study has pending reservations.')
        for attempt_id, request in requests.items():
            entry = by_id.get(attempt_id)
            if not require(entry is not None, 'A request has no credit reservation.'):
                continue
            require(all(entry.get(k) == request[k] for k in ('model', 'phase', 'retry')), 'A ledger attempt identity differs.')
            if mode == 'live':
                a, b = (Decimal(x) for x in PRICES[entry['model']])
                require(Decimal(entry['reserved']) == (6000*a+512*b)/1000000*Decimal('1.05'),
                        'A request lacks its full fixed reservation.')
            else:
                require(Decimal(entry['reserved']) == 0, 'An offline request has a paid reservation.')
            terminal = terminals.get(attempt_id)
            if finished:
                require(terminal is not None, 'A finished request has no terminal record.')
            if terminal is not None:
                usage = terminal['response']['usage'] if terminal['kind'] == 'response' else terminal.get('usage')
                if usage is not None:
                    require(entry['status'] == 'settled'
                            and json.loads(entry['usage']) == {k: usage[k] for k in ('input_tokens', 'output_tokens', 'total_tokens')},
                            'A known response has a different settled usage record.')
                    estimate = Decimal(0) if mode == 'offline' else (
                        Decimal(usage['input_tokens'])*Decimal(PRICES[entry['model']][0])
                        + Decimal(usage['output_tokens'])*Decimal(PRICES[entry['model']][1]))/1000000
                    require(Decimal(entry['estimated_charge']) == estimate, 'The token charge estimate differs.')
                else:
                    require(entry['status'] == 'unknown', 'An unknown charge lost its reservation.')
        snapshot = status.get('ledger', {})
        same_account(snapshot.get('current'), current, 'current snapshot')
        same_account(snapshot.get('carried'), carried, 'carried snapshot')
        same_account(snapshot, global_account, 'global snapshot')
        require(Decimal(snapshot.get('remaining_credits', '-1')) == 100-Decimal(global_account['committed_credits']),
                'The global remaining credit differs.')
    except Exception as error:
        require(False, f'Cannot check the credit carry or ledger ({type(error).__name__}).')
    try:
        pacing = read_log(root / 'pacing.jsonl')
        throttle = load('throttle.json', {})
        require(pacing and pacing[0]['kind'] == 'configured' and throttle.get('log_hash') == pacing[-1]['hash'],
                'The pacing log or final state hash differs.')
        require({k:v for k,v in throttle.items() if k != 'log_hash'} == pacing[-1].get('state'),
                'The pacing snapshot differs from its log.')
        previous_dispatch, cooldown_until, cycles = None, 0.0, 0
        dispatches = 0
        for event in pacing:
            state = event['state']
            now = state['elapsed_seconds']
            require(state['enabled'] is (mode == 'live'), 'The pacing mode differs.')
            require(state['rate_per_second'] in (4.0, 2.0, 1.0)
                    and state['rate_limit_cycles'] == state['generation']
                    and (state['rate_limit_cycles'] < 3 or state['stopped'] is True),
                    'The pacing rate, generation, or stop state differs.')
            if event['kind'] == 'dispatch':
                require(not state['stopped'] and now+0.01 >= cooldown_until, 'A request passed a stopped gate or active pause.')
                if previous_dispatch is not None:
                    require(now-previous_dispatch+0.01 >= 1/state['rate_per_second'], 'The dispatch spacing is too short.')
                previous_dispatch = now
                dispatches += 1
            elif event['kind'] in ('rate_limit', 'same_surge_rate_limit'):
                delay = event['cooldown_seconds']
                require(delay >= 60, 'A rate-limit pause is less than 60 seconds.')
                cooldown_until = max(cooldown_until, now+delay)
                if event['kind'] == 'rate_limit':
                    cycles += 1
                require(state['rate_limit_cycles'] == cycles and cycles <= 3
                        and state['rate_per_second'] == (2.0 if cycles == 1 else 1.0),
                        'The rate reduction differs from the fixed schedule.')
        if mode == 'live':
            require(dispatches >= len(requests), 'A request has no pacing gate record.')
            if status.get('status') == 'complete':
                require(dispatches == len(requests), 'A complete study has an unmatched pacing dispatch.')
            require(sum(e['kind'] in ('rate_limit', 'same_surge_rate_limit') for e in pacing)
                    == sum(e.get('http_status') == 429 for e in terminals.values()), 'The rate-limit event count differs.')
        active, peak = 0, 0
        for _, delta in sorted([(a,1) for a,b in intervals] + [(b,-1) for a,b in intervals]):
            active += delta
            peak = max(peak, active)
        require(peak <= 4, 'The recorded request concurrency exceeds four.')
        counts['pacing_dispatches'], counts['rate_limit_cycles'] = dispatches, cycles
        counts['peak_concurrent_requests'] = peak
    except Exception as error:
        require(False, f'Cannot check the pacing record ({type(error).__name__}).')
    report = {'passed': not issues, 'issues': issues, 'counts': counts, 'mode': mode,
              'study_status': status.get('status'), 'paid_calls': 0, 'research_result': False,
              'billing_verified': False, 'prior_records_written': False,
              'time_utc': datetime.now(timezone.utc).isoformat(),
              'audit_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'scope': 'This audit checks saved records, scores, cost carry, and recorded pacing. It is not a model result.'}
    if write_report:
        write_json(root / 'audit.json', report)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('result_root', type=Path)
    parser.add_argument('--write-report', action='store_true')
    args = parser.parse_args(argv)
    report = audit(args.result_root, write_report=args.write_report)
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
