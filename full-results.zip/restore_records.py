"""Restore the original archived records to a new folder. No network access."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('destination', type=Path, help='A new folder outside this repository')
    args = parser.parse_args()
    destination = args.destination.resolve()
    if destination.exists() or destination == BASE or BASE in destination.parents:
        raise ValueError('Use a new folder outside this repository')
    index = json.loads((BASE/'archives/INDEX.json').read_text())
    checked = []
    names = set()
    for group in index['archives']:
        packed = b''.join((BASE/part).read_bytes() for part in group['parts'])
        if hashlib.sha256(packed).hexdigest() != group['gzip_sha256']:
            raise ValueError('An archive hash differs')
        expected = {item['path']: item for item in group['members']}
        with tarfile.open(fileobj=io.BytesIO(gzip.decompress(packed)), mode='r:') as archive:
            members = archive.getmembers()
            if len(members) != len(expected) or {m.name for m in members} != set(expected):
                raise ValueError('An archive member list differs')
            for member in members:
                path = Path(member.name)
                if path.is_absolute() or '..' in path.parts or not member.isfile() or member.name in names:
                    raise ValueError('An archive member path is unsafe or repeated')
                names.add(member.name)
                data = archive.extractfile(member).read()
                if len(data) != expected[member.name]['bytes'] or hashlib.sha256(data).hexdigest() != expected[member.name]['sha256']:
                    raise ValueError('An original record hash differs')
                checked.append((path, data))
    destination.mkdir(parents=True, exist_ok=False)
    for path, data in checked:
        target = destination/path
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(data)
    print(json.dumps({'original_files_restored':len(checked),'destination':str(destination),'paid_calls':0}))


if __name__ == '__main__':
    main()
