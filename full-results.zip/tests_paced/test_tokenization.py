import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from paced_study.environment import build_messages, failure_outcome, generate_episode, outcome
from paced_study.tokenization import FRAMING_ALLOWANCE, NativeCounter, _flat_ids


ASSETS = Path(__file__).resolve().parents[1] / "tokenizers"
HAS_NATIVE = all(importlib.util.find_spec(name) is not None for name in ("transformers", "tokenizers", "jinja2"))


class NativeValidationTests(unittest.TestCase):
    def test_flat_ids_never_counts_dictionary_keys(self):
        self.assertEqual(_flat_ids({"input_ids": [5, 8, 13], "attention_mask": [1, 1, 1]}), [5, 8, 13])
        self.assertEqual(_flat_ids([5, 8, 13]), [5, 8, 13])
        for value in ([[5, 8]], {"input_ids": [[5, 8]]}, [True], [1.0], [-1], {"other": []}, None):
            with self.subTest(value=value), self.assertRaises(ValueError):
                _flat_ids(value)

    def manifest(self, root):
        path = Path(root)
        (path / 'tokenizer.json').write_text('{}')
        value = {"model_id": "qwen3.5-397b", "repo": "Qwen/Qwen3.5-397B-A17B",
                 "revision": "1" * 40,
                 "files": {"tokenizer.json": hashlib.sha256(b'{}').hexdigest()}}
        (path / 'manifest.json').write_text(json.dumps(value))
        return path, value

    def test_wrong_identity_and_revision_fail_before_loading(self):
        for change in ({"model_id": "wrong"}, {"repo": "wrong"}, {"revision": "main"}):
            with tempfile.TemporaryDirectory() as root:
                path, manifest = self.manifest(root)
                (path / 'manifest.json').write_text(json.dumps({**manifest, **change}))
                with self.assertRaises(ValueError): NativeCounter('qwen3.5-397b', path)

    def test_hash_change_and_unlisted_file_fail_before_loading(self):
        with tempfile.TemporaryDirectory() as root:
            path, _ = self.manifest(root)
            (path / 'tokenizer.json').write_text('changed')
            with self.assertRaises(ValueError): NativeCounter('qwen3.5-397b', path)
        with tempfile.TemporaryDirectory() as root:
            path, _ = self.manifest(root)
            (path / 'unlisted.json').write_text('{}')
            with self.assertRaises(ValueError): NativeCounter('qwen3.5-397b', path)

    def test_outside_symlink_is_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder) / 'inside'; root.mkdir()
            path, manifest = self.manifest(root)
            outside = Path(folder) / 'outside.json'; outside.write_text('{}')
            (path / 'tokenizer.json').unlink(); (path / 'tokenizer.json').symlink_to(outside)
            with self.assertRaises(ValueError): NativeCounter('qwen3.5-397b', path)


@unittest.skipUnless(HAS_NATIVE and ASSETS.exists(), "Use the native tokenizer environment")
class NativeIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with patch('socket.create_connection', side_effect=AssertionError('Network disabled')), \
                patch('socket.socket.connect', side_effect=AssertionError('Network disabled')):
            cls.counters = [NativeCounter('qwen3.5-397b', ASSETS / 'qwen'),
                            NativeCounter('glm-5.2', ASSETS / 'glm')]

    def test_count_is_maximum_of_both_native_modes_plus_allowance(self):
        episode = generate_episode(10, 'worker_objection')
        messages = build_messages(episode, [], 1)
        for counter in self.counters:
            with self.subTest(model=counter.model_id):
                counts = counter.count_modes(messages)
                self.assertGreater(min(counts.values()), 100)
                self.assertEqual(counter.count(messages), max(counts.values()) + FRAMING_ALLOWANCE)
                self.assertLessEqual(counter.count(messages), 6000)
                self.assertIn('transformers', counter.versions)
                self.assertTrue(counter.name.startswith('native_local:'))

    def test_native_render_roundtrip_in_both_modes_for_three_full_histories(self):
        episode = generate_episode(2001, 'worker_objection')
        shortcut_id = next(worker_id for worker_id in episode['worker_ids']
                           if episode['worker_policies'][worker_id] == 'shortcut')
        histories = {
            'careful': [outcome(episode, n, episode['focal_id']) for n in range(1, 24)],
            'shortcut': [outcome(episode, n, shortcut_id) for n in range(1, 24)],
            'invalid': [failure_outcome(episode, n, 'invalid_choice') for n in range(1, 24)],
        }
        for policy, history in histories.items():
            messages = build_messages(episode, history, 24)
            for counter in self.counters:
                for option in (None, False):
                    with self.subTest(model=counter.model_id, option=option, policy=policy):
                        ids = counter.token_ids(messages, enable_thinking=option)
                        rendered = counter.render(messages, enable_thinking=option)
                        self.assertEqual(counter.tokenizer.encode(rendered, add_special_tokens=False), ids)
                        self.assertLessEqual(len(ids) + FRAMING_ALLOWANCE, 6000)

    def test_unchecked_message_shapes_are_rejected(self):
        valid = build_messages(generate_episode(10, 'worker_objection'), [], 1)
        bad = [[], valid[:2], [dict(valid[0], name='worker')] + valid[1:],
               [valid[0], dict(valid[1], role='assistant'), valid[2]]]
        for counter in self.counters:
            for messages in bad:
                with self.assertRaises(ValueError): counter.count(messages)
            with self.assertRaises(ValueError): counter.token_ids(valid, enable_thinking=True)


if __name__ == '__main__':
    unittest.main()
