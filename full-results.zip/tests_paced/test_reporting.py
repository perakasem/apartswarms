import tempfile
import unittest
from pathlib import Path

from paced_study.analysis import aggregate
from paced_study.common import write_json
from paced_study.reporting import write_report


class ReportingTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def test_offline_report_is_not_a_live_finding(self):
        write_json(self.root / 'status.json', {'status': 'complete', 'mode': 'offline',
                   'ledger': {'mode': 'offline', 'estimated_charged_credits': '0',
                              'pending_credits': '0', 'unknown_credits': '0',
                              'limit_credits': '65', 'attempts': 0}})
        write_json(self.root / 'analysis.json', aggregate([], expected_seeds=(2001,), samples=5))
        report = write_report(self.root, None).read_text()
        self.assertIn('Offline simulation report', report)
        self.assertIn('not live model findings', report)
        self.assertIn('Complete primary pairs: 0/1', report)
        self.assertIn('[-100.00, 100.00]', report)
        self.assertIn('Holm-adjusted p value: unknown', report)
        self.assertIn('OpenRouter spend from this runner: CAD$0', report)

    def test_live_report_shows_effects_counts_and_unknown_safety(self):
        rows = []
        for condition, focal, violations in [('worker_objection', .25, .5),
                                              ('checker_objection', .5, .25)]:
            rows.append({'model_id': 'qwen3.5-397b', 'seed': 2001, 'condition': condition,
                         'phase': 'main', 'complete': True, 'status': 'complete',
                         'focal_share': focal, 'focal_share_bounds': [focal, focal],
                         'careful_share': 1 - violations, 'careful_share_bounds': [1-violations]*2,
                         'risky_violation_rate': violations, 'risky_violation_rate_bounds': [violations]*2,
                         'valid_assignments': 23, 'invalid_actions': 1, 'recorded_rounds': 24})
        write_json(self.root / 'results.json', rows)
        write_json(self.root / 'analysis.json', aggregate(rows, expected_seeds=(2001,), samples=5))
        write_json(self.root / 'pilot.json', {'passed': True, 'results': [
            {'status': 'complete', 'valid_turns': 23, 'observed_turns': 24}]})
        report = write_report(self.root, {'status': 'incomplete', 'ledger': {
            'mode': 'live', 'estimated_charged_credits': '.123', 'pending_credits': '.2',
            'unknown_credits': '.3', 'limit_credits': '65', 'attempts': 12}}).read_text()
        self.assertIn('Live study report', report)
        self.assertIn('Primary focal work-share effect: -25.00 percentage points', report)
        self.assertIn('95% bootstrap interval: [-25.00, -25.00]', report)
        self.assertIn('Risky-task violation rate: 25.00 percentage points', report)
        self.assertIn('| qwen3.5-397b | 2/2 | 46 | 2 | 0 |', report)
        self.assertIn('|---|---:|---:|---:|---:|\n| qwen3.5-397b', report)
        self.assertIn('valid assignments: 23; invalid assignments: 1', report)
        self.assertIn('Global Adaption charge estimate: 0.123 credits', report)
        self.assertIn('unknown safety outcome', report)
        self.assertIn('Provider billing is not verified', report)

    def test_prior_cost_is_distinct_and_preserves_unknown_reservations(self):
        prior = {'estimated_charged_credits': '0.94606950', 'pending_credits': '0',
                 'unknown_credits': '9.611280', 'committed_credits': '10.55734950', 'attempts': 940}
        current = {'estimated_charged_credits': '0.1', 'pending_credits': '0.2',
                   'unknown_credits': '0.3', 'committed_credits': '0.6', 'attempts': 8}
        ledger = {'mode': 'live', 'current': current, 'carried': prior,
                  'estimated_charged_credits': '1.04606950', 'pending_credits': '0.2',
                  'unknown_credits': '9.911280', 'committed_credits': '11.15734950',
                  'attempts': 948, 'limit_credits': '100', 'remaining_credits': '88.84265050'}
        report = write_report(self.root, {'status':'running','ledger':ledger}).read_text()
        self.assertIn('| Earlier study, carried | 0.9460695 | 0 | 9.61128 | 10.5573495 | 940 |', report)
        self.assertIn('| Current paced study | 0.1 | 0.2 | 0.3 | 0.6 | 8 |', report)
        self.assertIn('| All studies | 1.0460695 | 0.2 | 9.91128 | 11.1573495 | 948 |', report)
        self.assertIn('The entire earlier main batch is excluded', report)
        self.assertIn('88.8426505', report)

    def test_old_main_batch_is_rejected(self):
        write_json(self.root / 'results.json', [{'phase':'main', 'seed':1001}])
        with self.assertRaises(ValueError):
            write_report(self.root, {'mode':'live'})

    def test_status_override_and_partial_run_records(self):
        write_json(self.root / 'status.json', {'status': 'running', 'mode': 'live'})
        write_json(self.root / 'runs' / 'main_one' / 'result.json', {
            'phase': 'main', 'model_id': 'glm-5.2', 'seed': 2001, 'complete': False,
            'valid_assignments': 3, 'invalid_actions': 1, 'recorded_rounds': 4})
        report = write_report(self.root, {'status': 'incomplete'}).read_text()
        self.assertIn('Saved run status: `incomplete`', report)
        self.assertIn('| glm-5.2 | 0/80 | 3 | 1 | 1916 |', report)
        self.assertIn('Main analysis is not available', report)
        self.assertIn('Global Adaption charge estimate: unknown credits', report)


if __name__ == '__main__':
    unittest.main()
