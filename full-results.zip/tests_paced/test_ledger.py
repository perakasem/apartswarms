"""Offline tests for immutable prior costs and current atomic reservations."""
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
from copy import deepcopy
from decimal import Decimal
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest

from paced_study.ledger import BudgetError, CreditLedger, read_prior
from paced_study.transport import MODEL_PRICES, maximum_call_cost

MODEL = 'qwen3.5-397b'
RESERVE = maximum_call_cost(MODEL)


def prior_fixture(root):
    root.mkdir()
    with closing(sqlite3.connect(root / 'credits.sqlite')) as db:
        db.execute('CREATE TABLE metadata (key TEXT PRIMARY KEY,value TEXT NOT NULL)')
        db.execute('CREATE TABLE attempts (id TEXT PRIMARY KEY,model TEXT,phase TEXT,retry INTEGER,reserved TEXT,status TEXT,estimated_charge TEXT,usage TEXT)')
        values = {'mode': 'live', 'currency': 'adaption_credits', 'limit_credits': '1E+2',
                  'prices': json.dumps(MODEL_PRICES, sort_keys=True), 'frozen_reason': 'Prior rate limit stop'}
        db.executemany('INSERT INTO metadata VALUES (?,?)', values.items())
        db.executemany('INSERT INTO attempts VALUES (?,?,?,?,?,?,?,?)', [
            ('old-known-1', MODEL, 'probe', 0, '.02', 'settled', '.005', None),
            ('old-known-2', MODEL, 'main', 0, '.02', 'settled', '.002', None),
            ('old-unknown', 'glm-5.2', 'main', 1, '.02', 'unknown', None, None)])
        db.commit()
    status = {'mode': 'live', 'status': 'incomplete', 'ledger': {
        'mode': 'live', 'currency': 'adaption_credits', 'limit_credits': '100',
        'frozen': True, 'frozen_reason': 'Prior rate limit stop', 'attempts': 3,
        'estimated_charged_credits': '.007', 'pending_credits': '0',
        'unknown_credits': '.02', 'committed_credits': '.027'}}
    (root / 'status.json').write_text(json.dumps(status))
    (root / 'study.json').write_text(json.dumps({'mode': 'live', 'protocol': 'selection-1.2'}))


class PacedLedgerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.prior = Path(self.temp.name) / 'prior'
        self.path = Path(self.temp.name) / 'current' / 'credits.sqlite'
        prior_fixture(self.prior)
        self.carry = read_prior(self.prior)

    def tearDown(self):
        self.temp.cleanup()

    def ledger(self, limit='100'):
        return CreditLedger(self.path, limit_credits=limit, carry=self.carry)

    def test_prior_receipt_is_read_only_and_includes_all_costs(self):
        before = {name: (self.prior / name).read_bytes() for name in ('credits.sqlite', 'study.json', 'status.json')}
        again = read_prior(self.prior)
        self.assertEqual(again, self.carry)
        self.assertEqual(again['attempts'], 3)
        self.assertEqual(Decimal(again['estimated_charged_credits']), Decimal('.007'))
        self.assertEqual(Decimal(again['unknown_credits']), Decimal('.02'))
        self.assertEqual(Decimal(again['committed_credits']), Decimal('.027'))
        self.assertEqual(before, {name: (self.prior / name).read_bytes() for name in before})

    def test_new_live_ledger_requires_carry(self):
        with self.assertRaises(BudgetError):
            CreditLedger(self.path)

    def test_reopen_loads_carry_and_rejects_changed_carry(self):
        self.ledger()
        loaded = CreditLedger(self.path)
        self.assertEqual(loaded.carry, self.carry)
        changed = deepcopy(self.carry)
        changed['root'] += '-other'
        with self.assertRaises(BudgetError):
            CreditLedger(self.path, carry=changed)

    def test_carry_cannot_change_through_input_or_returned_dictionary(self):
        ledger = self.ledger()
        self.carry['committed_credits'] = '0'
        returned = ledger.carry
        returned['committed_credits'] = '0'
        self.assertEqual(ledger.carried_committed, Decimal('.027'))
        self.assertEqual(Decimal(ledger.snapshot()['committed_credits']), Decimal('.027'))

    def test_current_and_global_snapshot_are_separate(self):
        ledger = self.ledger()
        ledger.reserve('a', MODEL, 'probe', RESERVE)
        ledger.settle('a', '.001')
        ledger.reserve('b', MODEL, 'probe', RESERVE)
        ledger.mark_unknown('b', freeze=False)
        ledger.reserve('c', MODEL, 'probe', RESERVE)
        snapshot = ledger.snapshot()
        self.assertEqual(snapshot['current']['attempts'], 3)
        self.assertEqual(snapshot['carried']['attempts'], 3)
        self.assertEqual(snapshot['attempts'], 6)
        self.assertEqual(Decimal(snapshot['current']['estimated_charged_credits']), Decimal('.001'))
        self.assertEqual(Decimal(snapshot['estimated_charged_credits']), Decimal('.008'))
        self.assertEqual(Decimal(snapshot['unknown_credits']), Decimal('.02') + RESERVE)
        self.assertEqual(Decimal(snapshot['pending_credits']), RESERVE)
        self.assertEqual(Decimal(snapshot['committed_credits']), Decimal('.028') + 2 * RESERVE)

    def test_reservations_include_prior_carry_in_limit(self):
        limit = Decimal('.027') + RESERVE
        ledger = self.ledger(str(limit))
        ledger.reserve('a', MODEL, 'probe', RESERVE)
        with self.assertRaises(BudgetError):
            ledger.reserve('b', MODEL, 'probe', RESERVE)
        ledger.settle('a', 0)
        ledger.reserve('b', MODEL, 'probe', RESERVE)

    def test_concurrent_reservations_cannot_exceed_global_limit(self):
        ledger = self.ledger(str(Decimal('.027') + 5 * RESERVE))
        def reserve(index):
            try:
                ledger.reserve(f'r{index}', MODEL, 'main', RESERVE)
                return True
            except BudgetError:
                return False
        with ThreadPoolExecutor(max_workers=8) as pool:
            passed = list(pool.map(reserve, range(30)))
        self.assertEqual(sum(passed), 5)
        self.assertEqual(ledger.snapshot()['current_attempts'], 5)

    def test_unknown_keeps_reservation_and_freeze_blocks_calls(self):
        ledger = self.ledger()
        ledger.reserve('a', MODEL, 'probe', RESERVE)
        ledger.mark_unknown('a')
        self.assertEqual(Decimal(ledger.snapshot()['current']['unknown_credits']), RESERVE)
        with self.assertRaises(BudgetError):
            ledger.reserve('b', MODEL, 'probe', RESERVE)

    def test_overrun_is_saved_before_freeze(self):
        ledger = self.ledger()
        ledger.reserve('a', MODEL, 'probe', RESERVE)
        with self.assertRaises(BudgetError):
            ledger.settle('a', '.5')
        self.assertEqual(Decimal(ledger.snapshot()['current']['estimated_charged_credits']), Decimal('.5'))
        self.assertTrue(ledger.snapshot()['frozen'])

    def test_phase_retry_and_duplicate_limits(self):
        ledger = self.ledger()
        for index in range(4):
            ledger.reserve(f'p{index}', MODEL, 'probe', RESERVE)
        with self.assertRaises(BudgetError):
            ledger.reserve('p4', MODEL, 'probe', RESERVE)
        for index in range(100):
            ledger.reserve(f'r{index}', MODEL, 'probe', RESERVE, is_retry=True)
        with self.assertRaises(BudgetError):
            ledger.reserve('r100', MODEL, 'probe', RESERVE, is_retry=True)
        with self.assertRaises(BudgetError):
            ledger.reserve('p0', MODEL, 'main', RESERVE)
        self.assertEqual(ledger.snapshot()['counts'][MODEL]['retries'], 100)

    def test_offline_has_zero_carry_and_zero_charges(self):
        ledger = CreditLedger(self.path, mode='offline')
        ledger.reserve('a', MODEL, 'probe', 0)
        with self.assertRaises(BudgetError):
            ledger.settle('a', '.001')
        ledger.settle('a', 0)
        self.assertEqual(Decimal(ledger.snapshot()['committed_credits']), 0)
        self.assertEqual(ledger.snapshot()['carried_attempts'], 0)
        with self.assertRaises(BudgetError):
            CreditLedger(self.path, mode='offline', carry=self.carry)

    def test_prior_status_must_match_actual_ledger(self):
        path = self.prior / 'status.json'
        value = json.loads(path.read_text())
        value['ledger']['unknown_credits'] = '0'
        path.write_text(json.dumps(value))
        with self.assertRaises(BudgetError):
            read_prior(self.prior)

    def test_prior_pending_or_unfrozen_ledger_is_rejected(self):
        with closing(sqlite3.connect(self.prior / 'credits.sqlite')) as db:
            db.execute("UPDATE attempts SET status='pending' WHERE status='unknown'")
            db.commit()
        with self.assertRaises(BudgetError):
            read_prior(self.prior)
        with closing(sqlite3.connect(self.prior / 'credits.sqlite')) as db:
            db.execute("UPDATE attempts SET status='unknown' WHERE status='pending'")
            db.execute("UPDATE metadata SET value='' WHERE key='frozen_reason'")
            db.commit()
        with self.assertRaises(BudgetError):
            read_prior(self.prior)

    def test_bad_carry_totals_and_hashes_are_rejected(self):
        for field, value in [('committed_credits', '0'), ('pending_credits', '.1'),
                             ('unknown_credits', 'NaN'), ('ledger_hash', 'bad')]:
            changed = deepcopy(self.carry)
            changed[field] = value
            with self.subTest(field=field), self.assertRaises((BudgetError, ValueError)):
                CreditLedger(self.path, carry=changed)

    def test_full_fixed_reservation_is_required(self):
        ledger = self.ledger()
        for amount in ['0', 'NaN', '-1', 'Infinity']:
            with self.subTest(amount=amount), self.assertRaises(ValueError):
                ledger.reserve('a', MODEL, 'probe', amount)


if __name__ == '__main__':
    unittest.main()
