from copy import deepcopy
from decimal import Decimal
import io
import json
import unittest
import urllib.error
import urllib.request

from paced_study.transport import (AdaptionProvider, TransportError, _NoRedirect,
    estimate_credit_charge, maximum_call_cost, validate_usage, parse_retry_after)


MODEL = 'qwen3.5-397b'
MESSAGES = [{'role': role, 'content': text} for role, text in
            [('system', 'Rules'), ('user', 'Task'), ('user', 'State')]]


def response():
    return {'id': 'resp-test', 'model': MODEL, 'status': 'completed',
            'reasoning': {'effort': 'none'},
            'output_text': '{"worker_id":"W1"}',
            'output': [{'type': 'message', 'content': [{'type': 'output_text', 'text': '{"worker_id":"W1"}'}]}],
            'usage': {'input_tokens': 200, 'output_tokens': 50, 'total_tokens': 250,
                      'output_tokens_details': {'reasoning_tokens': 0}}}


class TransportTests(unittest.TestCase):
    def setUp(self):
        self.seen = []

    def provider(self, raw):
        def opener(request, timeout):
            self.seen.append(request)
            return io.BytesIO(json.dumps(raw).encode())
        return AdaptionProvider('unit-test-key', opener=opener)

    def test_fixed_request_and_response(self):
        result = self.provider(response()).complete(MODEL, MESSAGES)
        self.assertEqual(result['text'], '{"worker_id":"W1"}')
        self.assertEqual(result['id'], 'resp-test')
        self.assertEqual(len(self.seen), 1)
        request = self.seen[0]
        self.assertEqual(request.full_url, 'https://api.prod.adaptionlabs.ai/api/v1/responses')
        body = json.loads(request.data)
        self.assertEqual(body['input'], MESSAGES)
        self.assertEqual(body['tools'], [])
        self.assertEqual(body['tool_choice'], 'none')
        self.assertFalse(body['agentic_memory'])
        self.assertFalse(body['store'])
        self.assertFalse(body['stream'])
        self.assertEqual(body['max_output_tokens'], 512)
        self.assertEqual(body['reasoning'], {'effort': 'none'})
        self.assertNotIn('previous_response_id', body)
        self.assertNotIn('unit-test-key', json.dumps(body))

    def test_read_only_hosted_model_list(self):
        raw = {'object': 'list', 'data': [{'id': MODEL}]}
        self.assertEqual(self.provider(raw).list_models(), raw)
        self.assertEqual(self.seen[0].method, 'GET')
        self.assertTrue(self.seen[0].full_url.endswith('/models?type=hosted'))

    def test_settings_and_shape_fail_before_transport(self):
        provider = self.provider(response())
        for model, messages in [('stack:other', MESSAGES), (MODEL, []),
                                (MODEL, [{'role': 'user', 'content': 'X'}] * 3)]:
            with self.assertRaises(ValueError):
                provider.complete(model, messages)
        self.assertEqual(self.seen, [])

    def test_bad_usage_model_status_and_tools_keep_known_accounting(self):
        cases = [dict(model='other'), dict(status='incomplete'), dict(usage=None),
                 dict(output=[{'type': 'mcp_call'}])]
        too_many = deepcopy(response()['usage']); too_many.update(output_tokens=513,total_tokens=713)
        cases.append(dict(usage=too_many))
        for change in cases:
            with self.subTest(change=change):
                raw = {**response(), **change}
                with self.assertRaises(TransportError) as caught:
                    self.provider(raw).complete(MODEL, MESSAGES)
                self.assertTrue(caught.exception.fatal)
                self.assertEqual(caught.exception.request_id, 'resp-test')
                self.assertEqual(caught.exception.known_usage, raw['usage'])

    def test_usage_details_reject_bool_negative_and_inconsistent_total(self):
        for usage in [dict(input_tokens=True,output_tokens=1,total_tokens=2),
                      dict(input_tokens=1,output_tokens=-1,total_tokens=0),
                      dict(input_tokens=1,output_tokens=1,total_tokens=3),
                      dict(input_tokens=1,output_tokens=1,total_tokens=2,
                           output_tokens_details={'reasoning_tokens':2})]:
            with self.subTest(usage=usage), self.assertRaises(ValueError):
                validate_usage(usage)

    def test_live_response_must_confirm_disabled_reasoning_and_integer_zero(self):
        for reasoning, details in [(None, {'reasoning_tokens': 0}),
                                   ({'effort': 'low'}, {'reasoning_tokens': 0}),
                                   ({'effort': 'none'}, None),
                                   ({'effort': 'none'}, {'reasoning_tokens': 1}),
                                   ({'effort': 'none'}, {'reasoning_tokens': False})]:
            raw = response()
            raw['reasoning'] = reasoning
            raw['usage']['output_tokens_details'] = details
            with self.subTest(reasoning=reasoning, details=details), self.assertRaises(TransportError) as caught:
                self.provider(raw).complete(MODEL, MESSAGES)
            self.assertTrue(caught.exception.fatal)

    def test_output_limit_consumes_turn_without_retry_or_global_freeze(self):
        raw=response();raw['status']='incomplete';raw['incomplete_details']={'reason':'max_output_tokens'}
        with self.assertRaises(TransportError) as caught:
            self.provider(raw).complete(MODEL,MESSAGES)
        self.assertFalse(caught.exception.fatal)
        self.assertFalse(caught.exception.retryable)
        self.assertEqual(caught.exception.known_usage,raw['usage'])
        self.assertEqual(caught.exception.request_id,'resp-test')
        # A wrong model remains fatal even if output is also incomplete.
        raw['model']='other'
        with self.assertRaises(TransportError) as caught:
            self.provider(raw).complete(MODEL,MESSAGES)
        self.assertTrue(caught.exception.fatal)

    def test_no_automatic_retry_and_safe_error(self):
        for status in (401, 429, 503):
            seen = []
            def opener(request, timeout):
                seen.append(request)
                raise urllib.error.HTTPError(request.full_url,status,'unit-test-key',{},None)
            provider = AdaptionProvider('unit-test-key', opener=opener)
            with self.assertRaises(TransportError) as caught:
                provider.complete(MODEL, MESSAGES)
            self.assertEqual(len(seen),1)
            self.assertEqual(caught.exception.retryable,status != 401)
            self.assertNotIn('unit-test-key',str(caught.exception))

    def test_redirect_never_forwards_authorization(self):
        request = urllib.request.Request('https://api.prod.adaptionlabs.ai/api/v1/responses',
                                         headers={'Authorization':'Bearer unit-test-key'})
        with self.assertRaises(urllib.error.HTTPError):
            _NoRedirect().redirect_request(request,None,302,'Moved',{},'https://other.example/steal')

    def test_provider_content_redacts_key(self):
        raw = response(); raw['output_text'] = 'unit-test-key'; raw['metadata'] = {'echo': 'unit-test-key'}
        result = self.provider(raw).complete(MODEL,MESSAGES)
        self.assertNotIn('unit-test-key', json.dumps(result))

    def test_output_parts_and_credit_estimates(self):
        raw = response(); raw.pop('output_text')
        self.assertEqual(self.provider(raw).complete(MODEL,MESSAGES)['text'], '{"worker_id":"W1"}')
        self.assertEqual(maximum_call_cost(MODEL,False),Decimal('0.005092'))
        self.assertEqual(maximum_call_cost('glm-5.2'),Decimal('0.01118544'))
        usage={'input_tokens':6000,'output_tokens':2000,'total_tokens':8000,
               'input_tokens_details':{'cached_tokens':6000},
               'output_tokens_details':{'reasoning_tokens':1000}}
        self.assertEqual(estimate_credit_charge(MODEL,usage),Decimal('0.0103'))

    def test_paced_output_allowance_and_full_request_budget(self):
        usage = {'input_tokens': 6000, 'output_tokens': 512, 'total_tokens': 6512}
        self.assertEqual(validate_usage(usage), usage)
        reserve = sum(maximum_call_cost(model) * 2120 for model in (MODEL, 'glm-5.2'))
        self.assertEqual(reserve, Decimal('35.0479248'))
        self.assertEqual(reserve + Decimal('10.55734950'), Decimal('45.60527430'))

    def test_http_status_retry_after_and_safe_error_records(self):
        secret = 'unit-test-key'
        def opener(request, timeout):
            headers = {'Retry-After': '120', 'X-RateLimit-Limit': '500',
                       'X-RateLimit-Remaining': '0', 'X-RateLimit-Reset': '123',
                       'Authorization': 'Bearer ' + secret, 'Set-Cookie': secret,
                       'X-Other': secret}
            body = json.dumps({'error': 'Too many requests', 'echo': secret,
                               'authorization': 'Bearer another-secret'}).encode()
            raise urllib.error.HTTPError(request.full_url, 429, secret, headers, io.BytesIO(body))
        provider = AdaptionProvider(secret, opener=opener)
        with self.assertRaises(TransportError) as caught:
            provider.complete(MODEL, MESSAGES)
        error = caught.exception
        self.assertEqual(error.http_status, 429)
        self.assertEqual(error.retry_after_seconds, 120)
        self.assertEqual(error.rate_headers['x-ratelimit-limit'], '500')
        self.assertNotIn('authorization', error.rate_headers)
        self.assertNotIn('set-cookie', error.rate_headers)
        self.assertNotIn('x-other', error.rate_headers)
        self.assertNotIn(secret, str(error) + error.error_body + json.dumps(error.rate_headers))
        self.assertNotIn('another-secret', error.error_body)
        self.assertTrue(error.retryable)
        self.assertFalse(error.fatal)

    def test_retry_after_http_date_and_invalid_values(self):
        from datetime import datetime, timezone
        now = datetime(2026, 11, 7, 22, 0, 0, tzinfo=timezone.utc)
        self.assertEqual(parse_retry_after('Sat, 07 Nov 2026 22:02:00 GMT', now=now), 120)
        self.assertEqual(parse_retry_after('Sat, 07 Nov 2026 21:59:00 GMT', now=now), 0)
        self.assertEqual(parse_retry_after('0'), 0)
        for value in (None, '', '-1', 'bad-date', '1.5'):
            self.assertIsNone(parse_retry_after(value, now=now))

    def test_bounded_error_body_does_not_keep_partial_secret(self):
        def opener(request, timeout):
            body = ('x' * 65530 + 'unit-test-key').encode()
            raise urllib.error.HTTPError(request.full_url, 429, 'Limited', {}, io.BytesIO(body))
        with self.assertRaises(TransportError) as caught:
            AdaptionProvider('unit-test-key', opener=opener).complete(MODEL, MESSAGES)
        self.assertNotIn('unit-', caught.exception.error_body)
        self.assertTrue(caught.exception.error_body.endswith('[TRUNCATED]'))


if __name__ == '__main__':
    unittest.main()
