import asyncio
from contextlib import ExitStack
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import AsyncMock, Mock, patch

from paced_study import cli
from paced_study.common import write_json, read_json, digest
from paced_study.runner import MODELS


class Counter:
    name = 'local-test-only'
    def count(self, messages): return 4000


class CliTests(unittest.TestCase):
    def args(self, root, **extra):
        values = dict(mode='offline', execute_paid=False, key_receipt=None,
                      available_credits=4500, result_root=Path(root)/'new',
                      prior_root=Path(root)/'prior', pilot_only=True)
        values.update(extra)
        return SimpleNamespace(**values)

    def report(self, base):
        report = {'passed': True, 'tests': 1, 'skipped': 0,
                  'network_blocked': True, 'paid_calls': 0, 'source_hashes': cli.source_hashes()}
        write_json(base/cli.TEST_REPORT, report)
        write_json(base/'tokenizers'/cli.NATIVE_REPORT, {'network_blocked': True, 'paid_calls': 0,
                   'models': {key: {'counter': Counter.name} for key in ('qwen', 'glm')}})
        return report

    def test_paid_switch_is_required_before_key_or_provider_access(self):
        with tempfile.TemporaryDirectory() as folder, patch.object(cli, 'require_offline_checks') as checks, \
                patch('key_prompt.receive_key') as key:
            with self.assertRaisesRegex(ValueError, 'execute-paid'):
                asyncio.run(cli.execute(self.args(folder, mode='live')))
            checks.assert_not_called(); key.assert_not_called()

    def test_key_receipt_is_required(self):
        with tempfile.TemporaryDirectory() as folder, patch('key_prompt.receive_key') as key:
            with self.assertRaisesRegex(ValueError, 'private key receipt'):
                asyncio.run(cli.execute(self.args(folder, mode='live', execute_paid=True)))
            key.assert_not_called()

    def test_even_an_empty_existing_result_folder_is_rejected(self):
        with tempfile.TemporaryDirectory() as folder, patch.object(cli, 'require_offline_checks') as checks:
            args = self.args(folder); args.result_root.mkdir()
            with self.assertRaisesRegex(ValueError, 'already exists'):
                asyncio.run(cli.execute(args))
            checks.assert_not_called()

    def test_offline_proof_cannot_be_stale_or_skip_tests(self):
        with tempfile.TemporaryDirectory() as folder, patch.object(cli, 'BASE', Path(folder)):
            base = Path(folder); report = self.report(base)
            cli.require_offline_checks()
            for field, value in [('source_hashes', {'changed': 'changed'}), ('skipped', 1),
                                 ('tests', 0), ('paid_calls', 1), ('network_blocked', False)]:
                write_json(base/cli.TEST_REPORT, {**report, field: value})
                with self.assertRaisesRegex(ValueError, 'offline checks'):
                    cli.require_offline_checks()

    def test_native_fingerprint_must_match_paced_report(self):
        with tempfile.TemporaryDirectory() as folder, patch.object(cli, 'BASE', Path(folder)), \
                patch.object(cli, 'NativeCounter', return_value=Counter()):
            self.report(Path(folder)); self.assertEqual(set(cli.counters()), set(MODELS))
            report = read_json(Path(folder)/'tokenizers'/cli.NATIVE_REPORT)
            report['models']['glm']['counter'] = 'old-package-counter'
            write_json(Path(folder)/'tokenizers'/cli.NATIVE_REPORT, report)
            with self.assertRaisesRegex(ValueError, 'stale'):
                cli.counters()

    def test_full_offline_pilot_writes_fixed_settings_and_zero_cost(self):
        with tempfile.TemporaryDirectory() as folder, patch.object(cli, 'BASE', Path(folder)), \
                patch.object(cli, 'counters', return_value={model: Counter() for model in MODELS}), \
                patch.object(cli, 'read_prior') as prior:
            self.report(Path(folder)); args = self.args(folder)
            self.assertEqual(asyncio.run(cli.execute(args)), 0)
            study = read_json(args.result_root/'study.json')
            status = read_json(args.result_root/'status.json')
            self.assertEqual(study['protocol'], 'paced-1.0')
            self.assertEqual(study['output_cap'], 512)
            self.assertEqual(study['main_seeds'], list(range(2001, 2041)))
            self.assertEqual(status['ledger']['current_attempts'], 200)
            self.assertEqual(status['ledger']['estimated_charged_credits'], '0')
            self.assertEqual(status['status'], 'pilot_passed')
            self.assertFalse((args.result_root/'prior_study_receipt.json').exists())
            prior.assert_not_called()

    def test_live_setup_saves_carry_and_source_before_pipeline(self):
        with tempfile.TemporaryDirectory() as folder, ExitStack() as stack:
            base = Path(folder)
            stack.enter_context(patch.object(cli, 'BASE', base))
            (base/'paced_study').mkdir(); (base/'paced_study/example.py').write_text('# fixed source\n')
            self.report(base)
            write_json(base/'prior/audit.json', {'passed': True, 'issues': []})
            stack.enter_context(patch.object(cli, 'counters', return_value={model: Counter() for model in MODELS}))
            carry = {'ledger_hash': 'prior-ledger'}
            stack.enter_context(patch.object(cli, 'read_prior', return_value=carry))
            stack.enter_context(patch('key_prompt.receive_key', return_value='test-only'))
            provider = stack.enter_context(patch.object(cli, 'AdaptionProvider'))
            provider.return_value.list_models.return_value = {'data': [{'id': model} for model in MODELS]}
            runner_cls = stack.enter_context(patch.object(cli, 'Runner'))
            runner = runner_cls.return_value
            runner.ledger.snapshot.return_value = {'mode': 'live'}
            async def pipeline(main):
                saved = read_json(base/'new/prior_study_receipt.json')
                self.assertEqual(saved, carry)
                self.assertTrue((base/'new/source/paced_study/example.py').is_file())
                return {'status': 'pilot_passed', 'ledger': {'mode': 'live'}}
            runner.pipeline.side_effect = pipeline
            self.assertEqual(asyncio.run(cli.execute(self.args(base, mode='live', execute_paid=True,
                                      key_receipt=base/'receipt'))), 0)
            self.assertEqual(runner_cls.call_args.kwargs['carry'], carry)
            self.assertEqual(read_json(base/'new/study.json')['prior_carry_hash'], digest(carry))
            provider.return_value.complete.assert_not_called()

    def test_changed_prior_receipt_stops_before_result_creation(self):
        with tempfile.TemporaryDirectory() as folder, ExitStack() as stack:
            base = Path(folder)
            stack.enter_context(patch.object(cli, 'BASE', base)); self.report(base)
            write_json(base/'prior/audit.json', {'passed': True, 'issues': []})
            stack.enter_context(patch.object(cli, 'counters', return_value={m: Counter() for m in MODELS}))
            stack.enter_context(patch.object(cli, 'read_prior', side_effect=[{'hash': 'before'}, {'hash': 'after'}]))
            stack.enter_context(patch('key_prompt.receive_key', return_value='test-only'))
            provider = stack.enter_context(patch.object(cli, 'AdaptionProvider'))
            provider.return_value.list_models.return_value = {'data': [{'id': model} for model in MODELS]}
            with self.assertRaisesRegex(ValueError, 'prior study changed'):
                asyncio.run(cli.execute(self.args(base, mode='live', execute_paid=True,
                                      key_receipt=base/'receipt')))
            self.assertFalse((base/'new').exists())
