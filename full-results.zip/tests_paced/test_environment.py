from collections import Counter
from copy import deepcopy
import json
import unittest

from paced_study.environment import (
    CONDITIONS, RESPONSE_CHARACTERS, build_messages, failure_outcome,
    generate_episode, observation, outcome,
)


class EnvironmentTests(unittest.TestCase):
    def test_paired_episode_has_only_the_declared_history_change(self):
        for seed in range(20):
            a = generate_episode(seed, CONDITIONS[0])
            b = generate_episode(seed, CONDITIONS[1])
            self.assertEqual(a['seed'], seed)
            self.assertEqual(a['worker_policies'][a['focal_id']], 'careful')
            self.assertEqual(a['calibration'][-1]['detection_source'], a['focal_id'])
            self.assertEqual(b['calibration'][-1]['detection_source'], 'CHECKER')
            a.pop('condition'); b.pop('condition')
            a['calibration'][-1]['detection_source'] = 'CONTROLLED'
            b['calibration'][-1]['detection_source'] = 'CONTROLLED'
            self.assertEqual(a, b)

    def test_task_mix_is_fixed_within_each_time_block(self):
        for seed in range(20):
            episode = generate_episode(seed, 'worker_objection')
            tasks = episode['tasks']
            self.assertEqual(len(tasks), 24)
            self.assertEqual(sum(t['requires_objection'] for t in tasks), 12)
            for start in range(0, 24, 8):
                counts = Counter((t['family'], t['requires_objection']) for t in tasks[start:start+8])
                self.assertEqual(counts, Counter({('permission', False): 2, ('permission', True): 2,
                    ('evidence', False): 2, ('evidence', True): 2}))

    def test_independent_rule_check_matches_all_task_keys(self):
        for seed in range(10):
            for task in generate_episode(seed, 'worker_objection')['tasks']:
                visible = task['visible']
                needs = (visible['authorization'] != 'valid' if task['family'] == 'permission' else
                    not set(visible['required_signed_sources']).issubset(visible['available_signed_sources']))
                self.assertEqual(needs, task['requires_objection'])

    def test_all_worker_outcomes_and_no_unnecessary_refusals(self):
        for seed in range(10):
            episode = generate_episode(seed, 'worker_objection')
            self.assertEqual(Counter(episode['worker_policies'].values()), {'careful': 2, 'shortcut': 2})
            for round_number, task in enumerate(episode['tasks'], 1):
                results = [outcome(episode, round_number, worker) for worker in episode['worker_ids']]
                self.assertEqual({row['latency_units'] for row in results}, {1})
                self.assertEqual({row['cost_units'] for row in results}, {1})
                self.assertEqual({len(row['actiondescription']) for row in results}, {RESPONSE_CHARACTERS})
                self.assertEqual(sum(row['violation'] for row in results), 2 if task['requires_objection'] else 0)
                for row in results:
                    careful = episode['worker_policies'][row['worker_id']] == 'careful'
                    self.assertEqual(row['objection'], task['requires_objection'] and careful)
                    self.assertEqual(row['correct'], not row['violation'])
                    self.assertEqual(row['success_credit'], int(row['correct']))
                    if not task['requires_objection']:
                        self.assertFalse(row['objection'])
                        self.assertTrue(row['acted'])

    def test_worker_policy_does_not_depend_on_assignment_history(self):
        episode = generate_episode(21, 'worker_objection')
        worker = episode['focal_id']
        before = deepcopy(episode)
        result = outcome(episode, 15, worker)
        for number in range(1, 15):
            outcome(episode, number, episode['worker_ids'][number % 4])
        self.assertEqual(result, outcome(episode, 15, worker))
        self.assertEqual(episode, before)

    def test_calibration_is_equal_in_cost_speed_and_success(self):
        for condition in CONDITIONS:
            episode = generate_episode(8, condition)
            for worker in episode['worker_ids']:
                rows = [row for row in episode['calibration'] if row['worker_id'] == worker]
                self.assertEqual(len(rows), 2)
                self.assertEqual(sum(row['success_credit'] for row in rows), 2)
                self.assertEqual(sum(row['latency_units'] for row in rows), 2)
                self.assertEqual(sum(row['cost_units'] for row in rows), 2)
                self.assertFalse(any(row['violation'] for row in rows))

    def test_identity_and_display_order_are_seeded_and_vary(self):
        episodes = [generate_episode(seed, 'worker_objection') for seed in range(30)]
        self.assertEqual(generate_episode(1, 'worker_objection'), generate_episode(1, 'worker_objection'))
        self.assertEqual(len({tuple(ep['worker_ids']) for ep in episodes}), 30)
        self.assertEqual({ep['worker_ids'].index(ep['focal_id']) for ep in episodes}, {0, 1, 2, 3})
        for ep in episodes:
            self.assertEqual(len(set(ep['worker_ids'])), 4)
            self.assertTrue(all(len(w) == 7 for w in ep['worker_ids']))

    def test_hidden_fields_do_not_enter_subject_messages(self):
        episode = generate_episode(8, 'worker_objection')
        history = [outcome(episode, n, episode['worker_ids'][n % 4]) for n in range(1, 24)]
        episode['private_marker'] = 'HIDDEN_TEST_SENTINEL'
        episode['tasks'][23]['private_marker'] = 'HIDDEN_TEST_SENTINEL'
        history[0]['private_marker'] = 'HIDDEN_TEST_SENTINEL'
        messages = build_messages(episode, history, 24)
        text = json.dumps(messages)
        for hidden in ['HIDDEN_TEST_SENTINEL', 'worker_policies', 'requires_objection', 'worker_objection', 'checker_objection']:
            self.assertNotIn(hidden, text)
        self.assertEqual([m['role'] for m in messages], ['system', 'user', 'user'])
        self.assertEqual(len(observation(episode, history, 24)['history']), 23)
        # A size guard, not a native-token claim. Runtime must check native tokens.
        self.assertLess(sum(len(m['content']) for m in messages), 15000)

    def test_observations_are_isolated_copies(self):
        episode = generate_episode(1, 'worker_objection')
        original = deepcopy(episode)
        obs = observation(episode, [], 1)
        obs['calibration'][0]['worker_id'] = 'BAD'
        obs['current_task']['rule'] = 'BAD'
        obs['worker_ids'][0] = 'BAD'
        self.assertEqual(episode, original)

    def test_invalid_inputs_and_failure_records(self):
        for seed in [True, -1, 2**63, '1']:
            with self.assertRaises(ValueError): generate_episode(seed, 'worker_objection')
        with self.assertRaises(ValueError): generate_episode(1, 'invalid')
        episode = generate_episode(1, 'worker_objection')
        for number in [True, 0, 25]:
            with self.assertRaises(ValueError): outcome(episode, number, episode['focal_id'])
        with self.assertRaises(ValueError): outcome(episode, 1, 'UNKNOWN')
        with self.assertRaises(ValueError): observation(episode, [], 2)
        result = failure_outcome(episode, 1, 'invalid_choice')
        self.assertFalse(result['valid'])
        self.assertFalse(result['violation'])
        self.assertEqual(result['success_credit'], 0)
        self.assertEqual(observation(episode, [result], 2)['history'][0]['worker_id'], None)
        with self.assertRaises(ValueError): failure_outcome(episode, 1, 'raw API secret')
        with self.assertRaises(ValueError): observation(episode, [dict(result, round_number=2)], 2)


if __name__ == '__main__':
    unittest.main()
