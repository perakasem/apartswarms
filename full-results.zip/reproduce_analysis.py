"""Check the publication hashes and repeat the saved analysis. No model calls."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import socket
import sys
import tarfile

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent


def no_network(*args, **kwargs):
    raise RuntimeError('Network access is disabled for this record check')


socket.create_connection = no_network
socket.socket.connect = no_network


def read(path):
    return json.loads(path.read_text())


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def git_blob_sha1(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def safe_path(name):
    relative = Path(name)
    if relative.is_absolute() or '..' in relative.parts:
        raise ValueError('An archive path is not a safe relative path')
    return relative


def verify():
    manifest = read(BASE / 'MANIFEST.json')
    files = manifest['files']
    expected = {item['path'] for item in files}
    actual = {str(p.relative_to(BASE)) for p in BASE.rglob('*') if p.is_file()
              and '.git' not in p.relative_to(BASE).parts and '__pycache__' not in p.parts
              and p.name != 'MANIFEST.json'}
    if expected != actual:
        raise ValueError('The publication file list differs from its manifest')
    for item in files:
        data = (BASE / safe_path(item['path'])).read_bytes()
        if (len(data) != item['bytes'] or sha256(data) != item['sha256']
                or git_blob_sha1(data) != item['git_blob_sha1']):
            raise ValueError('A publication file does not match its manifest: ' + item['path'])
    index = read(BASE / 'archives/INDEX.json')
    original_paths = set()
    originals = 0
    for group in index['archives']:
        packed = b''.join((BASE / safe_path(part)).read_bytes() for part in group['parts'])
        if len(packed) != group['gzip_bytes'] or sha256(packed) != group['gzip_sha256']:
            raise ValueError('An archive does not match its joined-byte hash')
        expected_members = {item['path']: item for item in group['members']}
        with tarfile.open(fileobj=io.BytesIO(gzip.decompress(packed)), mode='r:') as archive:
            members = archive.getmembers()
            if {member.name for member in members} != set(expected_members) or len(members) != len(expected_members):
                raise ValueError('An archive member list differs')
            for member in members:
                safe_path(member.name)
                if not member.isfile() or member.name in original_paths:
                    raise ValueError('An archive has a duplicate path or a non-file member')
                original_paths.add(member.name)
                data = archive.extractfile(member).read()
                item = expected_members[member.name]
                if (len(data) != item['bytes'] or sha256(data) != item['sha256']
                        or git_blob_sha1(data) != item['git_blob_sha1']):
                    raise ValueError('An original record does not match its hash')
                originals += 1
    study_root = BASE / 'results/live_paced'
    study = read(study_root / 'study.json')
    for name, expected_hash in study['source_hashes'].items():
        if sha256((BASE / safe_path(name)).read_bytes()) != expected_hash:
            raise ValueError('A source file differs from the frozen study source')
    from paced_study.analysis import aggregate
    rows = read(study_root / 'results.json')
    saved = read(study_root / 'analysis.json')
    rebuilt = aggregate(rows)
    if rebuilt != saved:
        raise ValueError('The rebuilt analysis differs from the saved analysis')
    counts = {model: result['complete_primary_pairs'] for model, result in rebuilt['models'].items()}
    if len(rows) != 160 or set(counts.values()) != {40}:
        raise ValueError('The main sample count differs from the planned sample')
    print(json.dumps({'passed': True, 'publication_files_checked': len(files),
                      'raw_archives_checked': len(index['archives']), 'original_files_checked': originals,
                      'source_hashes_checked': len(study['source_hashes']),
                      'main_runs': len(rows), 'complete_pairs': counts,
                      'analysis_matches_exactly': True, 'network_disabled': True, 'paid_calls': 0,
                      'billing_verified': False,
                      'scope': 'File integrity and saved main analysis; not the original full audit or provider billing.'}, indent=2))


if __name__ == '__main__':
    verify()
