"""Check saved study records. This program makes no API calls.

Usage: python3 audit_results.py RESULT_ROOT
The audit writes RESULT_ROOT/audit.json. It does not change study records.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import sqlite3

from selection_study.analysis import MODELS, summarize_run
from selection_study.common import digest, read_json, read_log, write_json
from selection_study.environment import (CONDITIONS, build_messages, failure_outcome,
                                         generate_episode, outcome)


BASE = Path(__file__).resolve().parent


def _manifest():
    return [{'phase': phase, 'model_id': model, 'seed': seed, 'condition': condition,
             'run_id': f'{phase}_{model}_{seed}_{condition}'}
            for phase, seeds in [('pilot', (1, 2)), ('main', range(1001, 1041))]
            for seed in seeds for condition in (CONDITIONS if seed % 2 else CONDITIONS[::-1])
            for model in MODELS]


def _probes(protocol='selection-1.0'):
    prefix = {'selection-1.0': 'probe', 'selection-1.1': 'probe_v1_1',
              'selection-1.2': 'probe_v1_2'}[protocol]
    return [{'run_id': f'{prefix}_{model}', 'phase': 'probe', 'model_id': model,
             'seed': 0, 'condition': 'worker_objection'} for model in MODELS]


def _audit_diagnostics(root, archive, ledger_by_id, old_rows, old_metadata, require):
    """Check the separate journal without importing the request transport."""
    directory = root / archive['path'] / 'diagnostics'
    path = directory / 'budget.json'
    journal = archive['diagnostic_journal']
    receipt = archive['amendment']['ledger_receipt']
    saved = receipt.get('diagnostics', {})
    settings = journal.get('settings', {})
    require(saved.get('journal_sha256') == hashlib.sha256(path.read_bytes()).hexdigest(),
            'The imported diagnostic journal bytes differ.')
    require(saved.get('diagnostic_source_sha256') == settings.get('source_sha256')
            == archive['next_study'].get('source_hashes', {}).get('diagnose_adaption.py'),
            'The saved diagnostic source hash differs.')
    require(settings.get('max_attempts') == 20 and settings.get('diagnostic_limit_credits') == '1'
            and settings.get('global_limit_credits') == '100'
            and settings.get('carry_into_main_before_resume') is True,
            'The diagnostic limits or import rule differ.')
    require(receipt.get('old_metadata_sha256') == digest(old_metadata)
            and receipt.get('before', {}).get('attempt_records_sha256') == digest(old_rows),
            'The diagnostic import does not identify the old ledger.')
    entries, terminals, previous = {}, {}, None
    for number, original in enumerate(journal.get('events', []), 1):
        event = dict(original)
        saved_hash = event.pop('hash', None)
        require(event.get('sequence') == number and event.get('previous') == previous
                and saved_hash == digest(event), 'The diagnostic event hash chain differs.')
        previous = saved_hash
        source_id, kind = event.get('attempt_id'), event.get('kind')
        if kind == 'reserve':
            require(isinstance(source_id, str) and source_id not in entries,
                    'A diagnostic reservation ID is invalid or repeated.')
            account = event.get('main_account', {})
            require(account.get('ledger_hash') == digest({'metadata': old_metadata, 'attempts': old_rows})
                    and account.get('study_hash') == digest(archive['study'])
                    and account.get('status_hash') == digest(archive['status']),
                    'A diagnostic reservation has a different prior study state.')
            model = event.get('model')
            require(model in MODELS and event.get('reserved_credits')
                    == settings.get('reservation_by_model', {}).get(model),
                    'A diagnostic model or reservation differs.')
            entries[source_id] = {'id': 'diagnostic__' + source_id, 'model': model,
                                  'phase': 'diagnostic', 'retry': 0,
                                  'reserved': event.get('reserved_credits'), 'status': 'unknown',
                                  'estimated_charge': None, 'usage': None}
        elif kind in ('settle', 'unknown'):
            require(source_id in entries and source_id not in terminals,
                    'A diagnostic result has no unique reservation.')
            terminals[source_id] = event
            if kind == 'settle' and source_id in entries:
                usage = event.get('usage', {})
                entries[source_id].update(status='settled', estimated_charge=event.get('estimated_credits'),
                    usage=json.dumps({key: usage.get(key) for key in
                                      ('input_tokens', 'output_tokens', 'total_tokens')}, sort_keys=True))
        else:
            require(False, 'The diagnostic journal has an unsupported event.')
    require(previous == saved.get('journal_chain_hash'), 'The final diagnostic chain hash differs.')
    require(2 <= len(entries) <= 20 and saved.get('attempts') == len(entries),
            'The diagnostic attempt count differs.')
    imported_ids = [row['id'] for row in entries.values()]
    require(receipt.get('imported_attempt_ids') == imported_ids,
            'The imported diagnostic attempt list differs.')
    record_hashes, ready = {}, {}
    episode = generate_episode(0, 'worker_objection')
    for source_id, entry in entries.items():
        require(entry == ledger_by_id.get(entry['id']), 'An imported diagnostic ledger row differs.')
        if entry['status'] != 'settled':
            continue
        files = {}
        for name in ('request.json', 'raw_response.json', 'result.json'):
            relative = f'attempts/{source_id}/{name}'
            record_path = directory / relative
            record_hashes[relative] = hashlib.sha256(record_path.read_bytes()).hexdigest()
            files[name] = read_json(record_path)
        request, raw, result = (files[name] for name in ('request.json', 'raw_response.json', 'result.json'))
        terminal = terminals[source_id]
        usage = terminal['usage']
        require(raw.get('usage') == result.get('usage') == usage
                and raw.get('id') == result.get('request_id') == terminal.get('request_id')
                and raw.get('model') == entry['model'], 'A diagnostic response differs from its journal.')
        prices = settings.get('model_prices', {}).get(entry['model'], {})
        token_fields = ('input_tokens', 'output_tokens', 'total_tokens')
        if require(all(type(usage.get(key)) is int and usage[key] >= 0 for key in token_fields),
                   'A diagnostic token count is invalid.'):
            charge = (Decimal(usage['input_tokens']) * Decimal(prices['input'])
                      + Decimal(usage['output_tokens']) * Decimal(prices['output'])) / Decimal(1000000)
            require(usage['input_tokens'] <= 6000 and usage['output_tokens'] <= 256
                    and usage['total_tokens'] == usage['input_tokens'] + usage['output_tokens']
                    and charge == Decimal(entry['estimated_charge'])
                    and charge <= Decimal(entry['reserved']), 'A diagnostic charge or token limit differs.')
        if request.get('variant') != 'reasoning_none':
            continue
        expected_body = {'model': entry['model'], 'input': build_messages(episode, [], 1),
                         'tools': [], 'tool_choice': 'none', 'agentic_memory': False,
                         'store': False, 'stream': False, 'temperature': .7,
                         'max_output_tokens': 256, 'reasoning': {'effort': 'none'}}
        try:
            choice = json.loads(raw.get('output_text', ''))
        except (ValueError, TypeError):
            choice = None
        zero = (usage.get('output_tokens_details') or {}).get('reasoning_tokens')
        if (request.get('body') == expected_body and raw.get('status') == 'completed'
                and (raw.get('reasoning') or {}).get('effort') == 'none' and type(zero) is int and zero == 0
                and result.get('completed_valid_choice') is True and isinstance(choice, dict)
                and set(choice) == {'worker_id'} and choice['worker_id'] in episode['worker_ids']):
            ready[entry['model']] = source_id
    require(record_hashes == saved.get('record_sha256'), 'The diagnostic request or response hashes differ.')
    require(ready == saved.get('ready_attempts_by_model') and set(ready) == set(MODELS),
            'The diagnostic control checks do not pass for both models.')
    require(receipt.get('after', {}).get('attempt_records_sha256') == digest(old_rows + list(entries.values())),
            'The imported ledger row hash differs.')
    charged = sum((Decimal(row['estimated_charge']) for row in entries.values()
                   if row['status'] == 'settled'), Decimal(0))
    unknown = sum((Decimal(row['reserved']) for row in entries.values()
                   if row['status'] == 'unknown'), Decimal(0))
    require(charged + unknown <= 1 and Decimal(saved.get('estimated_charged_credits', '-1')) == charged
            and Decimal(saved.get('unknown_credits', '-1')) == unknown,
            'The imported diagnostic totals differ.')
    return set(imported_ids)


def audit(root):
    root = Path(root).resolve()
    issues, checks = [], {}
    counts = {'source_files': 0, 'runs': 0, 'complete_runs': 0, 'events': 0,
              'outcomes': 0, 'requests': 0, 'ledger_attempts': 0}

    def require(condition, message):
        if not condition:
            issues.append(message)
        return condition

    def load(name, required=True, default=None):
        path = root / name
        if not path.exists():
            if required:
                issues.append(f'Missing record: {name}.')
            return default
        try:
            return read_json(path)
        except Exception:
            issues.append(f'Cannot read JSON record: {name}.')
            return default

    study = load('study.json', default={})
    status = load('status.json', default={})
    mode = study.get('mode', 'unknown')
    protocol = study.get('protocol')
    require(protocol in ('selection-1.0', 'selection-1.1', 'selection-1.2'), 'The study protocol is unknown.')
    archives = []
    for version in ('v1_0', 'v1_1'):
        if not (root / 'amendments' / version).exists():
            continue
        prefix = f'amendments/{version}'
        archives.append({'path': prefix, 'study': load(f'{prefix}/study.json', default={}),
                         'probes': load(f'{prefix}/probes.json', default={}),
                         'status': load(f'{prefix}/status.json', default={}),
                         'amendment': load(f'{prefix}/amendment.json', default={})})
    for index, record in enumerate(archives):
        old_study, old_probes, old_status, amendment = (record[key] for key in ('study', 'probes', 'status', 'amendment'))
        new_study = archives[index + 1]['study'] if index + 1 < len(archives) else study
        record['next_study'] = new_study
        old_protocol = old_study.get('protocol')
        next_protocol = {'selection-1.0': 'selection-1.1', 'selection-1.1': 'selection-1.2'}.get(old_protocol)
        require(new_study.get('protocol') == next_protocol, 'The archived protocol transition is invalid.')
        for field, value in [('from_protocol', old_protocol), ('to_protocol', next_protocol),
                             ('approved_limit_credits', 100), ('previous_study_hash', digest(old_study)),
                             ('current_study_hash', digest(new_study)), ('previous_probes_hash', digest(old_probes)),
                             ('previous_status_hash', digest(old_status))]:
            require(amendment.get(field) == value, f'The amendment provenance differs: {record["path"]}, {field}.')
        require(new_study.get('previous_study_hash') == digest(old_study), 'The new study does not identify the old study.')
        receipt = amendment.get('ledger_receipt')
        if next_protocol == 'selection-1.1':
            linked_receipt = new_study.get('ledger_amendment', new_study.get('ledger_amendment_receipt'))
        else:
            linked_receipt = new_study.get('ledger_control_amendment')
        require(linked_receipt == receipt and receipt is not None, 'The ledger amendment receipts differ or are missing.')
        for field in ('models', 'model_prices', 'input_cap', 'temperature'):
            require(new_study.get(field) == old_study.get(field), f'An unchanged study setting differs: {field}.')
        for name in ('selection_study/environment.py', 'selection_study/analysis.py'):
            require(new_study.get('source_hashes', {}).get(name) == old_study.get('source_hashes', {}).get(name),
                    f'The task, prompt, or score source changed in the amendment: {name}.')
        if next_protocol == 'selection-1.1':
            require(old_study.get('output_cap') == 2000 and new_study.get('output_cap') == 4000,
                    'The output limit transition differs from the amendment.')
            require(new_study.get('token_counters') == old_study.get('token_counters'),
                    'The version 1.1 tokenizer identity changed.')
        else:
            require(old_study.get('output_cap') == new_study.get('output_cap') == 4000,
                    'The version 1.2 output limit changed.')
            require(new_study.get('reasoning_request') == {'effort': 'none'}
                    and new_study.get('reasoning_setting') == 'requested_none_reported_zero_required',
                    'The version 1.2 reasoning control differs.')
            journal = load(f'{record["path"]}/diagnostics/budget.json', default={})
            record['diagnostic_journal'] = journal
            require(amendment.get('diagnostic_journal_hash') == digest(journal),
                    'The diagnostic journal provenance differs.')
        require(new_study.get('limit_adaption_credits') == 100 and new_study.get('inference_concurrency') == 16,
                'The new credit limit or request concurrency differs from the amendment.')
        require(old_status.get('status') == 'probe_failed' and old_probes.get('passed') is False,
                'The old failed probe gate is not preserved.')
        old_ledger = old_status.get('ledger', {})
        expected_old = ((8, '0.05430695', '0') if old_protocol == 'selection-1.0'
                        else (20, '0.12211095', '0.118230'))
        require(old_ledger.get('attempts') == expected_old[0]
                and Decimal(old_ledger.get('estimated_charged_credits', '-1')) == Decimal(expected_old[1])
                and Decimal(old_ledger.get('pending_credits', '-1')) == 0
                and Decimal(old_ledger.get('unknown_credits', '-1')) == Decimal(expected_old[2]),
                'The old probe charge differs from the amendment.')
        require(load(f'{record["path"]}/manifest.json', default=[]) == _manifest(),
                'The archived main manifest differs from the fixed schedule.')
    checks['amendment_transitions_checked'] = len(archives)
    if study.get('previous_study_hash') and not archives:
        require(False, 'The study identifies an amendment but its archive is missing.')
    require(mode in ('offline', 'live'), 'The study mode is invalid.')
    require(status.get('mode', mode) == mode, 'The saved status mode differs from the study mode.')
    finished = (bool(status.get('finished_utc')) or
                status.get('status') in ('complete', 'pilot_passed', 'probe_failed', 'pilot_failed'))
    require(status.get('status') != 'running', 'The study is still running. Repeat the audit after it stops.')
    expected = _manifest()
    manifest = load('manifest.json', default=[])
    require(manifest == expected, 'The saved manifest differs from the fixed schedule.')
    probe_rows = _probes(protocol) + [row for record in archives for row in _probes(record['study']['protocol'])]
    probe_studies = {row['run_id']: record['study'] for record in archives
                     for row in _probes(record['study']['protocol'])}
    expected_rows = {row['run_id']: row for row in expected + probe_rows}

    hashes = study.get('source_hashes', {})
    require(isinstance(hashes, dict) and bool(hashes), 'The source hash map is missing or invalid.')
    if isinstance(hashes, dict):
        for name, expected_hash in hashes.items():
            path = (root / 'source' / name).resolve()
            if not require(path.is_relative_to(root / 'source'), 'A source path is outside the source folder.'):
                continue
            if not require(path.is_file(), f'Missing source copy: {name}.'):
                continue
            require(hashlib.sha256(path.read_bytes()).hexdigest() == expected_hash,
                    f'The source copy hash differs: {name}.')
            counts['source_files'] += 1
        # These files supply the current score calculation used by this audit.
        for name in ('selection_study/analysis.py', 'selection_study/environment.py', 'selection_study/common.py'):
            require(name in hashes and hashlib.sha256((BASE / name).read_bytes()).hexdigest() == hashes.get(name),
                    f'The current scoring source differs from the saved source: {name}.')
    checks['source_hashes_checked'] = counts['source_files']
    for record in archives:
        old_hashes = record['study'].get('source_hashes', {})
        require(isinstance(old_hashes, dict) and bool(old_hashes), 'The archived source hash map is missing.')
        archive_source = (root / record['path'] / 'source').resolve()
        if isinstance(old_hashes, dict):
            for name, expected_hash in old_hashes.items():
                path = (archive_source / name).resolve()
                if not require(path.is_relative_to(archive_source) and path.is_file(),
                               f'Missing or invalid archived source path: {name}.'):
                    continue
                require(hashlib.sha256(path.read_bytes()).hexdigest() == expected_hash,
                        f'The archived source hash differs: {name}.')
                counts['source_files'] += 1
    checks['archived_source_hashes_checked'] = counts['source_files'] - checks['source_hashes_checked']

    pilot = load('pilot.json', required=False)
    probes = load('probes.json', required=False)
    freeze = load('main_freeze.json', required=False)
    if freeze is not None:
        require(freeze.get('study_hash') == digest(study), 'The main freeze study hash differs.')
        require(freeze.get('manifest_hash') == digest(manifest), 'The main freeze manifest hash differs.')
        require(isinstance(pilot, dict) and freeze.get('pilot_hash') == digest(pilot.get('results', [])),
                'The main freeze pilot hash differs.')
        require(isinstance(pilot, dict) and pilot.get('passed') is True, 'Main work has no passed pilot gate.')
        require(isinstance(probes, dict) and probes.get('passed') is True, 'Main work has no passed probe gate.')

    run_results, requests, terminals = {}, {}, {}
    for directory in sorted((root / 'runs').glob('*')):
        if not directory.is_dir():
            continue
        run_id = directory.name
        counts['runs'] += 1
        row = expected_rows.get(run_id)
        if not require(row is not None, f'Unknown run folder: {run_id}.'):
            continue
        if row['phase'] == 'main':
            require(freeze is not None, f'Main run has no saved freeze: {run_id}.')
        try:
            episode = read_json(directory / 'episode.json')
            result = read_json(directory / 'result.json')
            entries = read_log(directory / 'events.jsonl')
        except Exception as error:
            issues.append(f'Cannot check run records: {run_id} ({type(error).__name__}).')
            continue
        run_results[run_id] = result
        run_study = probe_studies.get(run_id, study)
        counts['events'] += len(entries)
        require(bool(entries) and entries[0].get('kind') == 'start', f'The run start record is missing: {run_id}.')
        if not entries:
            continue
        start = entries[0]
        require(start.get('row') == row, f'The start identity differs: {run_id}.')
        require(start.get('mode') == mode and result.get('mode') == mode, f'The run mode differs: {run_id}.')
        require(all(result.get(key) == value for key, value in row.items()), f'The result identity differs: {run_id}.')
        require(episode == generate_episode(row['seed'], row['condition']), f'The task or worker matrix differs: {run_id}.')
        require(start.get('episode_hash') == digest(episode), f'The start episode hash differs: {run_id}.')
        require(result.get('log_hash') == entries[-1]['hash'], f'The result log hash differs: {run_id}.')
        turns, history, round_requests = [], [], {}
        for event in entries[1:]:
            kind = event.get('kind')
            if kind == 'request':
                attempt_id = event.get('attempt_id')
                number = event.get('round_number')
                if not require(isinstance(attempt_id, str) and attempt_id not in requests,
                               f'A request ID is missing or repeated: {run_id}.'):
                    continue
                require(number == len(turns) + 1, f'A request has the wrong round: {run_id}.')
                require(event.get('model_id') == row['model_id'], f'A request model differs: {run_id}.')
                try:
                    rendered = build_messages(episode, history, number)
                    require(event.get('messages') == rendered, f'A rendered request differs: {run_id}, round {number}.')
                except Exception:
                    issues.append(f'Cannot rebuild a request: {run_id}, round {number}.')
                used = round_requests.get(number, 0)
                require(attempt_id == f'{run_id}|r{number}|attempt{used}' and used < 2,
                        f'A request attempt ID or retry count differs: {run_id}.')
                round_requests[number] = used + 1
                count = event.get('counted_input_tokens')
                require(type(count) is int and 0 <= count <= run_study.get('input_cap', 6000),
                        f'A local token count exceeds its limit: {run_id}.')
                require(event.get('counter') == run_study.get('token_counters', {}).get(row['model_id']),
                        f'A request tokenizer differs: {run_id}.')
                requests[attempt_id] = {'model': row['model_id'], 'phase': row['phase'], 'retry': int(used > 0)}
            elif kind in ('response', 'transport_error'):
                attempt_id = event.get('attempt_id')
                require(attempt_id in requests and attempt_id not in terminals,
                        f'A response has no unique request: {run_id}.')
                terminals[attempt_id] = event
                if kind == 'response' and mode == 'live' and run_study.get('protocol') == 'selection-1.2':
                    response = event.get('response', {})
                    raw = response.get('raw', {})
                    reasoning_tokens = (response.get('usage', {}).get('output_tokens_details') or {}).get('reasoning_tokens')
                    require((raw.get('reasoning') or {}).get('effort') == 'none'
                            and type(reasoning_tokens) is int and reasoning_tokens == 0,
                            f'A version 1.2 response lacks the required reasoning control: {run_id}.')
            elif kind == 'outcome':
                turn = {key: event.get(key) for key in ('round', 'worker_id', 'outcome', 'invalid', 'failure_reason')}
                number = turn['round']
                require(number == len(turns) + 1, f'Outcome rounds are not sequential: {run_id}.')
                require(number in round_requests, f'An outcome has no request: {run_id}.')
                try:
                    feedback = (failure_outcome(episode, number, turn['failure_reason']) if turn['invalid']
                                else outcome(episode, number, turn['worker_id']))
                    require(event.get('feedback') == feedback, f'The fixed feedback differs: {run_id}, round {number}.')
                    history.append(feedback)
                except Exception:
                    issues.append(f'Cannot rebuild fixed feedback: {run_id}, round {number}.')
                turns.append(turn)
            elif kind != 'stopped':
                issues.append(f'Unknown event type: {run_id}.')
        counts['outcomes'] += len(turns)
        if result.get('status') == 'complete':
            counts['complete_runs'] += 1
        rounds = 4 if row['phase'] == 'probe' else 24
        require(result.get('scheduled_rounds') == rounds, f'The scheduled round count differs: {run_id}.')
        require(result.get('observed_turns') == len(turns), f'The observed turn count differs: {run_id}.')
        require(result.get('valid_turns') == sum(turn['invalid'] is False for turn in turns),
                f'The valid turn count differs: {run_id}.')
        if result.get('status') == 'complete':
            require(len(turns) == rounds, f'A complete run has missing turns: {run_id}.')
        try:
            scored = summarize_run(episode, turns, 'incomplete' if rounds == 4 else result['status'])
            for key, value in scored.items():
                if rounds == 4 and key in ('status', 'scheduled_rounds'):
                    continue
                require(key in result and type(result[key]) is type(value) and result[key] == value,
                        f'The saved score differs: {run_id}, field {key}.')
        except Exception as error:
            issues.append(f'Cannot recompute the run score: {run_id} ({type(error).__name__}).')

    gate_records = [(pilot, 'pilot', 'pilot'), (probes, 'probes', 'probe')]
    gate_records += [(item['probes'], item['path'] + ' probes', 'probe') for item in archives]
    for record, label, phase in gate_records:
        if record is None:
            continue
        rows = record.get('results', [])
        ids = [row.get('run_id') for row in rows]
        require(len(ids) == len(set(ids)), f'The {label} result list has repeated runs.')
        for row in rows:
            require(row == run_results.get(row.get('run_id')) and row.get('phase') == phase,
                    f'A saved {label} result differs from its run file.')
        if phase == 'probe':
            passed = len(rows) == 2 and all(row.get('status') == 'complete' and row.get('valid_turns') == 4 for row in rows)
        else:
            passed = len(rows) == 8
            for model in MODELS:
                group = [row for row in rows if row.get('model_id') == model]
                passed &= (len(group) == 4 and all(row.get('status') == 'complete' for row in group)
                           and sum(row.get('valid_turns', 0) for row in group) >= 92)
        require(record.get('passed') is bool(passed), f'The saved {label} gate result differs.')
    for record in archives:
        old_ids = {row['run_id'] for row in _probes(record['study']['protocol'])}
        preserved = {run_id: run_results.get(run_id, {}).get('log_hash') for run_id in sorted(old_ids)}
        require(all(preserved.values()) and record['amendment'].get('preserved_probe_runs') == preserved,
                'The preserved probe log hashes differ from the amendment provenance.')
        require({row.get('run_id') for row in record['probes'].get('results', [])} == old_ids,
                'The archived probe run IDs differ.')
    if probes is not None:
        require({row.get('run_id') for row in probes.get('results', [])}
                == {row['run_id'] for row in _probes(protocol)}, 'The new probe run IDs differ.')

    main_list = load('results.json', required=False)
    if main_list is not None:
        require(isinstance(main_list, list), 'The main result list is invalid.')
        if isinstance(main_list, list):
            ids = [row.get('run_id') for row in main_list]
            require(len(ids) == len(set(ids)), 'The main result list has repeated runs.')
            for row in main_list:
                require(row == run_results.get(row.get('run_id')) and row.get('phase') == 'main',
                        'A saved main result differs from its run file.')
    if status.get('status') == 'complete':
        wanted = {row['run_id'] for row in expected + probe_rows}
        require(set(run_results) == wanted and counts['complete_runs'] == len(wanted),
                'The complete study has missing, extra, or incomplete runs.')
        require(isinstance(main_list, list) and len(main_list) == 160, 'The complete study has no full main result list.')
    counts['requests'] = len(requests)

    database = root / 'credits.sqlite'
    try:
        with sqlite3.connect(database.as_uri() + '?mode=ro', uri=True) as db:
            db.row_factory = sqlite3.Row
            ledger = [dict(row) for row in db.execute('SELECT * FROM attempts')]
            metadata = dict(db.execute('SELECT key,value FROM metadata'))
        require(metadata.get('mode') == mode, 'The ledger mode differs from the study mode.')
        ledger_by_id = {row['id']: row for row in ledger}
        counts['ledger_attempts'] = len(ledger)
        diagnostic_ids = set()
        for record in archives:
            previous_database = root / record['path'] / 'credits.sqlite'
            with sqlite3.connect(previous_database.as_uri() + '?mode=ro', uri=True) as db:
                db.row_factory = sqlite3.Row
                previous_entries = [dict(row) for row in db.execute('SELECT * FROM attempts ORDER BY rowid')]
                previous_metadata = dict(db.execute('SELECT key,value FROM metadata'))
            old_protocol = record['study']['protocol']
            allowed_ids = {row['run_id'] for old_version in ('selection-1.0', 'selection-1.1')
                           if old_version <= old_protocol for row in _probes(old_version)}
            require(len(previous_entries) == (8 if old_protocol == 'selection-1.0' else 20),
                    'The archived ledger attempt count differs.')
            for entry in previous_entries:
                require(entry == ledger_by_id.get(entry['id']), 'An old ledger attempt changed during the amendment.')
                require(entry['phase'] == 'probe' and entry['status'] in ('settled', 'unknown')
                        and entry['id'].split('|', 1)[0] in allowed_ids,
                        'The archived ledger contains a different type of attempt.')
            receipt = record['amendment'].get('ledger_receipt', {})
            require(receipt.get('old_attempt_records_unchanged', True) is True,
                    'The receipt does not preserve prior attempts.')
            receipt_key = ('amendment_failed_probes_v1_1' if old_protocol == 'selection-1.0'
                           else 'amendment_control_ready_v1_2')
            require(json.loads(metadata.get(receipt_key, 'null')) == receipt,
                    'The database amendment receipt differs from the saved provenance.')
            require(Decimal(metadata.get('limit_credits', '-1')) == 100,
                    'The amended ledger limit is not 100 credits.')
            if old_protocol == 'selection-1.1':
                require(sum(row['status'] == 'unknown' for row in previous_entries) == 5,
                        'The old unknown-charge count differs.')
                diagnostic_ids |= _audit_diagnostics(root, record, ledger_by_id,
                                                     previous_entries, previous_metadata, require)
        counts['diagnostic_attempts'] = len(diagnostic_ids)
        if protocol == 'selection-1.2':
            require(metadata.get('max_attempts') == '4276'
                    and json.loads(metadata.get('quotas', '{}')) ==
                    {'main': 1920, 'pilot': 96, 'probe': 12, 'diagnostic': 20}
                    and metadata.get('retry_limit') == '100', 'The version 1.2 ledger quotas differ.')
        for attempt_id, request in requests.items():
            entry = ledger_by_id.get(attempt_id)
            if not require(entry is not None, 'A logged request has no credit reservation.'):
                continue
            require(all(entry.get(key) == value for key, value in request.items()),
                    'A ledger request identity differs from its log.')
            terminal = terminals.get(attempt_id)
            if finished:
                require(terminal is not None, 'A finished study has a request without a terminal record.')
                require(entry['status'] != 'pending', 'A finished study has a pending credit reservation.')
            if terminal is not None and terminal.get('kind') == 'response':
                require(entry['status'] == 'settled', 'A successful response has no settled credit entry.')
                require(Decimal(entry['estimated_charge']) == Decimal(terminal['estimated_credits']),
                        'The settled credit estimate differs from the response log.')
                usage = terminal['response']['usage']
                require(json.loads(entry['usage']) == {key: usage[key] for key in ('input_tokens', 'output_tokens', 'total_tokens')},
                        'The ledger token usage differs from the response log.')
        if finished:
            require(set(ledger_by_id) == set(requests) | diagnostic_ids,
                    'The finished ledger and request logs have different attempt IDs.')
        snapshot = status.get('ledger')
        if isinstance(snapshot, dict):
            require(snapshot.get('attempts') == len(ledger), 'The saved ledger attempt count differs.')
            for field, state, amount in [('estimated_charged_credits', 'settled', 'estimated_charge'),
                                         ('pending_credits', 'pending', 'reserved'),
                                         ('unknown_credits', 'unknown', 'reserved')]:
                total = sum((Decimal(row[amount]) for row in ledger if row['status'] == state), Decimal(0))
                require(Decimal(snapshot.get(field, '-1')) == total, f'The saved ledger total differs: {field}.')
    except Exception as error:
        issues.append(f'Cannot check the credit ledger ({type(error).__name__}).')

    report = {'passed': not issues, 'issues': issues, 'counts': counts, 'mode': mode,
              'study_status': status.get('status', 'unknown'), 'checks': checks,
              'time_utc': datetime.now(timezone.utc).isoformat(),
              'audit_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'paid_calls': 0, 'research_result': False,
              'scope': 'This audit checks saved records and scores. It is not a new model experiment.',
              'billing_verified': False}
    write_json(root / 'audit.json', report)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('result_root', type=Path)
    args = parser.parse_args(argv)
    report = audit(args.result_root)
    print(f'Audit {"passed" if report["passed"] else "failed"}. '
          f'Runs checked: {report["counts"]["runs"]}. Issues: {len(report["issues"])}. No API calls were made.')
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
