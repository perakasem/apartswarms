"""Atomic paced-study credit reservations with an immutable prior cost carry."""
from contextlib import closing, contextmanager
from decimal import Decimal, InvalidOperation
import hashlib
import json
from pathlib import Path
import re
import sqlite3

from .transport import MODEL_PRICES, maximum_call_cost

QUOTAS = {'main': 1920, 'pilot': 96, 'probe': 4}
RETRY_LIMIT = 100
MAX_ATTEMPTS = 4240


class BudgetError(RuntimeError):
    pass


def money(value):
    if isinstance(value, bool):
        raise ValueError('The credit amount is invalid')
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ValueError('The credit amount is invalid') from None
    if not result.is_finite() or result < 0:
        raise ValueError('The credit amount must be finite and nonnegative')
    return result


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)


def record_hash(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def strict_json(payload):
    def bad(value):
        raise BudgetError('A saved record contains a non-finite JSON value')
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise BudgetError('A saved record contains a duplicate JSON key')
            result[key] = value
        return result
    return json.loads(payload, parse_constant=bad, object_pairs_hook=unique)


def totals(rows):
    charges = sum((money(row['estimated_charge']) for row in rows if row['status'] == 'settled'), Decimal(0))
    pending = sum((money(row['reserved']) for row in rows if row['status'] == 'pending'), Decimal(0))
    unknown = sum((money(row['reserved']) for row in rows if row['status'] == 'unknown'), Decimal(0))
    return charges, pending, unknown


def read_prior(root):
    """Read the stopped original study. Never open its database for writing."""
    root = Path(root).resolve()
    study_bytes = (root / 'study.json').read_bytes()
    status_bytes = (root / 'status.json').read_bytes()
    study, status = strict_json(study_bytes), strict_json(status_bytes)
    if study.get('mode') != 'live' or status.get('mode') != 'live' or status.get('status') != 'incomplete':
        raise BudgetError('The carry requires an incomplete live prior study')
    with closing(sqlite3.connect((root / 'credits.sqlite').as_uri() + '?mode=ro', uri=True)) as db:
        db.row_factory = sqlite3.Row
        db.execute('BEGIN')
        metadata = dict(db.execute('SELECT key,value FROM metadata').fetchall())
        rows = [dict(row) for row in db.execute('SELECT * FROM attempts ORDER BY rowid')]
    if (metadata.get('mode') != 'live' or metadata.get('currency') != 'adaption_credits'
            or money(metadata.get('limit_credits')) != 100 or not metadata.get('frozen_reason')
            or metadata.get('prices') != json.dumps(MODEL_PRICES, sort_keys=True)
            or 'carry' in metadata):
        raise BudgetError('The prior ledger is not the frozen original 100-credit study')
    if not rows or any(row['status'] not in ('settled', 'unknown') or row['model'] not in MODEL_PRICES
                       or row['retry'] not in (0, 1) or money(row['reserved']) <= 0 for row in rows):
        raise BudgetError('The prior ledger has pending or invalid attempts')
    charged, pending, unknown = totals(rows)
    if charged + pending + unknown > 100:
        raise BudgetError('The prior study already exceeds the global credit limit')
    saved = status.get('ledger', {})
    expected = {'estimated_charged_credits': charged, 'pending_credits': pending,
                'unknown_credits': unknown, 'committed_credits': charged + pending + unknown}
    if (type(saved.get('attempts')) is not int or saved['attempts'] != len(rows) or saved.get('frozen') is not True
            or saved.get('frozen_reason') != metadata['frozen_reason']
            or saved.get('currency') != 'adaption_credits' or money(saved.get('limit_credits')) != 100
            or any(money(saved.get(key)) != amount for key, amount in expected.items())):
        raise BudgetError('The prior status and ledger accounting do not agree')
    return {'schema': 'paced-prior-carry-1', 'currency': 'adaption_credits',
            'root': str(root), 'limit_credits': '100', 'prior_status': 'incomplete',
            'prior_frozen': True, 'frozen_reason': metadata['frozen_reason'],
            'attempts': len(rows), **{key: str(amount) for key, amount in expected.items()},
            'ledger_hash': record_hash({'metadata': metadata, 'attempts': rows}),
            'attempt_records_sha256': record_hash(rows), 'study_hash': record_hash(study),
            'status_hash': record_hash(status), 'study_file_sha256': hashlib.sha256(study_bytes).hexdigest(),
            'status_file_sha256': hashlib.sha256(status_bytes).hexdigest(),
            'actual_billing_verified': False}


def validate_carry(value, mode):
    if value is None:
        if mode != 'offline':
            raise BudgetError('A new live paced ledger requires its prior carry receipt')
        return None
    if mode != 'live' or not isinstance(value, dict):
        raise BudgetError('Only a live ledger can contain a prior carry')
    if (value.get('schema') != 'paced-prior-carry-1' or value.get('currency') != 'adaption_credits'
            or money(value.get('limit_credits')) != 100 or value.get('prior_status') != 'incomplete'
            or value.get('prior_frozen') is not True or not value.get('frozen_reason')
            or type(value.get('attempts')) is not int or value['attempts'] < 1
            or not isinstance(value.get('root'), str) or value.get('actual_billing_verified') is not False):
        raise BudgetError('The prior carry receipt is invalid')
    for field in ('ledger_hash', 'attempt_records_sha256', 'study_hash', 'status_hash',
                  'study_file_sha256', 'status_file_sha256'):
        if not isinstance(value.get(field), str) or not re.fullmatch(r'[a-f0-9]{64}', value[field]):
            raise BudgetError('The prior carry receipt has an invalid record hash')
    charged, pending, unknown = (money(value.get(field)) for field in
                                 ('estimated_charged_credits', 'pending_credits', 'unknown_credits'))
    if pending or charged + unknown != money(value.get('committed_credits')) or charged + unknown > 100:
        raise BudgetError('The prior carry receipt has invalid credit totals')
    return strict_json(canonical(value))


class CreditLedger:
    def __init__(self, path, limit_credits='100', mode='live', *, carry=None):
        self.path = Path(path)
        self.limit = money(limit_credits)
        self.mode = mode
        if mode not in ('live', 'offline') or not 0 < self.limit <= 100:
            raise ValueError('Use live or offline mode and a credit limit above zero and at most 100')
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._transaction() as db:
            db.execute('CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL)')
            db.execute('CREATE TABLE IF NOT EXISTS attempts (id TEXT PRIMARY KEY, model TEXT NOT NULL, phase TEXT NOT NULL, retry INTEGER NOT NULL, reserved TEXT NOT NULL, status TEXT NOT NULL, estimated_charge TEXT, usage TEXT)')
            saved = db.execute("SELECT value FROM metadata WHERE key='carry'").fetchone()
            if saved:
                saved_carry = strict_json(saved[0])
                self._carry = validate_carry(saved_carry if carry is None else carry, mode)
                if canonical(self.carry) != saved[0]:
                    raise BudgetError('The prior carry cannot change when a paced ledger is reopened')
            else:
                if db.execute('SELECT count(*) FROM metadata').fetchone()[0] or db.execute('SELECT count(*) FROM attempts').fetchone()[0]:
                    raise BudgetError('An existing ledger without a carry record cannot become a paced ledger')
                self._carry = validate_carry(carry, mode)
            if self.carried_committed > self.limit:
                raise BudgetError('The prior carry exceeds this credit limit')
            expected = {'mode': mode, 'limit_credits': str(self.limit.normalize()),
                        'currency': 'adaption_credits', 'prices': json.dumps(MODEL_PRICES, sort_keys=True),
                        'quotas': json.dumps(QUOTAS, sort_keys=True), 'retry_limit': str(RETRY_LIMIT),
                        'max_attempts': str(MAX_ATTEMPTS), 'input_cap': '6000', 'output_cap': '512',
                        'carry': canonical(self.carry)}
            for key, value in expected.items():
                row = db.execute('SELECT value FROM metadata WHERE key=?', (key,)).fetchone()
                if row and row[0] != value:
                    raise BudgetError('The paced ledger settings differ from the saved study')
                db.execute('INSERT OR IGNORE INTO metadata VALUES (?,?)', (key, value))
            db.execute("INSERT OR IGNORE INTO metadata VALUES ('frozen_reason','')")

    @property
    def carry(self):
        # Give callers a copy. The cost bound uses the saved internal receipt.
        return strict_json(canonical(self._carry))

    @property
    def carried_committed(self):
        return money(self._carry['committed_credits']) if self._carry else Decimal(0)

    @contextmanager
    def _transaction(self):
        db = sqlite3.connect(self.path, timeout=30, isolation_level=None)
        db.row_factory = sqlite3.Row
        try:
            db.execute('PRAGMA journal_mode=WAL')
            db.execute('PRAGMA synchronous=FULL')
            db.execute('BEGIN IMMEDIATE')
            yield db
            db.execute('COMMIT')
        except BaseException:
            if db.in_transaction:
                db.execute('ROLLBACK')
            raise
        finally:
            db.close()

    @staticmethod
    def _freeze(db, reason):
        db.execute("UPDATE metadata SET value=? WHERE key='frozen_reason'", (str(reason),))

    _totals = staticmethod(totals)

    def reserve(self, attempt_id, model_id, phase, amount, is_retry=False):
        reserved = money(amount)
        if (not isinstance(attempt_id, str) or not attempt_id or len(attempt_id) > 500
                or model_id not in MODEL_PRICES or phase not in QUOTAS or type(is_retry) is not bool):
            raise ValueError('The reservation identity is invalid')
        if self.mode == 'live' and reserved != maximum_call_cost(model_id):
            raise ValueError('A live request needs the full fixed reservation')
        if self.mode == 'offline' and reserved != 0:
            raise ValueError('An offline request must have a zero reservation')
        with self._transaction() as db:
            if db.execute("SELECT value FROM metadata WHERE key='frozen_reason'").fetchone()[0]:
                raise BudgetError('The ledger is frozen')
            rows = db.execute('SELECT * FROM attempts').fetchall()
            if any(row['id'] == attempt_id for row in rows):
                raise BudgetError('The request attempt already exists')
            if len(rows) >= MAX_ATTEMPTS:
                raise BudgetError('The current request limit was reached')
            group = [row for row in rows if row['model'] == model_id]
            used = sum(row['retry'] for row in group) if is_retry else sum(row['phase'] == phase and not row['retry'] for row in group)
            if used >= (RETRY_LIMIT if is_retry else QUOTAS[phase]):
                raise BudgetError('The current phase or retry limit was reached')
            if self.carried_committed + sum(totals(rows)) + reserved > self.limit:
                raise BudgetError('The combined credit limit would be exceeded')
            db.execute('INSERT INTO attempts VALUES (?,?,?,?,?,?,?,?)',
                       (attempt_id, model_id, phase, int(is_retry), str(reserved), 'pending', None, None))
        return attempt_id

    def settle(self, attempt_id, estimated_charge, usage=None):
        charge = money(estimated_charge)
        if self.mode == 'offline' and charge != 0:
            raise BudgetError('An offline request cannot have a charge')
        overrun = False
        with self._transaction() as db:
            row = db.execute('SELECT * FROM attempts WHERE id=?', (attempt_id,)).fetchone()
            if not row or row['status'] == 'settled':
                raise BudgetError('The attempt is missing or already settled')
            safe = None
            if usage is not None:
                safe = {key: usage[key] for key in ('input_tokens', 'output_tokens', 'total_tokens') if key in usage}
                if any(type(value) is not int or value < 0 for value in safe.values()):
                    raise ValueError('Token usage fields must be nonnegative integers')
            db.execute("UPDATE attempts SET status='settled',estimated_charge=?,usage=? WHERE id=?",
                       (str(charge), json.dumps(safe, sort_keys=True), attempt_id))
            overrun = (charge > money(row['reserved'])
                       or self.carried_committed + sum(totals(db.execute('SELECT * FROM attempts').fetchall())) > self.limit)
            if overrun:
                self._freeze(db, 'Estimated credits exceeded the fixed reservation or global limit')
        if overrun:
            raise BudgetError('The charge was recorded and the paced ledger was frozen')

    def mark_unknown(self, attempt_id, reason='The request charge is unknown', *, freeze=True):
        with self._transaction() as db:
            row = db.execute('SELECT status FROM attempts WHERE id=?', (attempt_id,)).fetchone()
            if not row or row[0] == 'settled':
                raise BudgetError('The attempt is missing or already settled')
            db.execute("UPDATE attempts SET status='unknown' WHERE id=?", (attempt_id,))
            if freeze:
                self._freeze(db, reason)

    def freeze(self, reason):
        with self._transaction() as db:
            self._freeze(db, reason)

    def records(self):
        with self._transaction() as db:
            return [dict(row) for row in db.execute('SELECT * FROM attempts ORDER BY rowid')]

    def snapshot(self):
        with self._transaction() as db:
            rows = db.execute('SELECT * FROM attempts').fetchall()
            charged, pending, unknown = totals(rows)
            reason = db.execute("SELECT value FROM metadata WHERE key='frozen_reason'").fetchone()[0]
            carried_charged = money(self.carry['estimated_charged_credits']) if self.carry else Decimal(0)
            carried_unknown = money(self.carry['unknown_credits']) if self.carry else Decimal(0)
            carried_attempts = self.carry['attempts'] if self.carry else 0
            current = {'estimated_charged_credits': str(charged), 'pending_credits': str(pending),
                       'unknown_credits': str(unknown), 'committed_credits': str(charged + pending + unknown),
                       'attempts': len(rows)}
            carried = {'estimated_charged_credits': str(carried_charged), 'pending_credits': '0',
                       'unknown_credits': str(carried_unknown), 'committed_credits': str(self.carried_committed),
                       'attempts': carried_attempts, 'ledger_hash': self.carry['ledger_hash'] if self.carry else None}
            committed = self.carried_committed + charged + pending + unknown
            counts = {model: {'primary_by_phase': {phase: sum(row['model'] == model and row['phase'] == phase and not row['retry'] for row in rows)
                                                   for phase in QUOTAS},
                              'retries': sum(row['model'] == model and row['retry'] for row in rows)} for model in MODEL_PRICES}
            return {'currency': 'adaption_credits', 'mode': self.mode, 'limit_credits': str(self.limit),
                    'estimated_charged_credits': str(carried_charged + charged), 'pending_credits': str(pending),
                    'unknown_credits': str(carried_unknown + unknown), 'committed_credits': str(committed),
                    'remaining_credits': str(self.limit - committed), 'attempts': carried_attempts + len(rows),
                    'current_attempts': len(rows), 'carried_attempts': carried_attempts,
                    'current': current, 'carried': carried, 'counts': counts,
                    'frozen': bool(reason), 'frozen_reason': reason, 'actual_billing_verified': False}


BudgetLedger = CreditLedger
