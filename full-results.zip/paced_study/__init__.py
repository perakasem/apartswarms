"""Controlled tests of coordinator worker selection."""
