import hashlib
import json
import os
from pathlib import Path
import tempfile
import time


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.pending-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w') as stream:
            stream.write(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False) + '\n')
            stream.flush(); os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp): os.unlink(temp)


def read_json(path):
    return json.loads(Path(path).read_text())


class EventLog:
    def __init__(self, path, secrets=()):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.secrets = secrets
        entries = read_log(self.path) if self.path.exists() else []
        self.sequence = len(entries)
        self.previous = entries[-1]['hash'] if entries else None

    def append(self, kind, **values):
        self.sequence += 1
        text = canonical({'kind': kind, 'sequence': self.sequence, 'previous': self.previous,
                          'time': time.time(), **values})
        for secret in self.secrets:
            if secret: text = text.replace(secret, '[REDACTED]')
        entry = json.loads(text)
        entry['hash'] = digest(entry)
        with self.path.open('a') as stream:
            stream.write(canonical(entry) + '\n'); stream.flush(); os.fsync(stream.fileno())
        self.previous = entry['hash']


def read_log(path):
    entries, previous = [], None
    for number, line in enumerate(Path(path).read_text().splitlines(), 1):
        entry = json.loads(line); saved = entry.pop('hash')
        if entry['sequence'] != number or entry['previous'] != previous or saved != digest(entry):
            raise ValueError('The event log integrity check failed')
        entry['hash'] = saved; previous = saved; entries.append(entry)
    return entries
