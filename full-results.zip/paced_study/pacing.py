"""One smooth dispatch gate for every live request and retry in this process."""

import asyncio
from dataclasses import dataclass
import math
from pathlib import Path
import time

from .common import EventLog, write_json


class PacingStopped(RuntimeError):
    pass


@dataclass(frozen=True)
class DispatchTicket:
    generation: int
    dispatched_at: float


class GlobalPacer:
    """No burst credit is accumulated during idle time or cooldowns.

    A generation changes at the first HTTP 429 from that generation. All other
    requests already in flight belong to the same surge, even if they end later.
    They can extend the cooldown but cannot cause another rate reduction.
    """

    def __init__(self, root, *, enabled=True, clock=None, sleep=None):
        self.root = Path(root)
        self.enabled = enabled
        self.clock = clock or time.monotonic
        self.sleep = sleep or asyncio.sleep
        self.started = self.clock()
        self.rate = 4.0
        self.next_dispatch = self.started + .25
        self.cooldown_until = self.started
        self.generation = 0
        self.rate_limit_cycles = 0
        self.dispatches = 0
        self.stopped = False
        self.lock = asyncio.Lock()
        self.log = EventLog(self.root / 'pacing.jsonl')
        self._record('configured', minimum_cooldown_seconds=60,
                     stop_after_rate_limit_cycles=3)

    def snapshot(self):
        now = self.clock()
        return {'enabled': self.enabled, 'rate_per_second': self.rate,
                'rate_limit_cycles': self.rate_limit_cycles, 'generation': self.generation,
                'dispatches': self.dispatches, 'stopped': self.stopped,
                'elapsed_seconds': max(0.0, now - self.started),
                'cooldown_remaining_seconds': max(0.0, self.cooldown_until - now),
                'next_dispatch_remaining_seconds': max(0.0, self.next_dispatch - now)}

    def _record(self, kind, **fields):
        state = self.snapshot()
        self.log.append(kind, **fields, state=state)
        write_json(self.root / 'throttle.json', {**state, 'log_hash': self.log.previous})

    async def wait(self, *, stop=lambda: False):
        if not self.enabled:
            if stop():
                raise PacingStopped('The study stopped before dispatch')
            return DispatchTicket(self.generation, self.clock())
        while True:
            async with self.lock:
                if self.stopped or stop():
                    raise PacingStopped('The global request gate stopped')
                now = self.clock()
                delay = max(self.next_dispatch, self.cooldown_until) - now
                if delay <= 0:
                    self.dispatches += 1
                    self.next_dispatch = now + 1 / self.rate
                    ticket = DispatchTicket(self.generation, now)
                    self._record('dispatch', ticket_generation=ticket.generation)
                    return ticket
            # Short waits allow every queued caller to observe a stop promptly.
            await self.sleep(min(delay, 1.0))

    async def on_rate_limit(self, ticket, retry_after_seconds=None):
        if not self.enabled:
            return self.snapshot()
        if not isinstance(ticket, DispatchTicket):
            raise ValueError('A rate-limit event needs its dispatch ticket')
        delay = 60.0
        if (type(retry_after_seconds) in (int, float)
                and math.isfinite(retry_after_seconds) and retry_after_seconds >= 0):
            delay = max(delay, retry_after_seconds)
        async with self.lock:
            if ticket.generation > self.generation or ticket.generation < 0:
                raise ValueError('The dispatch generation is invalid')
            now = self.clock()
            new_cycle = ticket.generation == self.generation
            if new_cycle:
                self.rate_limit_cycles += 1
                self.generation += 1
                self.rate = 2.0 if self.rate_limit_cycles == 1 else 1.0
                if self.rate_limit_cycles >= 3:
                    self.stopped = True
            self.cooldown_until = max(self.cooldown_until, now + delay)
            self.next_dispatch = max(self.next_dispatch, self.cooldown_until)
            self._record('rate_limit' if new_cycle else 'same_surge_rate_limit',
                         ticket_generation=ticket.generation, cooldown_seconds=delay)
            return self.snapshot()
