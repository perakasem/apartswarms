"""Checked local native tokenizers for the fixed coordinator message format.

The two local template modes bound their known header differences. They do not
identify the provider's reasoning setting. Live probes must check server usage.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path
import re


MODELS = {
    "qwen3.5-397b": "Qwen/Qwen3.5-397B-A17B",
    "glm-5.2": "zai-org/GLM-5.2",
}
FRAMING_ALLOWANCE = 256
INPUT_CAP = 6000


def _digest(value):
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(payload.encode()).hexdigest()


def _messages(messages):
    if not isinstance(messages, list) or len(messages) != 3:
        raise ValueError("The native counter needs three study messages")
    for item, role in zip(messages, ("system", "user", "user")):
        if (not isinstance(item, dict) or set(item) != {"role", "content"}
                or item["role"] != role or not isinstance(item["content"], str)):
            raise ValueError("The native counter supports system, user, user text messages only")


def _flat_ids(value):
    # Transformers 5 can otherwise return BatchEncoding. Its length is the
    # number of dictionary keys, not the number of input tokens.
    if hasattr(value, "keys"):
        value = value.get("input_ids")
    if not isinstance(value, list) or any(type(item) is not int or item < 0 for item in value):
        raise ValueError("The native tokenizer did not return a flat token-ID list")
    return value


class NativeCounter:
    is_native = True

    def __init__(self, model_id, directory):
        path = Path(directory).resolve()
        if model_id not in MODELS:
            raise ValueError("No checked native tokenizer is configured for this model")
        if not path.is_dir():
            raise ValueError("A local native tokenizer directory is required")
        manifest = json.loads((path / "manifest.json").read_text(encoding="utf-8"))
        if (manifest.get("model_id") != model_id or manifest.get("repo") != MODELS[model_id]
                or not isinstance(manifest.get("revision"), str)
                or re.fullmatch(r"[0-9a-f]{40}", manifest["revision"]) is None
                or not isinstance(manifest.get("files"), dict) or not manifest["files"]):
            raise ValueError("The tokenizer manifest does not match the selected model and revision")
        expected_files = manifest["files"]
        actual_files = {str(item.relative_to(path)) for item in path.rglob("*")
                        if item.is_file() and item != path / "manifest.json"}
        if set(expected_files) != actual_files:
            raise ValueError("The tokenizer manifest must cover every local data file")
        for filename, expected_hash in expected_files.items():
            candidate = (path / filename).resolve()
            if not candidate.is_relative_to(path) or not candidate.is_file():
                raise ValueError("The tokenizer manifest contains an invalid file path")
            if (not isinstance(expected_hash, str) or re.fullmatch(r"[0-9a-f]{64}", expected_hash) is None
                    or hashlib.sha256(candidate.read_bytes()).hexdigest() != expected_hash):
                raise ValueError("A checked tokenizer file has changed")
        self.model_id = model_id
        self.directory = path
        self.manifest_hash = _digest(manifest)
        self.revision = manifest["revision"]
        self.versions = {name: importlib.metadata.version(name)
                         for name in ("transformers", "tokenizers", "jinja2")}
        self.source_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        from transformers import AutoTokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(
            str(path), local_files_only=True, trust_remote_code=False)
        if not isinstance(self.tokenizer.chat_template, str) or not self.tokenizer.chat_template:
            raise ValueError("The native tokenizer has no single checked chat template")
        self.name = "native_local:" + _digest({
            "model_id": model_id, "manifest_hash": self.manifest_hash,
            "versions": self.versions, "source_hash": self.source_hash,
            "template_modes": ["default", "enable_thinking_false"],
            "framing_allowance": FRAMING_ALLOWANCE,
        })

    def token_ids(self, messages, *, enable_thinking=None):
        _messages(messages)
        if enable_thinking is not None and enable_thinking is not False:
            raise ValueError("Only default and disabled-thinking template modes are checked")
        options = {} if enable_thinking is None else {"enable_thinking": False}
        result = self.tokenizer.apply_chat_template(
            messages, tokenize=True, add_generation_prompt=True,
            return_dict=False, **options)
        return _flat_ids(result)

    def render(self, messages, *, enable_thinking=None):
        _messages(messages)
        if enable_thinking is not None and enable_thinking is not False:
            raise ValueError("Only default and disabled-thinking template modes are checked")
        options = {} if enable_thinking is None else {"enable_thinking": False}
        value = self.tokenizer.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True, **options)
        if not isinstance(value, str):
            raise ValueError("The native template did not return text")
        return value

    def count_modes(self, messages):
        return {"default": len(self.token_ids(messages)),
                "enable_thinking_false": len(self.token_ids(messages, enable_thinking=False))}

    def count(self, messages):
        return max(self.count_modes(messages).values()) + FRAMING_ALLOWANCE


def verify_native_contexts(asset_root, output_path=None):
    """Check every planned context with network connections blocked."""
    from unittest.mock import patch
    from .environment import CONDITIONS, build_messages, failure_outcome, generate_episode, outcome

    asset_root = Path(asset_root)
    seeds = [10, 11, 12] + list(range(2001, 2041))
    history_policies = {
        "always_focal_careful": "The focal careful worker is selected on every previous turn.",
        "always_shortcut": "The first shortcut worker in the displayed roster is selected on every previous turn.",
        "always_invalid": "Every previous turn has an invalid worker choice and no task action.",
    }
    report = {"status": "local_native_checks_passed", "paid_calls": 0,
              "network_blocked": True, "input_cap": INPUT_CAP,
              "framing_allowance": FRAMING_ALLOWANCE,
              "task_seeds": seeds, "conditions": list(CONDITIONS),
              "history_policies": history_policies,
              "models": {},
              "limits": [
                  "The server's model revision and tokenizer are not directly observed.",
                  "No API reasoning-effort setting is inferred from local template options.",
                  "Live probes must check reported input tokens against this local bound.",
              ]}
    with patch("socket.create_connection", side_effect=AssertionError("Network disabled")), \
            patch("socket.socket.connect", side_effect=AssertionError("Network disabled")):
        for key, model_id in (("qwen", "qwen3.5-397b"), ("glm", "glm-5.2")):
            counter = NativeCounter(model_id, asset_root / key)
            counts = []
            mode_min = {"default": None, "enable_thinking_false": None}
            mode_max = {"default": 0, "enable_thinking_false": 0}
            policy_counts = {policy: [] for policy in history_policies}
            roundtrip_checks = 0
            for seed in seeds:
                for condition in CONDITIONS:
                    episode = generate_episode(seed, condition)
                    shortcut_id = next(worker_id for worker_id in episode["worker_ids"]
                                       if episode["worker_policies"][worker_id] == "shortcut")
                    for history_policy in history_policies:
                        history = []
                        for round_number in range(1, 25):
                            messages = build_messages(episode, history, round_number)
                            mode_counts = counter.count_modes(messages)
                            count = max(mode_counts.values()) + FRAMING_ALLOWANCE
                            if count > INPUT_CAP:
                                raise AssertionError(f"Native input cap failed: {model_id}, {seed}, {condition}, {history_policy}, round {round_number}: {count}")
                            counts.append(count)
                            policy_counts[history_policy].append(count)
                            for mode, number in mode_counts.items():
                                mode_min[mode] = number if mode_min[mode] is None else min(mode_min[mode], number)
                                mode_max[mode] = max(mode_max[mode], number)
                            if seed == 10 and condition == CONDITIONS[0] and round_number in (1, 12, 24):
                                for setting in (None, False):
                                    rendered = counter.render(messages, enable_thinking=setting)
                                    expected = _flat_ids(counter.tokenizer.encode(rendered, add_special_tokens=False))
                                    if expected != counter.token_ids(messages, enable_thinking=setting):
                                        raise AssertionError("Template and rendered-text token IDs differ")
                                    roundtrip_checks += 1
                            if history_policy == "always_invalid":
                                result = failure_outcome(episode, round_number, "invalid_choice")
                            else:
                                worker_id = (episode["focal_id"] if history_policy == "always_focal_careful"
                                             else shortcut_id)
                                result = outcome(episode, round_number, worker_id)
                            history.append(result)
            report["models"][key] = {
                "model_id": model_id, "revision": counter.revision,
                "manifest_hash": counter.manifest_hash, "counter": counter.name,
                "source_hash": counter.source_hash, "library_versions": counter.versions,
                "episodes_checked": len(seeds) * len(CONDITIONS),
                "episode_policy_checks": len(seeds) * len(CONDITIONS) * len(history_policies),
                "contexts_checked": len(counts), "minimum_count": min(counts),
                "maximum_count": max(counts), "native_mode_minimum": mode_min,
                "native_mode_maximum": mode_max,
                "roundtrip_checks": roundtrip_checks,
                "history_policies": {policy: {
                    "contexts_checked": len(values), "minimum_count": min(values),
                    "maximum_count": max(values),
                } for policy, values in policy_counts.items()},
            }
    if output_path is not None:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        pending = output_path.with_suffix(output_path.suffix + ".pending")
        pending.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        pending.replace(output_path)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description="Check local native tokenizers without model requests")
    parser.add_argument("--tokenizer-root", type=Path, default=Path(__file__).resolve().parents[1] / "tokenizers")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    output = args.output or args.tokenizer_root / "paced_verification.json"
    report = verify_native_contexts(args.tokenizer_root, output)
    print(json.dumps({"status": report["status"], "paid_calls": 0,
        "models": {key: {name: value[name] for name in ("contexts_checked", "maximum_count", "roundtrip_checks")}
                   for key, value in report["models"].items()}, "report": str(output)}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
