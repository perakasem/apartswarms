"""Small, auditable Adaption Responses client; no SDK or external dependencies.

Pricing is credits per million tokens, from the official hosted catalogue read
2026-11-07. Model access is always discovered from the authenticated catalogue.
Budget reservations use UTF-8 request bytes plus 1,024 framing tokens and the
requested output ceiling. Reservations are retained for *every HTTP attempt*,
including unsuccessful attempts; they are deliberately conservative rather than
a claim about the provider's final bill. Model sampling is not seeded.
"""

from __future__ import annotations

import datetime as dt
import json
import math
import os
from pathlib import Path
import re
import stat
import threading
import time
from typing import Any, Callable
import urllib.error
import urllib.parse
import urllib.request


API_ORIGIN = "https://api.prod.adaptionlabs.ai"
API_BASE = API_ORIGIN + "/api/v1"
ALLOWED_HOST = "api.prod.adaptionlabs.ai"
PRICING_SOURCE = "https://docs.adaptionlabs.ai/inference-stacks/models/"
PRICING_DATE = "2026-11-07"
# Input, cached input, output, in credits / million tokens.
MODEL_PRICES = {
    "gemma-4-31b-it": (0.09, 0.05, 0.34),
    "glm-5.2": (1.40, 0.26, 4.40),
    "qwen3.5-397b": (0.55, 0.225, 3.50),
    "gemma-4-26b-a4b-it": (0.0765, 0.0425, 0.255),
    "qwen3.8-27b": (0.039, 0.0039, 1.25),
    "deepseek-v4-flash": (0.04444, 0.001414, 0.13332),
    "glm-53-flash": (0.15, 0.03, 0.50),
}


class AdaptionAPIError(RuntimeError):
    """An API/transport error with a credential-sanitized execution record."""

    def __init__(self, message: str, record: dict | None = None):
        super().__init__(message)
        self.record = record or {}


class CredentialError(AdaptionAPIError):
    pass


class BudgetExceeded(AdaptionAPIError):
    pass


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # urllib's default redirect handler could forward Authorization.
        return None


def _default_transport(request: urllib.request.Request, timeout: float):
    """Return status, headers, bytes. Redirects never receive credentials."""
    opener = urllib.request.build_opener(_NoRedirect())
    try:
        with opener.open(request, timeout=timeout) as response:
            return response.status, dict(response.headers), response.read(8_000_001)
    except urllib.error.HTTPError as exc:
        try:
            return exc.code, dict(exc.headers), exc.read(8_000_001)
        finally:
            exc.close()


def _timestamp() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def extract_output_text(response: dict) -> str:
    """Only assistant message output_text parts; never reasoning or tool text."""
    if isinstance(response.get("output_text"), str):
        return response["output_text"]
    parts = []
    for item in response.get("output", []):
        if not isinstance(item, dict) or item.get("type") != "message":
            continue
        if item.get("role", "assistant") != "assistant":
            continue
        for part in item.get("content", []):
            if isinstance(part, dict) and part.get("type") == "output_text":
                if isinstance(part.get("text"), str):
                    parts.append(part["text"])
    return "".join(parts)


class AdaptionClient:
    def __init__(
        self,
        *,
        api_key: str | None = None,
        secret_file: str | Path | None = None,
        max_credits: float = 25.0,
        max_requests: int = 5000,
        timeout: float = 120.0,
        max_attempts: int = 3,
        initial_budget: dict | None = None,
        budget_checkpoint: Callable[[dict], None] | None = None,
        transport: Callable | None = None,
        sleep: Callable[[float], None] = time.sleep,
    ):
        self._key = self._load_key(api_key, secret_file)
        if not math.isfinite(max_credits) or max_credits < 0:
            raise ValueError("max_credits must be finite and nonnegative")
        if isinstance(max_requests, bool) or max_requests < 0 or int(max_requests) != max_requests:
            raise ValueError("max_requests must be a nonnegative integer")
        if not math.isfinite(timeout) or timeout <= 0:
            raise ValueError("timeout must be finite and positive")
        if max_attempts not in (1, 2, 3):
            raise ValueError("max_attempts must be between one and three")
        self.max_credits = float(max_credits)
        self.max_requests = int(max_requests)
        self.timeout = float(timeout)
        self.max_attempts = max_attempts
        self._transport = transport or _default_transport
        self._sleep = sleep
        self._budget_checkpoint = budget_checkpoint
        self._budget_lock = threading.Lock()
        self._models_lock = threading.Lock()
        self._models = None
        self._budget = {
            "requests": 0, "reserved_credits": 0.0,
            "input_tokens": 0, "output_tokens": 0, "estimated_usage_credits": 0.0,
            "responses_with_usage": 0, "responses_missing_usage": 0,
        }
        for name in self._budget:
            value = (initial_budget or {}).get(name, 0)
            if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(value) or value < 0:
                raise ValueError("initial_budget values must be finite and nonnegative")
            if name in ("requests", "input_tokens", "output_tokens", "responses_with_usage", "responses_missing_usage") and int(value) != value:
                raise ValueError("initial_budget counts must be integers")
            self._budget[name] = value
        if self._budget["requests"] > self.max_requests or self._budget["reserved_credits"] > self.max_credits:
            raise BudgetExceeded("Previously reserved usage already exceeds the configured budget")

    @staticmethod
    def _load_key(api_key, secret_file):
        key = api_key if api_key is not None else os.environ.get("ADAPTION_API_KEY")
        if not key:
            path = Path(secret_file) if secret_file is not None else Path(__file__).resolve().parent.parent / ".secrets" / "adaption_api_key"
            try:
                info = path.lstat()
            except FileNotFoundError:
                raise CredentialError("Set ADAPTION_API_KEY or create .secrets/adaption_api_key with permissions 600") from None
            if not stat.S_ISREG(info.st_mode) or stat.S_IMODE(info.st_mode) != 0o600:
                raise CredentialError("The Adaption key file must be a regular file with permissions 600")
            key = path.read_text(encoding="utf-8").strip()
        if not isinstance(key, str) or not key.strip() or "\n" in key.strip() or "\r" in key.strip():
            raise CredentialError("The Adaption API key must be a nonempty single-line value")
        return key.strip()

    def _sanitize(self, value: Any):
        if isinstance(value, str):
            value = value.replace(self._key, "[REDACTED]")
            value = re.sub(r"(?i)Bearer\s+[^\s\"'<>]+", "Bearer [REDACTED]", value)
            value = re.sub(r"pt_live_[A-Za-z0-9_\-]+", "[REDACTED]", value)
            return value
        if isinstance(value, list):
            return [self._sanitize(v) for v in value]
        if isinstance(value, dict):
            return {self._sanitize(str(k)): self._sanitize(v) for k, v in value.items()}
        return value

    def budget_snapshot(self) -> dict:
        with self._budget_lock:
            return dict(self._budget)

    def _reserve(self, credits, record):
        with self._budget_lock:
            if self._budget["requests"] + 1 > self.max_requests:
                raise BudgetExceeded("Inference request budget exhausted", self._sanitize(record))
            if self._budget["reserved_credits"] + credits > self.max_credits:
                raise BudgetExceeded("Conservative inference credit budget exhausted", self._sanitize(record))
            self._budget["requests"] += 1
            self._budget["reserved_credits"] += credits
            if self._budget_checkpoint is not None:
                # Persist the reservation before sending. The callback must not
                # call budget_snapshot(), because this lock is already held.
                try:
                    self._budget_checkpoint(dict(self._budget))
                except Exception:
                    raise AdaptionAPIError("Budget checkpoint failed; inference was not sent", self._sanitize(record)) from None

    @staticmethod
    def estimate_credits(model: str, input_tokens: int, output_tokens: int) -> float:
        if model not in MODEL_PRICES:
            raise AdaptionAPIError("No verified price for requested model; update the price catalogue before using it")
        prices = MODEL_PRICES[model]
        return (input_tokens * prices[0] + output_tokens * prices[2]) / 1_000_000

    def _call(self, path: str, payload: dict | None = None, reserved_credits: float = 0.0) -> dict:
        url = API_BASE + path
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme != "https" or parsed.hostname != ALLOWED_HOST or parsed.port not in (None, 443) or parsed.username or parsed.password:
            raise AdaptionAPIError("API destination is outside the fixed allowlist")
        if path not in ("/models?type=hosted", "/responses"):
            raise AdaptionAPIError("API route is not allowed")
        body = None if payload is None else json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        record = {
            "timestamp": _timestamp(), "endpoint": url,
            "request": payload, "attempts": [], "response": None,
            "text": "", "usage": {}, "estimated_credits": 0.0,
        }
        started = time.monotonic()
        for attempt in range(1, self.max_attempts + 1):
            if payload is not None:
                try:
                    self._reserve(reserved_credits, record)
                except BudgetExceeded as exc:
                    record.update(latency_seconds=time.monotonic() - started, budget=self.budget_snapshot(), error=str(exc))
                    raise BudgetExceeded(str(exc), self._sanitize(record)) from None
                record["estimated_credits"] += reserved_credits
            req = urllib.request.Request(
                url, data=body,
                headers={"Authorization": "Bearer " + self._key, "Content-Type": "application/json", "Accept": "application/json"},
                method="GET" if body is None else "POST",
            )
            attempt_started = time.monotonic()
            attempt_record = {"attempt": attempt, "timestamp": _timestamp(), "reserved_credits": reserved_credits if payload is not None else 0.0}
            retryable = False
            headers = {}
            try:
                status, headers, raw = self._transport(req, self.timeout)
                attempt_record["http_status"] = status
                if len(raw) > 8_000_000:
                    raise ValueError("Response exceeded 8 MB limit")
                try:
                    data = json.loads(raw)
                except (ValueError, UnicodeDecodeError):
                    data = {"error": {"message": raw.decode("utf-8", errors="replace")[:2048]}}
                    if 200 <= status < 300:
                        raise ValueError("API returned invalid JSON") from None
                if not isinstance(data, dict):
                    raise ValueError("API returned a non-object JSON response")
                if 200 <= status < 300:
                    record["response"] = data
                    record["text"] = extract_output_text(data)
                    usage = data.get("usage")
                    if isinstance(usage, dict):
                        record["usage"] = usage
                    if payload is not None:
                        checkpoint_error = self._record_usage(payload["model"], record["usage"])
                        if checkpoint_error:
                            record["usage_checkpoint_error"] = checkpoint_error
                    attempt_record["latency_seconds"] = time.monotonic() - attempt_started
                    record["attempts"].append(attempt_record)
                    record.update(latency_seconds=time.monotonic() - started, budget=self.budget_snapshot())
                    return self._sanitize(record)
                retryable = status == 429 or 500 <= status < 600
                attempt_record["error"] = self._sanitize(data.get("error", data))
                error = "Adaption API returned HTTP " + str(status)
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                retryable = True
                error = "Adaption transport failure: " + self._sanitize(str(exc))[:2048]
                attempt_record["error"] = error
            except (ValueError, TypeError) as exc:
                error = "Adaption response failure: " + self._sanitize(str(exc))[:2048]
                attempt_record["error"] = error
            attempt_record["latency_seconds"] = time.monotonic() - attempt_started
            record["attempts"].append(attempt_record)
            if retryable and attempt < self.max_attempts:
                delay = float(min(2 ** (attempt - 1), 8))
                retry_after = next((v for k, v in headers.items() if k.lower() == "retry-after"), None)
                try:
                    seconds = float(retry_after)
                    if math.isfinite(seconds):
                        delay = min(8.0, max(delay, seconds))
                except (TypeError, ValueError):
                    pass
                attempt_record["retry_delay_seconds"] = delay
                self._sleep(delay)
            else:
                record.update(error=error, latency_seconds=time.monotonic() - started, budget=self.budget_snapshot())
                raise AdaptionAPIError(error, self._sanitize(record)) from None
        raise AssertionError("unreachable")

    def _record_usage(self, model, usage):
        def count(name):
            n = usage.get(name, 0)
            return n if isinstance(n, int) and not isinstance(n, bool) and n >= 0 else 0
        n_input, n_output = count("input_tokens"), count("output_tokens")
        usage_present = all(isinstance(usage.get(name), int) and not isinstance(usage.get(name), bool) and usage[name] >= 0 for name in ("input_tokens", "output_tokens"))
        with self._budget_lock:
            self._budget["input_tokens"] += n_input
            self._budget["output_tokens"] += n_output
            # Standard input price is deliberately used even if caching applies.
            self._budget["estimated_usage_credits"] += self.estimate_credits(model, n_input, n_output)
            self._budget["responses_with_usage" if usage_present else "responses_missing_usage"] += 1
            if self._budget_checkpoint is not None:
                try:
                    self._budget_checkpoint(dict(self._budget))
                except Exception:
                    # The pre-send reservation is already durable. Preserve the
                    # obtained response and flag this accounting issue; do not
                    # turn it into a retriable inference failure.
                    return "Usage checkpoint failed; the pre-send reservation remains the durable upper estimate"
        return None

    def list_models(self, *, refresh: bool = False) -> list[dict]:
        with self._models_lock:
            if self._models is None or refresh:
                record = self._call("/models?type=hosted")
                data = record["response"].get("data")
                if not isinstance(data, list) or any(not isinstance(m, dict) or not isinstance(m.get("id"), str) for m in data):
                    raise AdaptionAPIError("Model catalogue response is invalid", record)
                self._models = data
            return [dict(m) for m in self._models]

    def create_response(self, *, model: str, input: str | list, instructions: str = "", temperature: float = 0.7, max_output_tokens: int = 1024) -> dict:
        if not isinstance(model, str) or model not in MODEL_PRICES:
            raise AdaptionAPIError("Requested model lacks verified hosted pricing")
        if model not in {m["id"] for m in self.list_models()}:
            raise AdaptionAPIError("Requested model is not available to this API key")
        if not isinstance(temperature, (int, float)) or not math.isfinite(temperature) or not 0 <= temperature <= 2:
            raise ValueError("temperature must be between zero and two")
        if isinstance(max_output_tokens, bool) or not isinstance(max_output_tokens, int) or max_output_tokens < 1:
            raise ValueError("max_output_tokens must be a positive integer")
        if not isinstance(input, (str, list)) or not isinstance(instructions, str):
            raise ValueError("input must be text or a message list; instructions must be text")
        payload = {
            "model": model, "input": input, "instructions": instructions,
            "temperature": temperature, "max_output_tokens": max_output_tokens,
            "agentic_memory": False, "store": False, "tools": [],
            "tool_choice": "none", "stream": False,
        }
        estimated_input_tokens = len(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")) + 1024
        credits = self.estimate_credits(model, estimated_input_tokens, max_output_tokens)
        record = self._call("/responses", payload, credits)
        record["reserved_input_tokens_per_attempt"] = estimated_input_tokens
        record["pricing_source"] = PRICING_SOURCE
        record["pricing_date"] = PRICING_DATE
        return record

    def preflight(self, model: str) -> dict:
        return self.create_response(model=model, input="Return exactly READY.", instructions="Follow the user instruction concisely.", temperature=0, max_output_tokens=64)
